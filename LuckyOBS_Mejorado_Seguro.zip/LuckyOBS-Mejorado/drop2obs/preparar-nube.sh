#!/usr/bin/env bash
# LuckyOBS · instalar en un servidor de Oracle Cloud (o cualquier Ubuntu).
#
#   ./preparar-nube.sh <dominio> [correo]
#
# Qué hace, en orden:
#   1. node y el programa, con su servicio de systemd
#   2. un servicio de Caddy delante, con HTTPS automatico (Let's Encrypt)
#   3. el firewall: solo 80 y 443 abiertos, el puerto de la app no se expone
#   4. el limite de subida, que en la nube no puede ser de 2 GB por archivo
#
# El script es idempotente: se puede volver a ejecutar sin romper nada.

set -euo pipefail
umask 077

DOMAIN="${1:-}"
EMAIL="${2:-}"
STAGE="$HOME/luckyobs-fuente"
PREFIX="${D2O_PREFIX:-$HOME/.local/share/luckyobs}"
DATA_DIR="${D2O_DATA_DIR:-$HOME/.local/share/luckyobs-data}"
PORT="${D2O_PORT:-8787}"
MAX_UPLOAD_MB="${D2O_MAX_UPLOAD_MB:-500}"
USER="$(id -un)"

info() { printf '\033[36m▸\033[0m %s\n' "$*"; }
ok() { printf '\033[32m✔\033[0m %s\n' "$*"; }
die() { printf '\033[31m✘\033[0m %s\n' "$*" >&2; exit 1; }

[ -n "$DOMAIN" ] || die "Falta el dominio:  ./preparar-nube.sh luckyobs.tudominio.com correo@ejemplo.com"
command -v sudo >/dev/null || die "Hace falta sudo (se pide para instalar y para el firewall)"

# ---------------------------------------------------------------- 1. node --
info "Node.js y utilidades"
if ! command -v node >/dev/null; then
  sudo apt-get update -qq
  sudo apt-get install -y -qq ca-certificates curl rsync >/dev/null
  curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash - >/dev/null
  sudo apt-get install -y -qq nodejs >/dev/null
fi
ok "Node $(node -v)"

# -------------------------------------------------------------- 2. la app --
info "LuckyOBS"
if [ -d "$STAGE/.git" ] || [ -f "$STAGE/install.sh" ]; then
  ok "El fuente ya estaba en $STAGE"
else
  die "No encuentro el fuente en $STAGE. Súbelo antes con:
  rsync -az --delete --exclude node_modules --exclude test --exclude .git \\
    '/ruta/a/luckyobs/' usuario@$DOMAIN:~/luckyobs-fuente/"
fi
chmod +x "$STAGE/install.sh"
"$STAGE/install.sh" --port "$PORT" --data-dir "$DATA_DIR" --admin "${D2O_ADMIN_USER:-admin}" \
  >/tmp/luckyobs-install.log 2>&1 || {
  tail -20 /tmp/luckyobs-install.log >&2
  die "install.sh fallo (log en /tmp/luckyobs-install.log)"
}
ok "Servicio instalado y arrancado"

# El limite de subida y la direccion publica van en el servicio, no en un
# archivo aparte, porque es lo unico que se lee al arrancar.
UNIT_DIR="$HOME/.config/systemd/user"
# Un drop-in de systemd va en <unidad>.service.d/, no suelto en el directorio de
# las unidades: puesto fuera, el servicio lo ignora en silencio.
SERVICE_NAME="luckyobs"
DROPIN_DIR="$UNIT_DIR/$SERVICE_NAME.service.d"
DROPIN="$DROPIN_DIR/publico.conf"
mkdir -p "$DROPIN_DIR"
cat > "$DROPIN" <<EOF
[Service]
# El servidor ya no esta en una red domestica: la subida se limita para que un
# archivo gigante no se coma el disco de la maquina.
Environment=D2O_MAX_UPLOAD_MB=$MAX_UPLOAD_MB
# Los enlaces del OBS y de los medios se construyen con esta direccion, en vez
# de con la queceb el peticion. Hace falta delante de un proxy como Caddy.
Environment=D2O_PUBLIC_URL=https://$DOMAIN
# Caddy es el unico punto de entrada; no publicar el puerto 8787 a internet.
Environment=D2O_HOST=127.0.0.1
# Permitir X-Forwarded-Proto SOLO desde el proxy local (cookie Secure).
Environment=D2O_TRUST_PROXY=true
EOF
systemctl --user daemon-reload
systemctl --user restart luckyobs.service
ok "Configurado (subida maxima ${MAX_UPLOAD_MB} MB, URL publica https://$DOMAIN)"

# --------------------------------------------------------------- 3. caddy --
info "Caddy, con HTTPS automatico"
if ! command -v caddy >/dev/null; then
  sudo apt-get install -y -qq debian-keyring debian-archive-keyring apt-transport-https curl >/dev/null
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' \
    | sudo gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg 2>/dev/null
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' \
    | sudo tee /etc/apt/sources.list.d/caddy-stable.list >/dev/null
  sudo apt-get update -qq
  sudo apt-get install -y -qq caddy >/dev/null
fi

CADDY_DIR="$HOME/.config/caddy"
CADDYFILE="$CADDY_DIR/luckyobs.caddy"
mkdir -p "$CADDY_DIR"
# El correo es para los avisos de caducidad del certificado. Si falta, Caddy
# funciona igual pero no avisa de nada.
cat > "$CADDYFILE" <<EOF
{
$( [ -n "$EMAIL" ] && printf '\temail %s\n' "$EMAIL" )
}

# El navegador del OBS y el de los moderadores entran por aqui. Caddy pide el
# certificado solo, se renueva solo y solo acepta TLS.
{$DOMAIN} {
	encode zstd gzip
	reverse_proxy 127.0.0.1:$PORT
	# OBS va quite con websockets y con Streaming.
	header {
		Strict-Transport-Security "max-age=31536000"
		X-Content-Type-Options "nosniff"
	}
}
EOF

# Caddy corre como servicio de sistema (no de usuario): necesita abrir el 443,
# que es por debajo de 1024. Por eso vive en su propio servicio.
CADDY_UNIT="/etc/systemd/system/luckyobs-caddy.service"
sudo tee "$CADDY_UNIT" >/dev/null <<EOF
[Unit]
Description=Caddy delante de LuckyOBS ($DOMAIN)
After=network-online.target
Wants=network-online.target

[Service]
Type=notify
ExecStart=/usr/bin/caddy run --config $CADDYFILE --adapter caddyfile
Restart=always
RestartSec=3
User=$USER
Environment=HOME=$HOME

[Install]
WantedBy=default.target
EOF
sudo systemctl daemon-reload
sudo systemctl enable --now luckyobs-caddy.service
sudo systemctl reload luckyobs-caddy.service 2>/dev/null || sudo systemctl restart luckyobs-caddy.service
ok "Caddy sirviendo https://$DOMAIN"

# ------------------------------------------------------------ 4. firewall --
# En la nube el firewall se manage en el panel de Oracle, pero por si acaso:
info "Firewall local"
if command -v ufw >/dev/null; then
  sudo ufw allow 80/tcp >/dev/null 2>&1 || true
  sudo ufw allow 443/tcp >/dev/null 2>&1 || true
  # No activar UFW automáticamente: podría bloquear el puerto SSH del dueño.
  ok "Reglas 80/443 agregadas; verifica SSH antes de activar UFW"
else
  ok "Sin ufw: el firewall se manage desde el panel de Oracle"
fi

# --------------------------------------------------------------- 5. chequeo --
info "Comprobando"
sleep 3
LOCAL="http://127.0.0.1:$PORT/healthz"
curl -fsS "$LOCAL" >/dev/null || die "La app no responde en $LOCAL"
ok "La app responde en local"

PUBLIC="https://$DOMAIN/healthz"
for attempt in 1 2 3 4 5; do
  if curl -fsS "$PUBLIC" >/dev/null 2>&1; then
    ok "Publico responde: https://$DOMAIN"
    break
  fi
  sleep 4
  if [ "$attempt" = 5 ]; then
    die "No responde por https. Mira:
  sudo journalctl -u luckyobs-caddy -n 40 --no-pager
  sudo caddy validate --config $CADDYFILE --adapter caddyfile"
  fi
done

echo
ok "LuckyOBS esta en linea en https://$DOMAIN"
printf '   Para el OBS:  https://%s/stage?t=<el token de la consola>\n' "$DOMAIN"
printf '   Gestion:     https://%s/\n' "$DOMAIN"
printf '   Logs:        journalctl --user -u luckyobs -f\n'
printf '                sudo journalctl -u luckyobs-caddy -f\n'
printf '   Reiniciar:   systemctl --user restart luckyobs\n'
printf '                sudo systemctl restart luckyobs-caddy\n'
echo
info "Recuerda: en el panel de Oracle el puerto $PORT NO debe estar abierto en la red publica."
info "Por el puerto $PORT solo se habla Caddy y los dos estan en la misma maquina."