import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
export const ROOT_DIR = path.resolve(here, '..');

const TRUE_VALUES = new Set(['1', 'true', 'yes', 'on']);
const FALSE_VALUES = new Set(['0', 'false', 'no', 'off']);

export function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i += 1) {
    const raw = argv[i];
    if (!raw.startsWith('--')) continue;
    const body = raw.slice(2);
    const eq = body.indexOf('=');
    if (eq !== -1) {
      out[body.slice(0, eq)] = body.slice(eq + 1);
      continue;
    }
    const next = argv[i + 1];
    if (next !== undefined && !next.startsWith('--')) {
      out[body] = next;
      i += 1;
    } else {
      out[body] = 'true';
    }
  }
  return out;
}

function pick(args, key, envKey, fallback) {
  if (args[key] !== undefined) return args[key];
  if (process.env[envKey] !== undefined && process.env[envKey] !== '') return process.env[envKey];
  return fallback;
}

function toBool(value, fallback) {
  if (value === undefined) return fallback;
  const v = String(value).trim().toLowerCase();
  if (TRUE_VALUES.has(v)) return true;
  if (FALSE_VALUES.has(v)) return false;
  return fallback;
}

function toInt(value, fallback, min, max) {
  const n = Number.parseInt(value, 10);
  if (!Number.isFinite(n)) return fallback;
  if (min !== undefined && n < min) return min;
  if (max !== undefined && n > max) return max;
  return n;
}

export function randomToken() {
  return crypto.randomBytes(18).toString('base64url');
}

function loadTokenFile(dataDir) {
  const file = path.join(dataDir, 'token.txt');
  try {
    const value = fs.readFileSync(file, 'utf8').trim();
    if (value) return value;
  } catch {
    /* file does not exist yet */
  }
  return null;
}

function saveTokenFile(dataDir, token) {
  const file = path.join(dataDir, 'token.txt');
  fs.mkdirSync(dataDir, { recursive: true });
  fs.writeFileSync(file, `${token}\n`, { mode: 0o600 });
  try {
    fs.chmodSync(file, 0o600);
  } catch {
    /* best effort on exotic filesystems */
  }
}

export function loadConfig(argv = process.argv.slice(2)) {
  const args = parseArgs(argv);
  const dataDir = path.resolve(
    pick(args, 'data', 'D2O_DATA_DIR', path.join(ROOT_DIR, 'data')),
  );
  fs.mkdirSync(dataDir, { recursive: true });
  fs.mkdirSync(path.join(dataDir, 'media'), { recursive: true });
  fs.mkdirSync(path.join(dataDir, 'uploads'), { recursive: true });

  let token = pick(args, 'token', 'D2O_TOKEN', null);
  if (!token || token === 'auto') {
    token = loadTokenFile(dataDir) ?? randomToken();
  }
  const tokenFile = path.join(dataDir, 'token.txt');
  let tokenPersisted = false;
  try {
    tokenPersisted = loadTokenFile(dataDir) === token;
  } catch {
    tokenPersisted = false;
  }
  if (!tokenPersisted) saveTokenFile(dataDir, token);

  // The emitted canvas is what the stream shows: the top half of one long
  // screen. The bank sits underneath at exactly the same size, so the whole
  // thing is the canvas twice over and the cut between them is the middle.
  const canvas = normalizeCanvas(pick(args, 'canvas', 'D2O_CANVAS', '1920x1080'));
  const [airWidth, airHeight] = canvas.split('x').map(Number);

  const config = {
    port: toInt(pick(args, 'port', 'D2O_PORT', 8787), 8787, 1, 65535),
    host: pick(args, 'host', 'D2O_HOST', '0.0.0.0'),
    token,
    // Tokens that used to be the current one and still work. Changing the token
    // takes effect at once everywhere, which leaves any OBS source still holding
    // an old link showing black in the middle of a stream. Listing the previous
    // one here keeps that source alive until whoever set it up can paste the new
    // link, and removing it from the list takes it back down.
    previousTokens: String(pick(args, 'previous-tokens', 'D2O_PREV_TOKENS', '') || '')
      .split(/[\s,]+/)
      .map((value) => value.trim())
      .filter((value) => value && value !== token),
    tokenFile,
    dataDir,
    mediaDir: path.join(dataDir, 'media'),
    uploadTmpDir: path.join(dataDir, 'uploads'),
    stateFile: path.join(dataDir, 'state.json'),
    publicUrl: (pick(args, 'public-url', 'D2O_PUBLIC_URL', '') || '').replace(/\/+$/, ''),
    publicDir: path.join(ROOT_DIR, 'public'),
    maxUploadMb: toInt(pick(args, 'max-upload-mb', 'D2O_MAX_UPLOAD_MB', 2048), 2048, 1, 102400),
    history: toInt(pick(args, 'history', 'D2O_HISTORY', 200), 200, 1, 5000),
    deleteOnClear: toBool(pick(args, 'delete-on-clear', 'D2O_DELETE_ON_CLEAR', true), true),
    uploadTtlHours: toInt(pick(args, 'upload-ttl-hours', 'D2O_UPLOAD_TTL_HOURS', 24), 24, 0, 8760),
    // One long screen: the emitted canvas on top, the bank right underneath at the
    // same size. Everything that draws the whole thing uses `screen`; everything
    // that draws what the audience sees uses `canvas`.
    canvas,
    airWidth,
    airHeight,
    screen: `${airWidth}x${airHeight * 2}`,
    air: { width: airWidth, height: airHeight },
    trustProxy: toBool(pick(args, 'trust-proxy', 'D2O_TRUST_PROXY', false), false),
    logRequests: toBool(pick(args, 'log-requests', 'D2O_LOG_REQUESTS', true), true),
    loginMaxPerUser: toInt(pick(args, 'login-max-per-user', 'D2O_LOGIN_MAX_PER_USER', 5), 5, 1, 100),
    loginMaxPerIp: toInt(pick(args, 'login-max-per-ip', 'D2O_LOGIN_MAX_PER_IP', 30), 30, 1, 1000),
  };

  return config;
}

// "1920x1080" -> [1920, 1080]; anything unusable falls back to 1080p.
export function normalizeCanvas(value) {
  const match = /^\s*(\d{2,5})\s*[x×]\s*(\d{2,5})\s*$/i.exec(String(value ?? ''));
  if (!match) return '1920x1080';
  const width = Math.min(16384, Math.max(16, Number(match[1])));
  const height = Math.min(16384, Math.max(16, Number(match[2])));
  return `${width}x${height}`;
}

/** The same canvas as real numbers, for the scene geometry. */
export function canvasSize(value) {
  const [width, height] = normalizeCanvas(value).split('x').map(Number);
  return { width, height };
}

const VIRTUAL_IFACE_PREFIXES = [
  'docker', 'br-', 'veth', 'virbr', 'podman', 'cni', 'flannel', 'kube', 'lxc', 'lxd',
];

export function lanAddresses() {
  const out = [];
  let interfaces = {};
  try {
    interfaces = os.networkInterfaces();
  } catch {
    // Some sandboxes (systemd RestrictAddressFamilies, containers) forbid the
    // netlink socket this uses. Not worth failing the boot over.
    return out;
  }
  for (const [name, list] of Object.entries(interfaces)) {
    const lowered = name.toLowerCase();
    if (VIRTUAL_IFACE_PREFIXES.some((prefix) => lowered.startsWith(prefix))) continue;
    for (const net of list ?? []) {
      if (net.family !== 'IPv4' || net.internal) continue;
      out.push(net.address);
    }
  }
  return out;
}
