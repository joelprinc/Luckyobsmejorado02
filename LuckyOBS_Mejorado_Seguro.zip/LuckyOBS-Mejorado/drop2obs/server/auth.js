import crypto from 'node:crypto';
import { readCookie, readUserCookie } from './users.js';

/** Cookie of the OBS stage. Distinct from the user session cookie on purpose. */
export const SESSION_COOKIE = 'd2o_session';
const COOKIE_TTL_MS = 1000 * 60 * 60 * 24 * 30;
const LOGIN_ASSETS = new Set(['/login', '/login.html', '/login.css', '/login.js']);
const SESSION_SECRET = 'luckyobs.session.v1';

export function safeEqual(a, b) {
  const bufA = Buffer.from(String(a ?? ''), 'utf8');
  const bufB = Buffer.from(String(b ?? ''), 'utf8');
  if (bufA.length !== bufB.length || bufA.length === 0) {
    // Still run a comparison so timing does not leak the length.
    crypto.timingSafeEqual(bufA, bufA);
    return false;
  }
  return crypto.timingSafeEqual(bufA, bufB);
}

export function signMedia(secret, id) {
  return crypto
    .createHmac('sha256', secret)
    .update(String(id))
    .digest('base64url')
    .slice(0, 32);
}

export function buildSessionCookie(value, secure) {
  const attrs = [
    `${SESSION_COOKIE}=${encodeURIComponent(value)}`,
    'Path=/',
    'HttpOnly',
    'SameSite=Lax',
    `Max-Age=${Math.floor(COOKIE_TTL_MS / 1000)}`,
  ];
  if (secure) attrs.push('Secure');
  return attrs.join('; ');
}

export function extractToken(req) {
  const header = req.headers.authorization;
  if (header && /^bearer\s+/i.test(header)) return header.replace(/^bearer\s+/i, '').trim();
  if (typeof req.headers['x-d2o-token'] === 'string') return req.headers['x-d2o-token'];
  if (req.query && typeof req.query.t === 'string') return req.query.t;
  return null;
}

/**
 * Gate in front of everything.
 *
 * Two principals exist:
 *   - {kind:'user'}  a moderator signed in with user + password
 *   - {kind:'token'} whoever knows the server token (the OBS stage, scripts)
 * Reads are allowed for both; writes require a signed in user, so the stage URL
 * that the friend has in OBS can never change anything.
 */
export function createAuth(config, { users, publicPaths = new Set() } = {}) {
  const sessionValue = crypto
    .createHmac('sha256', `${config.token}:${SESSION_SECRET}`)
    .update('session')
    .digest('base64url');

  const COOKIE_UPGRADE_PATHS = new Set(['/', '/stage']);

  function isValid(value) {
    if (!value) return false;
    return safeEqual(value, config.token) || safeEqual(value, sessionValue);
  }

  /**
   * What a screen needs to show the show, and nothing more. A token that used to
   * be the current one gets this far: an OBS source that is already on air keeps
   * working while somebody goes for the new link, but the old link only opens
   * the stage, never the controls.
   */
  function isStageToken(value) {
    if (isValid(value)) return true;
    if (!value) return false;
    return (config.previousTokens ?? []).some((old) => safeEqual(value, old));
  }

  function sessionCookieValue(req) {
    return readCookie(req.headers?.cookie, SESSION_COOKIE);
  }

  function userCookieValue(req) {
    return readUserCookie(req);
  }

  /** The signed in user of a request, or null. Used by the event socket. */
  function userPrincipal(req) {
    if (!users) return null;
    return users.resolveSession(userCookieValue(req))?.user ?? null;
  }

  /** Same path, but without the token: ?ui=1&fit=0.8 must survive the swap. */
  function withoutToken(originalUrl) {
    try {
      const url = new URL(String(originalUrl || '/'), 'http://localhost');
      url.searchParams.delete('t');
      return `${url.pathname}${url.search}`;
    } catch {
      return '/';
    }
  }

  function wantsHtml(req) {
    return String(req.headers.accept ?? '').includes('text/html');
  }

  function isPublic(req) {
    if (publicPaths.has(req.path)) return true;
    if (req.path.startsWith('/api/auth/')) return true;
    // The stage shell is empty: the scene, the media and the socket all live
    // behind the token. Serving it to a stale link is what lets the source say
    // "this link has expired" in red on the stream, instead of showing a login
    // form nobody can fill in from inside OBS.
    if (req.path === '/stage') return true;
    // The typefaces the app carries: not a secret, and the OBS source has to be
    // able to draw a label with them even if its cookie has not arrived yet.
    if (req.path.startsWith('/fuentes/')) return true;
    return LOGIN_ASSETS.has(req.path);
  }

  function middleware(req, res, next) {
    const token = extractToken(req);
    const stageCookie = sessionCookieValue(req);
    const signedIn = users ? users.resolveSession(userCookieValue(req)) : null;

    if (signedIn) {
      req.principal = { kind: 'user', user: signedIn.user, session: signedIn.session };
      return next();
    }

    if (isValid(token) || isValid(stageCookie)) {
      // No accounts yet: the token still runs the show so the first admin can
      // be created without locking anyone out.
      req.principal = { kind: 'token', manage: Boolean(users?.isBootstrap?.()) };
      if (token === config.token) {
        res.setHeader('set-cookie', buildSessionCookie(sessionValue, req.secure));
        // The landing page and the stage both accept ?t=<token>: swap it for the
        // session cookie so OBS (which cannot set headers) keeps working.
        if (COOKIE_UPGRADE_PATHS.has(req.path) && typeof req.query?.t === 'string') {
          res.redirect(302, withoutToken(req.originalUrl));
          return;
        }
      }
      return next();
    }

    if (isPublic(req)) {
      req.principal = null;
      return next();
    }

    if (isStageToken(token)) {
      // A link from before the token changed: enough to read the scene and show
      // it, and nothing else. Without this an OBS source that is already on air
      // goes black the moment the token is rotated, while the person who set it
      // up is nowhere near the machine.
      if (req.path !== '/api/state') {
        res.status(403).json({ error: 'forbidden' });
        return;
      }
      req.principal = { kind: 'stage' };
      return next();
    }

    if (wantsHtml(req)) {
      res.redirect(302, `/login?next=${encodeURIComponent(req.originalUrl || '/')}`);
      return;
    }
    res.status(401).json({ error: 'unauthorized' });
  }

  return {
    isValid,
    isStageToken,
    middleware,
    sessionCookieValue,
    userCookieValue,
    userPrincipal,
    stageSessionValue: sessionValue,
  };
}
