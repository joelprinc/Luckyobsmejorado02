/*
 /**
 * Scene model: one long screen, the emitted canvas on top and the bank right
 * underneath it at the same size.
 *
 *   program  the whole screen. The OBS browser source renders only the top half,
 *            so whether something goes out is decided by its y and nothing else.
 *
 * Every object stores its own transform, so what a moderator places is the very
 * same thing they see, at the size they see it.
 */
import path from 'node:path';

import { isAudioOnly, newMediaId, renderKind } from './media.js';

// One scene: the emission and the bank are two halves of the same screen, not
// two places an object can be. The id is kept so stored objects and the API
// keep the same shape.
export const SCENES = ['program'];

const SCENE_LABELS = { program: 'Pantalla' };

/** Guards every number that reaches the DOM, so a bad request cannot desync the
 *  control page from the stream. */
const clamp = (value, min, max, fallback) => {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
};

const round2 = (n) => Math.round(n * 100) / 100;

export function sceneLabel(id) {
  return SCENE_LABELS[id] ?? id;
}

export function emptyScene(id, { width, height }) {
  return { id, name: SCENE_LABELS[id] ?? id, width, height, objects: [] };
}

/**
 * Normalises an object coming from disk or from a request. A scene that is not
 * the one there is falls back to it, so a typo can never hide something from
 * the stream by accident, and every geometry field ends up a finite number.
 */
/**
 * How much of an object has to stay inside the screen. Anything pushed further
 * out than this cannot be clicked, so it could not be moved or deleted again
 * from the panel: it would be gone for good while still listed as content.
 */
export const REACH = 24;

/**
 * Keeps an object grabbable: at least REACH of it stays inside the screen, on
 * every side. An object bigger than the screen is centred instead, since there
 * is no room to spare on any side.
 */
export function keepOnScreen(value, size, limit) {
  if (size >= limit) return 0;
  return clamp(value, REACH - size, limit - REACH);
}

export function sanitizeObject(raw, { scene, width, height, cut = 0, fallbackZ = 0 }) {
  if (!raw || typeof raw !== 'object') return null;
  const id = typeof raw.id === 'string' && raw.id ? raw.id : newMediaId();
  // A text gets a box shaped like a label, and an audio a box shaped like its
  // card: a name and five bars. The generic forty percent is about right for a
  // picture and far too much for either of those.
  const texty = raw.render === 'text';
  const audioy = raw.audioOnly === true || isAudioOnly(raw.name, raw.mime);
  const fallbackW = texty ? 0.6 : audioy ? Math.min(0.4, 560 / width) : 0.4;
  const w = clamp(raw.w, 1, width * 4, Math.round(width * fallbackW));
  const h = clamp(
    raw.h,
    1,
    height * 4,
    texty ? Math.round(clamp(raw.textSize ?? 96, 8, 800, 96) * 1.7)
      : audioy ? 150
        : Math.round(height * 0.4),
  );
  return {
    id,
    scene: SCENES.includes(raw.scene) ? raw.scene : SCENES.includes(scene) ? scene : SCENES[0],
    uploadId: typeof raw.uploadId === 'string' ? raw.uploadId : '',
    file: typeof raw.file === 'string' ? raw.file : '',
    name: typeof raw.name === 'string' && raw.name ? raw.name : 'objeto',
    kind: raw.kind || 'browser',
    render: raw.render || renderKind(raw.name, raw.mime),
    ext: raw.ext ?? path.extname(String(raw.name ?? '')),
    mime: raw.mime || '',
    size: Number.isFinite(raw.size) ? raw.size : 0,
    // Intrinsic size, kept apart from the on-screen size so a resize can be undone.
    naturalWidth: Number.isFinite(raw.naturalWidth) ? raw.naturalWidth : null,
    naturalHeight: Number.isFinite(raw.naturalHeight) ? raw.naturalHeight : null,
    // With no coordinates an object is centred, and in the bank rather than on
    // air: something nobody has placed yet has no business going out. The NaN
    // that came out of here before is why.
    x: round2(keepOnScreen(Number.isFinite(raw.x) ? raw.x : (width - w) / 2, w, width)),
    y: round2(keepOnScreen(
      Number.isFinite(raw.y) ? raw.y : (cut > 0 ? cut + (cut - h) / 2 : (height - h) / 2),
      h,
      height,
    )),
    w: round2(w),
    h: round2(h),
    // Clip controls. The sound belongs to the stream, so it travels with the
    // object: what is quiet here is quiet in OBS. `volume` goes from 0 to 1 and
    // zero is the old "muted", so an object saved before the slider existed keeps
    // the silence it had. `playAt` is the moment the clip was last started from
    // the beginning, which is how a replay reaches the screen of the friend and
    // not only this panel.
    volume: round2(clamp(raw.volume ?? (raw.muted === true ? 0 : 1), 0, 1, 1)),
    // An mp3 has no picture to draw, so the stage gives it a card of its own
    // instead of leaving an empty box sitting on the stream.
    audioOnly: raw.audioOnly === true || isAudioOnly(raw.name, raw.mime),
    // A text object carries its own words and its own look. The defaults are the
    // ones a stream wants: Arial, big, and white so it reads over anything.
    text: typeof raw.text === 'string' ? raw.text.slice(0, 2000) : '',
    textFont: sanitizeTextFont(raw.textFont),
    textSize: Math.round(clamp(raw.textSize ?? 96, 8, 800, 96)),
    textColor: sanitizeTextColor(raw.textColor),
    textAlign: ['left', 'center', 'right'].includes(raw.textAlign) ? raw.textAlign : 'center',
    loop: raw.loop !== false,
    playAt: Number.isFinite(raw.playAt) ? Math.max(0, Math.round(raw.playAt)) : 0,
    /*
     * Where in the clip it was left, and when that was decided. Both travel
     * together so every screen works out the same moment on its own: the OBS
     * source and this panel each add the time that has gone by since `at`. That
     * is what lets a moderator jump to another point of a video and have the
     * jump land on the stream, and keep landing in the same place afterwards.
     */
    seek: raw.seek && typeof raw.seek === 'object' && Number.isFinite(raw.seek.pos)
      ? {
        pos: round2(clamp(raw.seek.pos, 0, 86400, 0)),
        at: Number.isFinite(raw.seek.at) ? Math.max(0, Math.round(raw.seek.at)) : 0,
      }
      : null,
    rot: round2(clamp(raw.rot, -360, 360, 0)),
    opacity: round2(clamp(raw.opacity ?? 1, 0, 1, 1)),
    z: Number.isFinite(raw.z) ? raw.z : fallbackZ,
    visible: raw.visible !== false,
    locked: Boolean(raw.locked),
    addedAt: typeof raw.addedAt === 'string' ? raw.addedAt : new Date().toISOString(),
  };
}

/*
 * The fonts a text object may use. A whitelist, because this string ends up in
 * the style of the OBS browser source: whatever arrives from a request has to be
 * one of these names, never something the request made up.
 *
 * Each entry is a stack: the family the moderator asked for first, and then
 * something that looks the same in case the machine drawing the stream does not
 * have it. That last part is why the stage carries its own copies of two of them:
 * the OBS source runs on somebody else's computer.
 */
export const TEXT_FONTS = [
  { id: 'arial', label: 'Arial', stack: '"Arial", "Liberation Sans", "Helvetica Neue", sans-serif' },
  { id: 'comic', label: 'Comic Sans', stack: '"Comic Sans MS", "Comic Neue", cursive' },
  { id: 'papyrus', label: 'Papyrus', stack: '"Papyrus", "PapyrusStd", "Eccentric Std", serif' },
  { id: 'impact', label: 'Impact', stack: 'Impact, "Arial Black", sans-serif' },
  { id: 'georgia', label: 'Georgia', stack: 'Georgia, "Liberation Serif", serif' },
  { id: 'mono', label: 'Monoespaciada', stack: 'ui-monospace, "Liberation Mono", Menlo, monospace' },
];
export const DEFAULT_TEXT_FONT = 'arial';

const TEXT_FONT_IDS = new Set(TEXT_FONTS.map((f) => f.id));

export function sanitizeTextFont(value) {
  const id = String(value ?? '').trim().toLowerCase();
  return TEXT_FONT_IDS.has(id) ? id : DEFAULT_TEXT_FONT;
}

const TEXT_FONT_STACKS = new Map(TEXT_FONTS.map((f) => [f.id, f.stack]));

export function textFontStack(id) {
  return TEXT_FONT_STACKS.get(sanitizeTextFont(id));
}

/** Only a plain #rgb or #rrggbb colour, so nothing else can end up in the style. */
export function sanitizeTextColor(value, fallback = '#ffffff') {
  const raw = String(value ?? '').trim().toLowerCase();
  if (/^#[0-9a-f]{3}$/.test(raw)) return raw;
  if (/^#[0-9a-f]{6}$/.test(raw)) return raw;
  return fallback;
}

export function sanitizeScene(raw, id, canvas) {
  const base = emptyScene(id, canvas);
  if (!raw || typeof raw !== 'object') return base;
  const objects = Array.isArray(raw.objects) ? raw.objects : [];
  base.objects = objects
    .map((o) => sanitizeObject(o, { ...canvas, scene: id }))
    .filter(Boolean);
  return base;
}

/**
 * Turns the old flat "layers" list into program objects. The old stage drew
 * every layer full bleed on top of each other, so that is exactly how they are
 * placed here and the stream looks the same after the upgrade.
 */
export function migrateLegacyLayers(layers, canvas) {
  return (Array.isArray(layers) ? layers : [])
    .filter((layer) => layer && layer.file)
    .map((layer, index) =>
      sanitizeObject(
        {
          id: layer.id,
          scene: 'program',
          uploadId: layer.uploadId,
          file: layer.file,
          name: layer.name,
          kind: layer.kind,
          render: layer.render || renderKind(layer.name, layer.mime),
          ext: layer.ext ?? path.extname(String(layer.name ?? '')),
          mime: layer.mime,
          size: layer.size,
          naturalWidth: layer.width ?? null,
          naturalHeight: layer.height ?? null,
          x: 0,
          y: 0,
          w: canvas.width,
          h: canvas.height,
          rot: 0,
          z: Number.isFinite(layer.seq) ? layer.seq : index + 1,
          visible: !layer.hidden,
          addedAt: layer.addedAt,
        },
        { ...canvas, scene: 'program' },
      ),
    );
}

export function topZ(scene) {
  return scene.objects.reduce((max, o) => Math.max(max, o.z), 0);
}

export function bottomZ(scene) {
  return scene.objects.reduce((min, o) => Math.min(min, o.z), 0);
}

/** Draw order: z first, then insertion order, so equal z never flickers. */
export function sortObjects(scene) {
  return [...scene.objects].sort((a, b) => a.z - b.z || a.addedAt.localeCompare(b.addedAt));
}
