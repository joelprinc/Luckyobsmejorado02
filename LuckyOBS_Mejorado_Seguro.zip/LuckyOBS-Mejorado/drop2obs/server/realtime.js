import { WebSocketServer } from 'ws';
import { resolveBaseUrl } from './urls.js';
import { browserOriginAllowed } from './browser-origin.js';

const HEARTBEAT_MS = 25000;

/** The address the client actually reached us on, so media links stay usable. */
function baseFromRequest(req, trustProxy) {
  const headers = req.headers ?? {};
  const proto = trustProxy
    ? String(headers['x-forwarded-proto'] ?? '').split(',')[0].trim()
    : '';
  const host = trustProxy
    ? String(headers['x-forwarded-host'] ?? '').split(',')[0].trim()
    : String(headers.host ?? '').trim();
  if (!host) return '';
  return `${proto || 'http'}://${host}`;
}

/**
 * Where a connection really comes from. Behind the tunnel the socket address is
 * the cloudflared container on this machine, which says nothing about who is
 * streaming, so the country and the real address are read from the edge when it
 * sends them.
 */
function originOf(req) {
  const headers = req.headers ?? {};
  const country = String(headers['cf-ipcountry'] ?? '').slice(0, 2).toUpperCase();
  const ip = String(headers['cf-connecting-ip'] ?? '').slice(0, 45);
  const where = [country, ip].filter(Boolean).join(' ');
  return where || String(req.socket?.remoteAddress ?? '');
}

/**
 * What the source says it can draw, kept short and typed. This is the only way
 * to tell "the source is showing a black screen" from "the source is not
 * running", which look identical from here. Numbers and text only.
 */
function sanitiseDiag(raw) {
  if (!raw || typeof raw !== 'object') return null;
  const size = (value) => (typeof value === 'string' ? value.slice(0, 20) : '');
  const num = (value) => (Number.isFinite(Number(value)) ? Number(value) : 0);
  const errors = Array.isArray(raw.errors)
    ? raw.errors
      .filter((line) => typeof line === 'string' && line)
      .slice(-3)
      .map((line) => line.slice(0, 160))
    : [];
  return {
    viewport: size(raw.viewport),
    ratio: num(raw.ratio),
    box: size(raw.box),
    drawn: num(raw.drawn),
    imgs: num(raw.imgs),
    broken: num(raw.broken),
    fit: num(raw.fit),
    errors,
  };
}

export class Hub {
  constructor({ config, store, log, auth, activity, users }) {
    this.config = config;
    this.auth = auth;
    this.store = store;
    this.activity = activity;
    this.users = users;
    this.log = log;
    this.stage = new Set();
    this.ui = new Set();
    this.observedBase = '';
    this.wss = new WebSocketServer({ noServer: true, maxPayload: 256 * 1024 });
    this.wss.on('connection', (ws, req, role) => this.#onConnection(ws, req, role));
    this.heartbeat = setInterval(() => {
      this.#sweep();
      this.refreshPresence();
    }, HEARTBEAT_MS);
    this.heartbeat.unref?.();
  }

  handleUpgrade(req, socket, head, url) {
    const { pathname, searchParams } = url;
    let role = null;
    if (pathname === '/stage') {
      role = 'stage';
      req.stageId = String(searchParams.get('id') ?? '');
    } else if (pathname === '/events') role = 'ui';
    if (!role) {
      socket.destroy();
      return;
    }
    const token = searchParams.get('t') ?? this.auth.sessionCookieValue(req);
    // The stage is fed by the token, the control page by whoever is signed in.
    // Both used to be token only, which left every logged in user without live
    // updates and a control panel stuck on "sin servidor".
    //
    // A signed in user may open either one. Opening the OBS link in the same
    // browser as the control page serves the stage as that user, and without
    // this the source would fall back to the four second poll: visible objects,
    // but no live drag.
    // The OBS source may read the scene. Only an authenticated moderator can
    // join /events, which includes the private workspace, history and presence.
    // Previously the OBS-only token could join /events and send transforms.
    const allowed = role === 'ui'
      ? Boolean(this.auth.userPrincipal(req))
      : (this.auth.isStageToken(token) || Boolean(this.auth.userPrincipal(req)));
    const trustedOrigin = browserOriginAllowed(req, this.config.publicUrl);
    if (!allowed || !trustedOrigin) {
      // Who is knocking and with what: without this, a refused source is just a
      // line of an IP behind the tunnel, and the two usual suspects (an OBS
      // source with an old link and a stale browser tab) are impossible to tell
      // apart. Only the product name is kept, never the whole header.
      const agent = String(req.headers['user-agent'] ?? 'desconocido').slice(0, 60);
      const reason = !trustedOrigin ? 'origen no permitido' : (role === 'ui' ? 'se necesita usuario' : 'token caducado');
      this.log('warn', `rejected ${role} websocket (${reason}, ${originOf(req)}, ${agent})`);
      socket.write('HTTP/1.1 401 Unauthorized\r\nConnection: close\r\n\r\n');
      socket.destroy();
      return;
    }
    this.observedBase = baseFromRequest(req, this.config.trustProxy) || this.observedBase;
    this.wss.handleUpgrade(req, socket, head, (ws) => {
      this.wss.emit('connection', ws, req, role);
    });
  }

  #onConnection(ws, req, role) {
    ws.isAlive = true;
    ws.role = role;
    // Keep the initial request so a revoked/disabled login cannot keep a live
    // control socket open indefinitely after the user's session is removed.
    if (role === 'ui') ws.authRequest = req;
    ws.seenAt = Date.now();
    ws.on('pong', () => {
      ws.isAlive = true;
      ws.seenAt = Date.now();
      // A browser source answers the ping even with nothing happening on it, so
      // the pong is the honest proof that the source is still running. Without
      // this the panel only heard from the screen when it connected or when its
      // window was resized, and went on saying "OBS desconectado" after a
      // minute of a perfectly good source.
      if (ws.role === 'stage' && ws.clientId) {
        this.store.touchAgent(ws.clientId, { kind: 'stage', source: 'ws' });
      }
    });

    if (role === 'stage') {
      // The stage is the browser source running inside OBS. Registering it
      // lets the control page tell whether the friend's screen is even live.
      this.stage.add(ws);
      ws.clientId = this.#pickStageId(req);
      this.store.touchAgent(ws.clientId, {
        kind: 'stage',
        name: 'Pantalla OBS',
        canvas: '',
        source: 'ws',
      });
      this.log('info', `stage connected as ${ws.clientId} (${this.stage.size} online, ${originOf(req)})`);
      this.#send(ws, { type: 'state', ...this.#statePayload(true) });
      this.broadcastScreens();
    } else {
      this.ui.add(ws);
      ws.clientId = `ui-${Math.random().toString(36).slice(2, 8)}`;
      /*
       * Who is in the room. The user comes from the session cookie, so it is
       * the account that really opened the page, and it only exists while the
       * socket lives: closing the tab is what marks somebody as gone.
       */
      const user = this.auth.userPrincipal(req);
      if (user) {
        ws.username = user.username;
        ws.role = 'ui';
        ws.userRole = user.role;
        this.activity?.connect(user.username, user.role);
      }
      this.#send(ws, { type: 'state', ...this.#statePayload() });
      // The uploads list only exists in the workspace frame, so a control page
      // that reconnects mid session would come back with a stale queue unless
      // the server hands it the whole thing on connect.
      this.#send(ws, { type: 'workspace', ...this.#workspacePayload() });
      this.#send(ws, this.#activityPayload());
    }

    ws.on('message', (raw) => this.#onMessage(ws, raw));
    ws.on('close', () => {
      if (role === 'stage') {
        this.stage.delete(ws);
        this.store.disconnectAgent(ws.clientId);
        this.log('info', `stage disconnected (${this.stage.size} online)`);
        this.broadcastScreens();
      } else {
        this.ui.delete(ws);
        if (ws.username) this.activity?.disconnect(ws.username);
      }
    });
    ws.on('error', (err) => this.log('warn', `websocket error: ${err.message}`));
  }

  #onMessage(ws, raw) {
    let msg;
    try {
      msg = JSON.parse(String(raw).slice(0, 64 * 1024));
    } catch {
      return;
    }
    if (ws.role === 'ui') {
      this.#onUiMessage(ws, msg);
      return;
    }
    if (ws.role !== 'stage') return;
    if (msg.type !== 'hello' && msg.type !== 'ping' && msg.type !== 'report' && msg.type !== 'alive') {
      return;
    }
    const drawn = Number(msg.rendered);
    this.store.touchAgent(ws.clientId, {
      kind: 'stage',
      name: typeof msg.name === 'string' && msg.name ? msg.name.slice(0, 40) : 'Pantalla OBS',
      canvas: typeof msg.canvas === 'string' ? msg.canvas.slice(0, 20) : '',
      source: 'ws',
      diag: sanitiseDiag(msg.diag),
      // When it last drew something, turned into a clock right here and now.
      // Keeping the duration instead and turning it into an instant on every
      // read made it slide forward with the clock, so a source that had been
      // silent for an hour looked as fresh as one that had just spoken.
      ...(Number.isFinite(drawn) && drawn >= 0
        ? { renderedAt: new Date(Date.now() - Math.min(600000, Math.round(drawn))).toISOString() }
        : {}),
    });
    this.broadcastScreens();
  }

  /**
   * A signed in control page streams the transform of the object being dragged
   * so the stream follows the cursor. It never touches the saved state: the
   * same values are committed through PATCH /api/objects/:id on drop.
   */
  #onUiMessage(ws, msg) {
    if (!this.auth.userPrincipal(ws.authRequest)) {
      ws.close(1008, 'sesion terminada');
      return;
    }
    // Any traffic at all means the page is alive, which keeps "connected" honest
    // for somebody whose tab is open but idle.
    if (ws.username && msg?.type !== 'transform') {
      this.activity?.connect(ws.username, ws.userRole);
      this.#send(ws, this.#activityPayload());
    }
    if (msg?.type !== 'transform') return;
    if (typeof msg.id !== 'string' || !msg.id) return;
    // One frame per pointer move is already 60/s, so anything much above that
    // is a client stuck in a loop rather than a person dragging.
    const now = Date.now();
    if (typeof ws.transformWindow !== 'number' || now - ws.transformWindow >= 1000) {
      ws.transformWindow = now;
      ws.transformCount = 0;
    }
    ws.transformCount += 1;
    if (ws.transformCount > 90) return;
    const object = this.store.previewObject(msg.id, msg);
    this.broadcastTransform(object);
  }

  #pickStageId(req) {
    const raw = String(req.stageId || req.headers['x-stage-id'] || '').trim();
    if (raw.length >= 4 && raw.length <= 40 && /^[A-Za-z0-9_.:-]+$/.test(raw)) return raw;
    return `stage-${Math.random().toString(36).slice(2, 8)}`;
  }

  #statePayload(stageOnly = false) {
    const state = this.store.snapshot({ baseUrl: this.#baseUrl() });
    if (stageOnly && state.program) {
      state.program.objects = state.program.objects.filter((object) => object.y < state.cut);
    }
    return state;
  }

  #workspacePayload() {
    return this.store.workspace({ baseUrl: this.#baseUrl() });
  }

  #baseUrl() {
    return resolveBaseUrl({
      publicUrl: this.config.publicUrl,
      fallback: this.observedBase || `http://127.0.0.1:${this.config.port}`,
    });
  }

  #sweep() {
    for (const ws of [...this.ui, ...this.stage]) {
      if (ws.isAlive === false) {
        ws.terminate();
        continue;
      }
      ws.isAlive = false;
      this.#send(ws, { type: 'ping' });
    }
  }

  /**
   * Presence has to be true on its own, without anyone doing anything: a
   * moderator who leaves the page open on a second monitor is still here, and
   * one whose laptop went to sleep is not. The pong of each control socket is
   * the proof, so it is what refreshes the moment somebody was last seen.
   */
  refreshPresence() {
    if (!this.activity) return;
    for (const ws of this.ui) {
      if (!ws.username || !ws.seenAt) continue;
      if (Date.now() - ws.seenAt < HEARTBEAT_MS * 2) continue;
      this.activity.connect(ws.username, ws.userRole);
    }
  }

  #send(ws, payload) {
    // Re-check user sessions before sending private workspace/history messages.
    if (ws.role === 'ui' && !this.auth.userPrincipal(ws.authRequest)) {
      ws.close(1008, 'sesion terminada');
      return;
    }
    ws.seenAt = Date.now();
    if (ws.readyState !== ws.OPEN) return;
    try {
      ws.send(JSON.stringify(payload));
    } catch {
      /* client vanished mid-send */
    }
  }

  broadcastState() {
    const controlPayload = { type: 'state', ...this.#statePayload() };
    const stagePayload = { type: 'state', ...this.#statePayload(true) };
    for (const ws of this.ui) this.#send(ws, controlPayload);
    for (const ws of this.stage) this.#send(ws, stagePayload);
    // The control page also needs the upload queue.
    const workspace = { type: 'workspace', ...this.#workspacePayload() };
    for (const ws of this.ui) this.#send(ws, workspace);
  }

  /**
   * Transform in flight: a moderator is dragging an object and OBS should show
   * it moving under the cursor. It goes to the stage and to the other control
   * pages, but it is not a state change, so nothing is written to disk and the
   * revision does not move. The drag ending sends the real update.
   */
  broadcastTransform(object) {
    if (!object) return;
    const payload = {
      type: 'transform',
      rev: this.store.rev,
      object: {
        id: object.id,
        scene: object.scene,
        x: object.x,
        y: object.y,
        w: object.w,
        h: object.h,
        rot: object.rot,
        opacity: object.opacity,
        z: object.z,
        visible: object.visible,
        locked: object.locked,
      },
    };
    for (const ws of [...this.ui, ...this.stage]) this.#send(ws, payload);
  }

  /**
   * The trail and the room. Only the control pages get it: neither the history
   * nor who is signed in has anything to do with what is on air.
   */
  #activityPayload() {
    return {
      type: 'activity',
      history: this.activity?.list(120) ?? [],
      moderators: this.activity?.accounts(this.users?.list() ?? []) ?? [],
    };
  }

  broadcastActivity() {
    const payload = this.#activityPayload();
    for (const ws of this.ui) this.#send(ws, payload);
  }

  broadcastScreens() {
    const payload = { type: 'agents', agents: this.store.listAgents(), rev: this.store.rev };
    for (const ws of [...this.ui, ...this.stage]) this.#send(ws, payload);
  }

  get stageCount() {
    return this.stage.size;
  }

  close() {
    clearInterval(this.heartbeat);
    for (const ws of [...this.ui, ...this.stage]) {
      try {
        ws.close(1001, 'server shutdown');
      } catch {
        /* ignore */
      }
    }
    this.wss.close();
  }
}
