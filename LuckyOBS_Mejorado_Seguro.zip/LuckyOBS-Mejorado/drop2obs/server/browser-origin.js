/**
 * Browser requests must originate from the same site as the panel. Reject
 * cross-site form submissions and WebSocket upgrades; command-line clients
 * without an Origin header can still use their explicit credentials.
 *
 * Only the public URL or the actual HTTP Host header may be trusted here.
 * Never trust a client-supplied X-Forwarded-Host value as an origin allowlist.
 */
export function browserOriginAllowed(req, publicUrl = '') {
  const supplied = req.headers?.origin;
  if (supplied === undefined) return true;
  if (typeof supplied !== 'string' || !supplied || supplied === 'null') return false;
  let origin;
  try {
    origin = new URL(supplied);
    if (!['http:', 'https:'].includes(origin.protocol)) return false;
    if (origin.origin !== supplied) return false;
  } catch {
    return false;
  }
  const expected = new Set();
  const host = req.headers?.host;
  if (typeof host === 'string' && host && !/[\s\/\\]/.test(host)) {
    expected.add(`http://${host}`);
    expected.add(`https://${host}`);
  }
  if (publicUrl) {
    try { expected.add(new URL(publicUrl).origin); } catch { /* invalid config */ }
  }
  return expected.has(origin.origin);
}
