import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import express from 'express';
import multer from 'multer';
import { Activity } from './activity.js';
import { browserOriginAllowed } from './browser-origin.js';
import { createAuth, safeEqual, signMedia } from './auth.js';
import { lanAddresses, loadConfig } from './config.js';
import { classify, imageSize, renderKind, sanitizeName } from './media.js';
import { Hub } from './realtime.js';
import { SCENES } from './scenes.js';
import { Store } from './state.js';
import { resolveBaseUrl } from './urls.js';
import {
  AuthError,
  LoginThrottle,
  UserStore,
  buildUserCookie,
  clearUserCookie,
  publicUser,
} from './users.js';

const COLORS = { info: '\u001b[36m', warn: '\u001b[33m', error: '\u001b[31m', ok: '\u001b[32m' };
const RESET = '\u001b[0m';

function makeLog(verbose = true) {
  return function log(level, message) {
    if (!verbose && level === 'info') return;
    const stamp = new Date().toISOString().slice(11, 19);
    const color = COLORS[level] ?? '';
    const stream = level === 'error' || level === 'warn' ? process.stderr : process.stdout;
    const line = `${stamp} ${color}${level.padEnd(5)}${RESET} ${message}\n`;
    try {
      // writeSync so nothing is lost when the process exits right after logging.
      fs.writeSync(stream.fd, line);
    } catch {
      stream.write(line);
    }
  };
}

const config = loadConfig();
const log = makeLog(config.logRequests);
const store = new Store(config, log);
/** What happened and who is around: one file, one write path. */
const activity = new Activity({
  dataDir: config.dataDir,
  log,
  limit: Math.max(50, Math.min(5000, config.history * 3)),
});
store.load();
activity.load();
const users = new UserStore({ config, log });
users.load();
users.watch();
const throttle = new LoginThrottle({
  maxPerUser: config.loginMaxPerUser,
  maxPerIp: config.loginMaxPerIp,
});
const auth = createAuth(config, { users, publicPaths: new Set(['/api/control/hidden']) });

/*
 * The key that lets a button on a desk hide the show.
 *
 * A stream deck is not a browser and cannot log in, so it needs a key of its
 * own. It is deliberately not the stage token: that one is pasted in the OBS of
 * whoever is broadcasting and stays read only, while this one only opens and
 * closes the show. It is created the first time the server runs and then kept in
 * the data directory, so a restart or a redeploy does not break the button.
 */
const CONTROL_KEY_FILE = path.join(config.dataDir, 'control.txt');
const controlKey = (() => {
  try {
    const found = fs.readFileSync(CONTROL_KEY_FILE, 'utf8').trim();
    if (found) return found;
  } catch {
    /* first run: there is nothing to read */
  }
  const made = crypto.randomBytes(18).toString('base64url');
  try {
    fs.mkdirSync(config.dataDir, { recursive: true });
    fs.writeFileSync(CONTROL_KEY_FILE, `${made}\n`, { mode: 0o600 });
  } catch (err) {
    log('warn', `could not store the control key: ${err.message}`);
  }
  return made;
})();

const app = express();
app.disable('x-powered-by');
// Only accept proxy headers from a proxy on this host, never from the internet.
if (config.trustProxy) app.set('trust proxy', 'loopback');
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: false, limit: '1mb' }));

/* ------------------------------ helpers ------------------------------ */

function baseUrlFor(req) {
  const proto =
    config.trustProxy && req.headers['x-forwarded-proto']
      ? String(req.headers['x-forwarded-proto']).split(',')[0].trim()
      : req.protocol;
  return resolveBaseUrl({
    publicUrl: config.publicUrl,
    fallback: `${proto}://${req.headers.host ?? `localhost:${config.port}`}`,
  });
}

function snapshotFor(req, includeUploads = false) {
  return store.snapshot({ baseUrl: baseUrlFor(req), includeUploads });
}

/* ----------------------------- middleware ---------------------------- */

app.use((req, res, next) => {
  res.setHeader('x-content-type-options', 'nosniff');
  res.setHeader('referrer-policy', 'no-referrer');
  res.setHeader('permissions-policy', 'camera=(), microphone=(), geolocation=()');
  next();
});

// API replies must not be stored by proxies or shared browsers.
app.use('/api', (req, res, next) => {
  res.setHeader('cache-control', 'no-store');
  next();
});

// Browsers always send an Origin header for cross-site writes. SameSite cookies
// and this check together prevent another site from operating the live show.
app.use((req, res, next) => {
  if (!['GET', 'HEAD', 'OPTIONS'].includes(req.method)
      && !browserOriginAllowed(req, config.publicUrl)) {
    res.status(403).json({ error: 'origin_not_allowed' });
    return;
  }
  next();
});

app.get('/healthz', (req, res) => {
  res.json({
    ok: true,
    rev: store.rev,
    objects: store.objects('program').length,
    screens: store.listAgents().filter((a) => a.online).length,
    uptime: Math.round(process.uptime()),
  });
});

// The stage fetches media without cookies, so media links carry an HMAC signature.
app.get('/media/:file', (req, res) => {
  const file = path.basename(String(req.params.file || ''));
  const provided = String(req.query.k ?? '');
  if (!file || !safeEqual(provided, signMedia(config.token, file))) {
    res.status(403).type('text/plain').send('forbidden');
    return;
  }
  const target = path.join(config.mediaDir, file);
  if (!target.startsWith(config.mediaDir + path.sep) || !fs.existsSync(target)) {
    res.status(404).type('text/plain').send('not found');
    return;
  }
  // Downloaded HTML/SVG must never become a trusted same-origin document:
  // even if someone opens a signed media link directly, it stays sandboxed.
  if (/\.(?:html?|svg)$/i.test(file)) {
    res.setHeader('content-security-policy', /\.svg$/i.test(file) ? 'sandbox' : 'sandbox allow-scripts');
  }
  res.setHeader('cache-control', 'private, max-age=31536000, immutable');
  // root + basename: sendFile refuses absolute paths that cross a dot segment,
  // and the data dir usually lives under ~/.local or ~/.config.
  res.sendFile(file, { root: config.mediaDir, acceptRanges: true, dotfiles: 'deny' }, (err) => {
    if (!err) return;
    log('error', `could not send ${file}: ${err.code ?? err.message}`);
    if (!res.headersSent) res.status(404).end();
  });
});

app.use(auth.middleware);

/* ----------------------------- access gates --------------------------- */

function isSignedIn(req) {
  return req.principal?.kind === 'user';
}

/** A signed in moderator, or the server token while no account exists. */
function canManage(req) {
  return isSignedIn(req) || req.principal?.manage === true;
}

/** Everything that changes the show needs a real signed in moderator. */
function requireUser(req, res, next) {
  if (canManage(req)) {
    next();
    return;
  }
  res.status(401).json({ error: 'login_required' });
}

function wantsHtml(req) {
  return String(req.headers.accept ?? '').includes('text/html');
}

/**
 * The moderator behind a change, for the history. Taken from the session, never
 * from the body, so a trail cannot be written in somebody else's name. While no
 * account exists the server token runs the show and shows as "token".
 */
function actorOf(req) {
  if (isSignedIn(req)) return req.principal.user.username;
  return 'token';
}

/** Like requireUser, but html browsers get the sign in page. */
function requireUserPage(req, res, next) {
  if (canManage(req)) {
    next();
    return;
  }
  if (wantsHtml(req)) {
    res.redirect(302, `/login?next=${encodeURIComponent(req.originalUrl || '/')}`);
    return;
  }
  res.status(401).json({ error: 'login_required' });
}

function requireAdmin(req, res, next) {
  if (req.principal?.manage === true) {
    next();
    return;
  }
  if (isSignedIn(req) && req.principal.user.role === 'admin') {
    next();
    return;
  }
  res.status(403).json({ error: 'admin_required' });
}

function clientIp(req) {
  return String(req.ip ?? req.socket?.remoteAddress ?? '').slice(0, 60);
}

/* --------------------------------- auth api --------------------------- */

function authPayload(req) {
  const user = req.principal?.user ?? null;
  return {
    user: publicUser(user),
    authenticated: Boolean(user),
    // With no accounts created yet, the server token is the only way in.
    tokenFallback: Boolean(user) === false && users.isBootstrap(),
  };
}

app.post('/api/auth/login', (req, res) => {
  const body = req.body ?? {};
  const username = String(body.username ?? '').trim();
  const password = String(body.password ?? '');
  const ip = clientIp(req);
  try {
    throttle.check(ip, username.toLowerCase());
  } catch (err) {
    log('warn', `login throttled for ${username || '?'} from ${ip}`);
    res.status(err.status ?? 429).json({ error: err.code, message: err.message });
    return;
  }

  const user = users.authenticate(username, password);
  if (!user) {
    throttle.fail(ip, username.toLowerCase());
    log('warn', `failed login for ${username || '(vacio)'} from ${ip}`);
    res.status(401).json({
      error: 'bad_credentials',
      message: 'Usuario o contraseña incorrectos.',
    });
    return;
  }
  throttle.clear(ip, username.toLowerCase());
  const session = users.createSession(user, { ip, userAgent: req.headers['user-agent'] ?? '' });
  res.setHeader('set-cookie', buildUserCookie(session.id, req.secure));
  log('info', `login: ${user.username} (${user.role}) from ${ip}`);
  res.json({ ...authPayload({ principal: { kind: 'user', user } }), session: { expiresAt: session.expiresAt } });
});

app.post('/api/auth/logout', (req, res) => {
  const id = auth.userCookieValue(req);
  if (id) users.destroySession(id);
  res.setHeader('set-cookie', clearUserCookie(req.secure));
  res.json({ ok: true });
});

app.get('/api/auth/me', (req, res) => {
  res.json(authPayload(req));
});

app.post('/api/auth/password', requireUser, (req, res) => {
  const body = req.body ?? {};
  try {
    users.changeOwnPassword(req.principal.user, body.current, body.next);
  } catch (err) {
    res.status(err.status ?? 400).json({ error: err.code, message: err.message });
    return;
  }
  res.setHeader('set-cookie', clearUserCookie(req.secure));
  res.json({ ok: true, message: 'Contraseña cambiada. Vuelve a entrar.' });
});

/* --------------------------- user management ------------------------- */

app.get('/api/auth/users', requireAdmin, (req, res) => {
  const sessions = users.listSessions();
  res.json({
    users: users.list().map((user) => ({
      ...publicUser(user),
      sessions: sessions.filter((s) => s.userId === user.id).length,
      lastIp: sessions.find((s) => s.userId === user.id)?.ip ?? '',
    })),
    // With no accounts at all the owner can still get in with the server token.
    bootstrap: users.isBootstrap(),
  });
});

app.post('/api/auth/users', requireAdmin, (req, res) => {
  const body = req.body ?? {};
  try {
    const user = users.create({
      username: body.username,
      password: body.password,
      role: body.role ?? 'mod',
      mustChangePassword: body.mustChangePassword !== false,
    });
    res.status(201).json({ user: publicUser(user) });
  } catch (err) {
    res.status(err.status ?? 400).json({ error: err.code, message: err.message });
  }
});

app.patch('/api/auth/users/:id', requireAdmin, (req, res) => {
  try {
    const user = users.update(req.params.id, req.body ?? {}, { actorId: req.principal.user?.id ?? null });
    res.json({ user: publicUser(user) });
  } catch (err) {
    res.status(err.status ?? 400).json({ error: err.code, message: err.message });
  }
});

app.delete('/api/auth/users/:id', requireAdmin, (req, res) => {
  try {
    users.delete(req.params.id, { actorId: req.principal.user.id });
    res.json({ ok: true });
  } catch (err) {
    res.status(err.status ?? 400).json({ error: err.code, message: err.message });
  }
});

/* -------------------------------- api -------------------------------- */

app.get('/api/state', (req, res) => {
  // A browser source that lost its socket falls back to polling, and it still
  // has to show up in the panel: without this the panel would report the OBS
  // source gone when the only thing wrong is that the live socket dropped.
  const stageId = String(req.query?.id ?? '').trim();
  if (stageId.length >= 4 && stageId.length <= 40 && /^[A-Za-z0-9_.:-]+$/.test(stageId)) {
    store.touchAgent(stageId, { kind: 'stage', name: 'Pantalla OBS', source: 'poll' });
  }
  // The OBS-only token can inspect what is on air, but not the prepared bank
  // or the private upload queue. Moderators still get the full workspace.
  const manager = canManage(req);
  const state = snapshotFor(req, manager);
  if (!manager && state.program) {
    state.program.objects = state.program.objects.filter((object) => object.y < state.cut);
  }
  res.json(state);
});

/*
 * Everything the control page needs to hand out the browser-source link.
 * The token is only exposed to an already authenticated session, and the
 * client builds the final url from its own origin so the friend gets the
 * address the operator is actually looking at (lan ip, tunnel, ...).
 */
/*
 * The stage token, and only for an administrator. A moderator does not need it:
 * the link is already pasted in the OBS of whoever is broadcasting, and handing
 * the token to everyone who can log in would spread a key that is read only but
 * permanent. This route used to be open to anybody who reached the port.
 */
app.get('/api/share', requireAdmin, (req, res) => {
  // The link goes to somebody else's machine, so it is built from the address
  // this server knows for itself and not from the one the moderator happens to
  // have open. Without this, copying the link from a laptop inside the house
  // gave the friend a private address that cannot work anywhere else.
  const base = baseUrlFor(req);
  res.json({
    stagePath: '/stage',
    publicUrl: base,
    stageUrl: `${base}/stage?t=${encodeURIComponent(config.token)}`,
    token: config.token,
    controlKey,
    controlUrl: `${base}/api/control/hidden?key=${encodeURIComponent(controlKey)}`,
    canvas: config.canvas,
    screen: config.screen,
    hints: {
      stageQuery: ['ui=1', 'fit=0.9', 'bg=1'],
      emptyCustomCss: true,
      muted: true,
    },
  });
});

const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, config.uploadTmpDir),
    filename: (req, file, cb) => cb(null, `tmp-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`),
  }),
  limits: { fileSize: config.maxUploadMb * 1024 * 1024, files: 12, fields: 8 },
});

app.post('/api/upload', requireUser, (req, res) => {
  upload.array('files', 12)(req, res, (err) => {
    if (err) {
      const code = err.code === 'LIMIT_FILE_SIZE' ? 413 : 400;
      log('warn', `upload rejected: ${err.message}`);
      res.status(code).json({ error: err.code === 'LIMIT_FILE_SIZE' ? 'file_too_large' : 'upload_failed', detail: err.message });
      return;
    }
    const files = req.files ?? [];
    if (!files.length) {
      res.status(400).json({ error: 'no_files' });
      return;
    }
    const created = [];
    const rejected = [];
    for (const file of files) {
      try {
        const { name, ext } = sanitizeName(file.originalname);
        const kind = classify(file.originalname, file.mimetype);
        const upload = store.addUpload({
          originalName: name,
          size: file.size,
          mime: file.mimetype,
          ext,
          kind,
          render: renderKind(file.originalname, file.mimetype),
        });
        const target = store.filePath(upload.file);
        fs.renameSync(file.path, target);
        const dims = kind === 'image' ? imageSize(target) : null;
        if (dims) {
          upload.width = dims.width;
          upload.height = dims.height;
        }
        created.push(upload);
        log('info', `uploaded ${name} (${(file.size / 1048576).toFixed(1)} MiB, ${kind})`);
      } catch (err) {
        rejected.push({ name: file.originalname, error: err.message });
        log('warn', `could not store ${file.originalname}: ${err.message}`);
        try {
          fs.unlinkSync(file.path);
        } catch {
          /* ignore */
        }
      }
    }
    if (!created.length) {
      res.status(500).json({ error: 'upload_failed', rejected });
      return;
    }
    store.save();
    for (const up of created) {
      activity.record({ action: 'subido', name: up.name, who: actorOf(req), detail: up.kind });
    }
    res.json({ uploads: created, rejected, rev: store.rev });
  });
});

app.post('/api/push', requireUser, (req, res) => {
  const ids = Array.isArray(req.body?.ids) ? req.body.ids.filter((v) => typeof v === 'string') : [];
  if (!ids.length) {
    res.status(400).json({ error: 'no_ids' });
    return;
  }
  const missing = ids.filter((id) => !store.getUpload(id));
  if (missing.length) {
    res.status(400).json({ error: 'unknown_upload', missing });
    return;
  }
  const created = store.push(ids);
  if (!created.length) {
    res.status(400).json({ error: 'nothing_to_push' });
    return;
  }
  log('ok', `sent ${created.length} file(s) to the bank`);
  res.json({ pushed: created, workspace: store.workspace({ baseUrl: baseUrlFor(req) }) });
});

/* ----------------------------- scenes api ------------------------------ */

app.get('/api/workspace', requireUser, (req, res) => {
  res.json(store.workspace({ baseUrl: baseUrlFor(req) }));
});

/**
 * Drops a file that is still waiting in the queue onto a screen. That is the
 * whole "drag from my computer onto the screen" gesture, in one request.
 */
app.post('/api/scenes/:scene/place', requireUser, (req, res) => {
  const scene = req.params.scene;
  if (!SCENES.includes(scene)) {
    res.status(400).json({ error: 'unknown_scene' });
    return;
  }
  const ids = (Array.isArray(req.body?.ids) ? req.body.ids : [req.body?.uploadId])
    .filter((v) => typeof v === 'string' && v);
  if (!ids.length) {
    res.status(400).json({ error: 'no_ids' });
    return;
  }
  const missing = ids.filter((id) => !store.getUpload(id));
  if (missing.length) {
    res.status(400).json({ error: 'unknown_upload', missing });
    return;
  }
  const placed = [];
  for (const id of ids) {
    const object = store.placeUpload(id, {
      scene,
      x: req.body?.x,
      y: req.body?.y,
      w: req.body?.w,
      h: req.body?.h,
    });
    if (object) placed.push(object);
  }
  if (!placed.length) {
    res.status(400).json({ error: 'nothing_placed' });
    return;
  }
  log('ok', `placed ${placed.length} file(s) on ${scene}`);
  for (const object of placed) {
    activity.record({
      action: store.isAir(object.y) ? 'en directo' : 'al banco',
      name: object.name,
      who: actorOf(req),
      detail: store.isAir(object.y) ? 'colocado sobre la linea' : 'colocado bajo la linea',
    });
  }
  res.json({ objects: placed.map((o) => store.publicObject(baseUrlFor(req), o)), workspace: store.workspace({ baseUrl: baseUrlFor(req) }) });
});

/*
 * An object made out of nothing: a text on the screen. Everything else comes
 * from a file that was uploaded, and this is the one kind that carries its own
 * content, so it needs no file. The words and the look are sanitised by the
 * store, not here.
 */
app.post('/api/objects', requireUser, (req, res) => {
  const scene = req.body?.scene;
  if (!SCENES.includes(scene)) {
    res.status(400).json({ error: 'unknown_scene' });
    return;
  }
  const wantsText = req.body?.render === 'text';
  const object = store.createObject({
    scene,
    file: typeof req.body?.file === 'string' ? req.body.file : '',
    name: typeof req.body?.name === 'string' ? req.body.name : (wantsText ? 'Texto' : 'objeto'),
    render: wantsText ? 'text' : req.body?.render,
    kind: req.body?.kind,
    text: req.body?.text,
    textFont: req.body?.textFont,
    textSize: req.body?.textSize,
    textColor: req.body?.textColor,
    textAlign: req.body?.textAlign,
    x: req.body?.x,
    y: req.body?.y,
    w: req.body?.w,
    h: req.body?.h,
    rot: req.body?.rot,
  });
  // Only a request that asked for a text may go without a file. Checking the
  // saved render instead would let anything whose name is not a known extension
  // slip through, since an unknown name falls back to a text on its own.
  if (!object.file && !wantsText) {
    res.status(400).json({ error: 'no_file' });
    return;
  }
  res.status(201).json({ object: store.publicObject(baseUrlFor(req), object), rev: store.rev });
});

/*
 * The transform endpoint. It accepts a partial body so the control page can send
 * only the field that changed while a drag is in progress, and it is the call
 * that makes a move show up in OBS the moment the moderator lets go.
 */
app.patch('/api/objects/:id', requireUser, (req, res) => {
  const object = store.updateObject(req.params.id, req.body ?? {});
  if (!object) {
    res.status(404).json({ error: 'not_found' });
    return;
  }
  res.json({ object: store.publicObject(baseUrlFor(req), object), rev: store.rev });
});

/*
 * A drag in progress. It moves the object for everyone watching, including OBS,
 * but keeps no trace on disk: the PATCH above is what actually saves it.
 */
app.patch('/api/objects/:id/transform', requireUser, (req, res) => {
  const object = store.previewObject(req.params.id, req.body ?? {});
  if (!object) {
    res.status(404).json({ error: 'not_found' });
    return;
  }
  hub.broadcastTransform(object);
  res.json({ object: store.publicObject(baseUrlFor(req), object), rev: store.rev });
});

app.post('/api/objects/:id/duplicate', requireUser, (req, res) => {
  const copy = store.duplicateObject(req.params.id);
  if (!copy) {
    res.status(404).json({ error: 'not_found' });
    return;
  }
  res.status(201).json({ object: store.publicObject(baseUrlFor(req), copy), rev: store.rev });
});

app.post('/api/objects/:id/order', requireUser, (req, res) => {
  const direction = String(req.body?.direction ?? '');
  if (!['front', 'back', 'up', 'down'].includes(direction)) {
    res.status(400).json({ error: 'bad_direction' });
    return;
  }
  const object = store.reorderObject(req.params.id, direction);
  if (!object) {
    res.status(404).json({ error: 'not_found' });
    return;
  }
  res.json({ objects: store.objects(object.scene).map((o) => store.publicObject(baseUrlFor(req), o)), rev: store.rev });
});

app.delete('/api/objects/:id', requireUser, (req, res) => {
  const removeFiles = req.query?.files === undefined ? config.deleteOnClear : req.query.files === '1';
  const going = store.findObject(req.params.id);
  const ok = store.removeObject(req.params.id, { deleteFile: removeFiles });
  if (!ok) {
    res.status(404).json({ error: 'not_found' });
    return;
  }
  activity.record({ action: 'quitado', name: going?.name ?? req.params.id, who: actorOf(req) });
  log('info', `removed object ${req.params.id}`);
  res.json({ ok: true, rev: store.rev });
});

app.delete('/api/scenes/:scene', requireUser, (req, res) => {
  const scene = req.params.scene;
  if (!SCENES.includes(scene)) {
    res.status(400).json({ error: 'unknown_scene' });
    return;
  }
  const removeFiles = req.query?.files === undefined ? config.deleteOnClear : req.query.files === '1';
  const removed = store.clearScene(scene, { deleteFiles: removeFiles });
  if (removed) activity.record({ action: 'pantalla vaciada', who: actorOf(req), detail: `${removed} objeto(s)` });
  log('ok', `cleared ${removed} object(s) from ${scene}`);
  res.json({ removed, rev: store.rev });
});

/**
 * "Vaciar el banco" as its own route: it only takes the lower half of the
 * screen off, leaving what is on air untouched. Without this the button would
 * have to clear the whole screen and a mistimed click would cut the stream.
 */
app.delete('/api/bank', requireUser, (req, res) => {
  const removeFiles = req.query?.files === undefined ? config.deleteOnClear : req.query.files === '1';
  const removed = store.clearBank({ deleteFiles: removeFiles });
  if (removed) activity.record({ action: 'banco vaciado', who: actorOf(req), detail: `${removed} objeto(s)` });
  log('ok', `cleared ${removed} object(s) from the bank`);
  res.json({ removed, rev: store.rev });
});

/*
 * The one switch that takes everything off the air. It is not an edit: nothing
 * is deleted or moved, the source is only told to draw nothing and to keep
 * quiet, so turning it back on gives back the same show.
 *
 * Administrators only, and that is not a shortcut: a moderator moves things
 * around all day, and cutting the picture is the owner's call or the deck's. The
 * deck does not come through here, it has its own route below.
 */
app.post('/api/hidden', requireAdmin, (req, res) => {
  const asked = req.body?.hidden;
  const hidden = store.setHidden(asked === undefined ? !store.hidden : asked === true);
  log('ok', `show ${hidden ? 'hidden' : 'visible'} by ${actorOf(req)}`);
  res.json({ hidden, rev: store.rev });
});

/*
 * The same switch for the stream deck, and only for whoever holds the control
 * key. A GET toggles, because that is what a one line url in a deck button can
 * do; a POST can also set the state outright, which is what a button with an
 * "on" and an "off" needs. No session, no cookie, no browser.
 */
function requireControlKey(req, res, next) {
  const header = req.headers['x-d2o-control'];
  const given = (typeof header === 'string' && header) || req.query?.key || '';
  if (!given || !safeEqual(String(given).trim(), controlKey)) {
    res.status(401).json({ error: 'bad_control_key' });
    return;
  }
  next();
}

function setHiddenFromControl(req, res) {
  const asked = req.body?.hidden;
  const hidden = store.setHidden(asked === undefined ? !store.hidden : asked === true);
  log('ok', `show ${hidden ? 'hidden' : 'visible'} from the stream deck`);
  res.json({ hidden, rev: store.rev });
}

app.get('/api/control/hidden', requireControlKey, setHiddenFromControl);
app.post('/api/control/hidden', requireControlKey, setHiddenFromControl);

/** The trail of what went in and out, newest first. */
app.get('/api/history', requireUser, (req, res) => {
  const limit = Math.min(500, Math.max(1, Number(req.query?.limit) || 200));
  res.json({ history: activity.list(limit), moderators: activity.accounts(users.list()) });
});

/** Only an administrator empties the trail: it is there to account for a show. */
app.delete('/api/history', requireAdmin, (req, res) => {
  const removed = activity.clear();
  log('ok', `history cleared (${removed} entries)`);
  res.json({ removed, rev: store.rev });
});

// The sign in page, and the stage: what the friend pastes into OBS.
app.get('/login', (req, res) => {
  if (req.principal?.kind === 'user') {
    res.redirect(302, '/');
    return;
  }
  res.sendFile(path.join(config.publicDir, 'login.html'), { etag: true, maxAge: 0 });
});

app.get('/stage', (req, res) => {
  // The empty shell is served whatever the link says. It holds nothing: the
  // scene, the media and the socket are all still behind the token. Serving it
  // to a stale link is what lets the page say "this link has expired" in red
  // on the stream, instead of leaving a black rectangle with no explanation.
  res.sendFile(path.join(config.publicDir, 'stage.html'), { etag: true, maxAge: 0 });
});

/**
 * The control page itself. Assets stay public to the static handler so the
 * stage and the login page can load their css and js with just their own
 * cookie, but the page is only served to a signed in moderator.
 */
function sendAppPage(req, res) {
  res.sendFile(path.join(config.publicDir, 'index.html'), { etag: true, maxAge: 0 });
}

app.get('/', requireUserPage, sendAppPage);
app.get('/index.html', requireUserPage, sendAppPage);
app.use(
  express.static(config.publicDir, {
    index: false,
    maxAge: 0,
    etag: true,
    // This is deployed by copying files by hand, so a stale app.js in the
    // browser is a real hazard: never let one be reused.
    setHeaders(res, filePath) {
      if (/\.(?:html|js|css)$/.test(filePath)) res.setHeader('cache-control', 'no-store');
    },
  }),
);

app.use((req, res) => {
  res.status(404).json({ error: 'not_found' });
});

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  log('error', `unhandled: ${err?.stack ?? err}`);
  if (res.headersSent) return;
  res.status(500).json({ error: 'internal_error' });
});

/* ------------------------------- boot -------------------------------- */

const hub = new Hub({ config, store, log, auth, activity, users });
store.onChange = () => hub.broadcastState();
// A new line in the trail, or somebody opening the page, only concerns the
// control pages: the stage has no use for either.
activity.onChange = () => hub.broadcastActivity();

const server = app.listen(config.port, config.host, () => {
  const lines = [
    '',
    `  ${COLORS.ok}LuckyOBS${RESET} listening on http://localhost:${config.port}`,
  ];
  for (const ip of lanAddresses()) {
    lines.push(`  LAN:      http://${ip}:${config.port}/`);
  }
  lines.push(`  Mobile:   http://${lanAddresses()[0] ?? 'localhost'}:${config.port}/`);
  if (config.publicUrl) lines.push(`  Public:   ${config.publicUrl}/`);
  lines.push(`  Data dir: ${config.dataDir}`);
  lines.push(`  Stage credentials stored privately in ${config.tokenFile}`);
  lines.push(`  Max file: ${config.maxUploadMb} MiB`);
  lines.push('');
  process.stdout.write(`${lines.join('\n')}\n`);
  log('info', 'ready');
});

server.on('upgrade', (req, socket, head) => {
  let url;
  try {
    url = new URL(req.url, `http://${req.headers.host ?? 'localhost'}`);
  } catch {
    socket.destroy();
    return;
  }
  hub.handleUpgrade(req, socket, head, url);
});

server.headersTimeout = 120000;
server.requestTimeout = 0;

const shutdown = (signal) => {
  users.stopWatching();
  log('info', `received ${signal}, shutting down`);
  try {
    store.save({ immediate: true });
    // El rastro se escribe con retardo, asi que sin esto se perdia justo lo
    // que paso en los ultimos milisegundos antes de parar el servicio.
    activity.save({ immediate: true });
  } catch {
    /* ignore */
  }
  hub.close();
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 3000).unref();
};
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('uncaughtException', (err) => log('error', `uncaught: ${err.stack ?? err}`));
process.on('unhandledRejection', (err) => log('error', `unhandled rejection: ${err?.stack ?? err}`));

setInterval(() => {
  if (store.pruneUploads()) log('info', 'pruned expired uploads');
  hub.broadcastScreens();
}, 60000).unref();
