import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

const IMAGE_EXT = new Set([
  '.png', '.jpg', '.jpeg', '.jfif', '.bmp', '.dds', '.tga', '.tiff', '.tif',
  '.webp', '.ico', '.ppm', '.hdr', '.exr', '.svg', '.avif', '.jxl', '.qoi',
]);
// Chromium animates these on its own, so the stage can use a plain <img>.
const ANIMATED_IMAGE_EXT = new Set(['.gif', '.apng', '.webp']);
const MEDIA_EXT = new Set([
  '.mp4', '.m4v', '.mkv', '.mov', '.webm', '.avi', '.flv', '.wmv', '.mpg', '.mpeg',
  '.ogv', '.ts', '.m2ts', '.mts', '.3gp', '.rm', '.vob', '.divx',
  '.mp3', '.wav', '.ogg', '.oga', '.flac', '.aac', '.m4a', '.opus', '.wma', '.aiff',
]);
const BROWSER_EXT = new Set([
  '.html', '.htm', '.txt', '.md', '.json', '.csv', '.xml', '.pdf', '.glsl', '.frag',
  '.vert', '.comp', '.frag', '.vert', '.glsl',
]);

const HTML_EXT = new Set(['.html', '.htm']);
const AUDIO_EXT = new Set([
  '.mp3', '.wav', '.ogg', '.oga', '.flac', '.aac', '.m4a', '.opus', '.wma', '.aiff', '.aif',
]);

/**
 * Whether a file is only sound. An mp3 in a <video> plays and shows nothing at
 * all, which on a stream looks like a broken object, so these are drawn as an
 * audio card instead of being left invisible.
 */
export function isAudioOnly(filename = '', mime = '') {
  const ext = path.extname(String(filename ?? '')).toLowerCase();
  if (AUDIO_EXT.has(ext)) return true;
  if (ext && MEDIA_EXT.has(ext)) return false;
  return String(mime ?? '').toLowerCase().startsWith('audio/');
}

/** Coarse family, used for icons and filters in the control page. */
export function classify(filename, mime = '') {
  const ext = path.extname(filename || '').toLowerCase();
  if (IMAGE_EXT.has(ext) || ANIMATED_IMAGE_EXT.has(ext)) return 'image';
  if (MEDIA_EXT.has(ext)) return 'video';
  if (BROWSER_EXT.has(ext)) return 'browser';
  if (mime.startsWith('image/')) return 'image';
  if (mime.startsWith('video/') || mime.startsWith('audio/')) return 'video';
  return 'browser';
}

/**
 * How the stage page (the browser source inside OBS) should draw each layer:
 * image -> <img>, media -> <video>, html -> sandboxed <iframe>, text -> <pre>.
 * Animated images are plain <img>: Chromium animates gif, webp and apng itself.
 */
export function renderKind(filename, mime = '') {
  const ext = path.extname(filename || '').toLowerCase();
  if (IMAGE_EXT.has(ext) || ANIMATED_IMAGE_EXT.has(ext)) return 'image';
  if (mime.startsWith('image/')) return 'image';
  if (HTML_EXT.has(ext) || mime === 'text/html') return 'html';
  if (MEDIA_EXT.has(ext) || mime.startsWith('video/') || mime.startsWith('audio/')) return 'media';
  return 'text';
}

export function sanitizeName(original) {
  const base = path.basename(String(original || 'archivo'));
  const ext = path.extname(base).toLowerCase();
  const stem = path
    .basename(base, path.extname(base))
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^\w.\- ]+/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 80);
  const safeStem = stem.length ? stem : 'archivo';
  const safeExt = /^\.[a-z0-9]{1,12}$/.test(ext) ? ext : '';
  return { name: `${safeStem}${safeExt}`, ext: safeExt };
}

export function newMediaId() {
  return `${Date.now().toString(36)}${crypto.randomBytes(6).toString('hex')}`;
}

function readExactly(fd, length, position) {
  const buf = Buffer.alloc(length);
  let filled = 0;
  // Some network/fuse filesystems return short reads, so loop until full or EOF.
  while (filled < length) {
    const { bytesRead } = fs.readSync(fd, buf, filled, length - filled, position + filled);
    if (bytesRead <= 0) break;
    filled += bytesRead;
  }
  if (filled === 0) throw new Error('nothing read');
  if (filled < length) throw new Error('short read');
  return buf;
}

/** Best-effort intrinsic size lookup for still images (no dependencies). */
export function imageSize(filePath) {
  let fd;
  try {
    fd = fs.openSync(filePath, 'r');
    const head = readExactly(fd, Math.min(64 * 1024, Math.max(1, fs.fstatSync(fd).size)), 0);

    // PNG
    if (head.length > 24 && head.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) {
      return { width: head.readUInt32BE(16), height: head.readUInt32BE(20) };
    }
    // GIF
    if (head.length > 10 && head.subarray(0, 3).toString('latin1') === 'GIF') {
      return { width: head.readUInt16LE(6), height: head.readUInt16LE(8) };
    }
    // BMP
    if (head.length > 26 && head.subarray(0, 2).toString('latin1') === 'BM') {
      return { width: Math.abs(head.readInt32LE(18)), height: Math.abs(head.readInt32LE(22)) };
    }
    // WEBP (VP8X / VP8 / VP8L)
    if (head.length > 30 && head.subarray(0, 4).toString('latin1') === 'RIFF' && head.subarray(8, 12).toString('latin1') === 'WEBP') {
      const chunk = head.subarray(12, 16).toString('latin1');
      if (chunk === 'VP8X') {
        const w = 1 + (head[24] | (head[25] << 8) | (head[26] << 16));
        const h = 1 + (head[27] | (head[28] << 8) | (head[29] << 16));
        return { width: w, height: h };
      }
      if (chunk === 'VP8 ') {
        return {
          width: head.readUInt16LE(26) & 0x3fff,
          height: head.readUInt16LE(28) & 0x3fff,
        };
      }
      if (chunk === 'VP8L') {
        const bits = head.readUInt32LE(21);
        return { width: (bits & 0x3fff) + 1, height: ((bits >> 14) & 0x3fff) + 1 };
      }
    }
    // QOI
    if (head.length > 14 && head.subarray(0, 4).toString('latin1') === 'qoif') {
      return {
        width: head.readUInt32BE(4) + 1,
        height: head.readUInt32BE(8) + 1,
      };
    }
    // JPEG
    if (head.length > 4 && head[0] === 0xff && head[1] === 0xd8) {
      let offset = 2;
      while (offset + 9 < head.length) {
        if (head[offset] !== 0xff) {
          offset += 1;
          continue;
        }
        const marker = head[offset + 1];
        if (marker === 0xd8 || marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) {
          offset += 2;
          continue;
        }
        const segLen = head.readUInt16BE(offset + 2);
        const isSof = marker >= 0xc0 && marker <= 0xcf && marker !== 0xc4 && marker !== 0xc8 && marker !== 0xcc;
        if (isSof) {
          return {
            height: head.readUInt16BE(offset + 5),
            width: head.readUInt16BE(offset + 7),
          };
        }
        if (segLen < 2) break;
        offset += 2 + segLen;
      }
    }
    // SVG (width/height attributes or viewBox)
    if (head.length > 5 && /<svg[\s>]/i.test(head.subarray(0, 2048).toString('utf8'))) {
      const text = head.toString('utf8');
      const wMatch = /\bwidth\s*=\s*["']?\s*([\d.]+)/i.exec(text);
      const hMatch = /\bheight\s*=\s*["']?\s*([\d.]+)/i.exec(text);
      if (wMatch && hMatch) return { width: Math.round(+wMatch[1]), height: Math.round(+hMatch[1]) };
      const vb = /\bviewBox\s*=\s*["']\s*[\d.-]+[\s,]+[\d.-]+[\s,]+([\d.]+)[\s,]+([\d.]+)/i.exec(text);
      if (vb) return { width: Math.round(+vb[1]), height: Math.round(+vb[2]) };
    }
    return null;
  } catch {
    return null;
  } finally {
    if (fd !== undefined) {
      try {
        fs.closeSync(fd);
      } catch {
        /* ignore */
      }
    }
  }
}

export function mediaFileName(id, ext) {
  return `${id}${ext || ''}`;
}
