import fs from 'node:fs';
import path from 'node:path';
import { signMedia } from './auth.js';
import { canvasSize } from './config.js';
import { isAudioOnly, mediaFileName, newMediaId, renderKind } from './media.js';
import {
  SCENES,
  bottomZ,
  emptyScene,
  migrateLegacyLayers,
  TEXT_FONTS,
  sanitizeObject,
  sanitizeScene,
  sortObjects,
  textFontStack,
  topZ,
} from './scenes.js';

function nowIso() {
  return new Date().toISOString();
}

function safeUnlink(filePath) {
  try {
    fs.unlinkSync(filePath);
    return true;
  } catch {
    return false;
  }
}

export class Store {
  constructor(config, log = () => {}) {
    this.config = config;
    this.log = log;
    this.rev = 0;
    this.seq = 0;
    this.layers = [];
    this.uploads = new Map();
    this.agents = new Map();
    /** In flight drag frames, by object id. Never written to disk. */
    this.live = new Map();
    this.scenes = {
      program: emptyScene('program', this.canvas),
    };
    /*
     * The one switch that takes the whole show off the air without touching a
     * single object: nothing is drawn and nothing is heard. It is a setting of
     * the show, not an edit, so a moderator can bring everything back exactly
     * as it was. This is what the stream deck toggles.
     */
    this.hidden = false;
    this.saveTimer = null;
    this.onChange = () => {};
  }

  /** The long screen as numbers, so the geometry never has to parse a string. */
  get canvas() {
    return canvasSize(this.config.screen);
  }

  /** What the audience sees: the top half of the long screen. */
  get air() {
    return this.config.air;
  }

  /** The y where emission ends and the bank starts. */
  get cut() {
    return this.config.air.height;
  }

  /** True when a point on the long screen is in the part that goes out. */
  isAir(y) {
    return Number(y) < this.cut;
  }

  load() {
    this.live.clear();
    let raw;
    try {
      raw = JSON.parse(fs.readFileSync(this.config.stateFile, 'utf8'));
    } catch {
      raw = null;
    }
    if (raw && typeof raw === 'object') {
      this.rev = Number.isFinite(raw.rev) ? raw.rev : 0;
      this.seq = Number.isFinite(raw.seq) ? raw.seq : 0;
      this.layers = Array.isArray(raw.layers) ? raw.layers.filter((l) => l && l.file) : [];
      for (const up of Array.isArray(raw.uploads) ? raw.uploads : []) {
        if (up && up.id) this.uploads.set(up.id, up);
      }
      // States written before the stage existed have no render hint: fill it in
      // from the file name so a restart never shows a video as plain text.
      let backfilled = false;
      for (const layer of [...this.layers, ...this.uploads.values()]) {
        if (layer.render) continue;
        layer.render = renderKind(layer.name, layer.mime);
        backfilled = true;
      }
      if (typeof raw.hidden === 'boolean') this.hidden = raw.hidden;
      this.loadScenes(raw, backfilled);
    }
    this.pruneUploads();
    this.garbageCollect();
  }

  /**
   * Reads the scene map, migrating whatever an older install had.
   *
   * A state file from before the long screen carries two scenes that share a y
   * range. The emission half keeps its numbers untouched and the bank half slides
   * down by exactly the cut, so what was on air stays on air and what was being
   * prepared stays in the bank, without either of them moving on screen. A state
   * file with no scenes at all keeps its flat layer list and turns it into
   * program objects, so an upgrade never blanks the stream either.
   */
  loadScenes(raw, backfilled) {
    const canvas = this.canvas;
    const hasScenes = raw.scenes && typeof raw.scenes === 'object';
    const program = hasScenes
      ? sanitizeScene(raw.scenes.program, 'program', canvas)
      : { ...emptyScene('program', canvas), objects: migrateLegacyLayers(this.layers, canvas) };
    const moved = this.bankIntoScreen(program, raw.scenes?.desk, canvas);
    this.scenes = { program };
    if (moved) {
      this.log('info', `movidos ${moved} objeto(s) del banco a la mitad inferior de la pantalla`);
    }
    if (!hasScenes && this.layers.length) {
      this.log('info', `migrated ${this.layers.length} layer(s) into the program scene`);
    }
    this.layers = [];
    if (!hasScenes || backfilled || moved) {
      this.rev += 1;
      // Written straight back, so the file on disk describes the model the
      // server is actually running instead of waiting for the next change to
      // push the migration out. The migration only reads what is missing, so
      // rewriting it early can never shift anything twice.
      this.save({ immediate: true });
    }
  }

  /**
   * Folds a stored bank scene into the lower half of the one long screen. The
   * y of every object moves down by the cut, which is what puts it back where
   * it was drawn from the moderator's point of view. Clamped afterwards so a
   * box that would hang off the bottom is pulled inside instead of vanishing.
   */
  bankIntoScreen(program, desk, canvas) {
    const list = sanitizeScene(desk, 'program', canvas).objects;
    if (!list.length) return 0;
    const cut = this.cut;
    let moved = 0;
    for (const object of list) {
      const height = Math.min(object.h, cut);
      const y = Math.min(object.y + cut, canvas.height - height);
      const x = Math.min(object.x, Math.max(0, canvas.width - object.w));
      program.objects.push(sanitizeObject({ ...object, scene: 'program', x, y, h: height }, {
        ...canvas,
        scene: 'program',
        fallbackZ: topZ(program) + 1,
      }));
      moved += 1;
    }
    return moved;
  }

  save({ immediate = false } = {}) {
    if (this.saveTimer) {
      clearTimeout(this.saveTimer);
      this.saveTimer = null;
    }
    const write = () => {
      this.saveTimer = null;
      const payload = {
        rev: this.rev,
        seq: this.seq,
        savedAt: nowIso(),
        scenes: this.scenes,
        uploads: [...this.uploads.values()],
        hidden: this.hidden,
      };
      const tmp = `${this.config.stateFile}.${process.pid}.tmp`;
      try {
        fs.writeFileSync(tmp, JSON.stringify(payload, null, 2));
        fs.renameSync(tmp, this.config.stateFile);
      } catch (err) {
        safeUnlink(tmp);
        this.log('error', `could not persist state: ${err.message}`);
      }
    };
    if (immediate) write();
    else this.saveTimer = setTimeout(write, 250);
  }

  bump() {
    this.rev += 1;
    this.save();
    this.onChange(this.rev);
  }

  filePath(file) {
    return path.join(this.config.mediaDir, file);
  }

  /* ----------------------------- uploads ----------------------------- */

  addUpload({ originalName, size, mime, ext, kind, render, width, height }) {
    const id = newMediaId();
    const file = mediaFileName(id, ext);
    this.uploads.set(id, {
      id,
      file,
      name: originalName,
      size,
      mime: mime || '',
      kind: kind || 'browser',
      render: render || renderKind(originalName, mime),
      width: width || null,
      height: height || null,
      uploadedAt: nowIso(),
      expiresAt: new Date(Date.now() + this.config.uploadTtlHours * 3600 * 1000).toISOString(),
    });
    this.bump();
    return this.uploads.get(id);
  }

  getUpload(id) {
    return this.uploads.get(id) ?? null;
  }

  forgetUpload(id) {
    return this.uploads.delete(id);
  }

  pruneUploads() {
    const now = Date.now();
    let changed = false;
    for (const [id, up] of this.uploads) {
      if (!up.expiresAt) continue;
      if (Date.parse(up.expiresAt) <= now) {
        // Keep the file if a placed object still points at it.
        if (!this.findObjectByUpload(id)) safeUnlink(this.filePath(up.file));
        this.uploads.delete(id);
        changed = true;
      }
    }
    if (changed) this.save({ immediate: true });
    return changed;
  }

  /* ----------------------------- scenes -------------------------------- */

  scene(id) {
    return this.scenes[id] ?? null;
  }

  /** Every object in a scene, bottom to top, ready to be drawn. */
  objects(id) {
    const scene = this.scenes[id];
    if (!scene) return [];
    return sortObjects(scene);
  }

  findObject(id) {
    if (typeof id !== 'string' || !id) return null;
    for (const sceneId of SCENES) {
      const found = this.scenes[sceneId].objects.find((o) => o.id === id);
      if (found) return found;
    }
    return null;
  }

  findObjectByUpload(uploadId) {
    for (const sceneId of SCENES) {
      const found = this.scenes[sceneId].objects.find((o) => o.uploadId === uploadId);
      if (found) return found;
    }
    return null;
  }

  sceneOf(object) {
    return this.scenes[object.scene] ?? null;
  }

  /**
   * Places a staged upload as an object. `x`/`y` are the top left corner in
   * screen pixels; when the caller does not know the media size the object lands
   * centred, which is what dropping a file in the middle of a screen should do.
   * Without a position it lands centred in the bank, never on air by accident.
   */
  placeUpload(uploadId, { scene = 'program', x, y, w, h, name } = {}) {
    const up = this.uploads.get(uploadId);
    const sceneRef = this.scenes[scene] ?? this.scenes.program;
    if (!up) return null;
    const naturalW = up.width || null;
    const naturalH = up.height || null;
    // An audio file has no size of its own, and forty percent of the screen is an
    // enormous box for a name and five bars: it gets a card of its own.
    const audio = isAudioOnly(up.name, up.mime);
    const width = Number.isFinite(w) && w > 0 ? w : naturalW || (audio ? 560 : this.canvas.width * 0.4);
    const height = Number.isFinite(h) && h > 0 ? h : naturalH || (audio ? 150 : this.cut * 0.4);
    this.seq += 1;
    const object = sanitizeObject(
      {
        id: newMediaId(),
        scene: sceneRef.id,
        uploadId: up.id,
        file: up.file,
        name: name || up.name,
        kind: up.kind,
        render: up.render ?? renderKind(up.name, up.mime),
        ext: path.extname(up.name),
        mime: up.mime,
        size: up.size,
        naturalWidth: naturalW,
        naturalHeight: naturalH,
        x: Number.isFinite(x) ? x : (this.canvas.width - width) / 2,
        y: Number.isFinite(y) ? y : this.cut + (this.cut - height) / 2,
        w: width,
        h: height,
        rot: 0,
        z: topZ(sceneRef) + 1,
        visible: true,
        addedAt: nowIso(),
      },
      { ...this.canvas, cut: this.cut, scene: sceneRef.id, fallbackZ: topZ(sceneRef) + 1 },
    );
    sceneRef.objects.push(object);
    // The file now lives on inside a scene, so it leaves the staging queue.
    this.forgetUpload(uploadId);
    this.bump();
    return object;
  }

  /**
   * Creates an object straight from a file already on disk, used by the API when
   * a moderator drops a file on a screen and wants it placed right away.
   */
  createObject(input) {
    const scene = SCENES.includes(input.scene) ? input.scene : SCENES[0];
    const sceneRef = this.scenes[scene];
    this.seq += 1;
    const object = sanitizeObject(
      { ...input, id: input.id || newMediaId(), scene, z: topZ(sceneRef) + 1, addedAt: nowIso() },
      { ...this.canvas, cut: this.cut, scene, fallbackZ: topZ(sceneRef) + 1 },
    );
    sceneRef.objects.push(object);
    this.bump();
    return object;
  }

  /**
   * Applies a partial update. Only known transform fields are accepted, so a
   * request can never inject new keys into the saved state. Moving an object
   * between screens is just a change of `scene`.
   */
  updateObject(id, patch) {
    const object = this.findObject(id);
    if (!object) return null;
    const target = patch.scene && SCENES.includes(patch.scene) ? patch.scene : object.scene;
    if (target !== object.scene) {
      const from = this.scenes[object.scene];
      const to = this.scenes[target];
      from.objects = from.objects.filter((o) => o.id !== id);
      object.scene = target;
      // Landing on a screen it already overlaps is friendlier than a pile in the
      // middle, so keep the coordinates the moderator dragged it to.
      object.z = topZ(to) + 1;
      to.objects.push(object);
    }
    const numeric = ['x', 'y', 'w', 'h', 'rot', 'opacity', 'z'];
    for (const key of numeric) {
      if (patch[key] === undefined) continue;
      const merged = sanitizeObject({ ...object, [key]: patch[key] }, { ...this.canvas, cut: this.cut, scene: object.scene });
      object[key] = merged[key];
    }
    // Volume is the sound of this object, from 0 to 1. The old boolean still goes
    // through, so a client that only knew how to mute keeps working.
    if (patch.volume !== undefined) {
      const merged = sanitizeObject({ ...object, volume: patch.volume }, { ...this.canvas, cut: this.cut, scene: object.scene });
      object.volume = merged.volume;
    } else if (patch.muted !== undefined) {
      object.volume = patch.muted === true ? 0 : 1;
    }
    if (patch.loop !== undefined) object.loop = Boolean(patch.loop);
    // The look of a text object. It goes through sanitizeObject like any other
    // field, so a hand made request cannot inject a colour or a font name into
    // the style of the OBS source.
    const textPatch = {};
    for (const key of ['text', 'textFont', 'textSize', 'textColor', 'textAlign']) {
      if (patch[key] !== undefined) textPatch[key] = patch[key];
    }
    if (Object.keys(textPatch).length) {
      const merged = sanitizeObject({ ...object, ...textPatch }, { ...this.canvas, cut: this.cut, scene: object.scene });
      for (const key of Object.keys(textPatch)) object[key] = merged[key];
    }
    // A replay is a request, not a position: the server stamps it and both the
    // panel and the stream restart from it.
    if (patch.replay) object.playAt = Date.now();
    // So is a jump: the moderator sends the second it wants and the server is
    // the one that says when, so that every screen lands on the same moment.
    if (patch.seek === null) {
      // Explicitly back to no jump at all, as opposed to a jump to second zero.
      object.seek = null;
    } else if (patch.seek !== undefined) {
      const pos = Number(patch.seek);
      if (Number.isFinite(pos)) object.seek = { pos: Math.max(0, pos), at: Date.now() };
    }
    if (typeof patch.name === 'string' && patch.name.trim()) object.name = patch.name.trim().slice(0, 200);
    if (patch.visible !== undefined) object.visible = Boolean(patch.visible);
    if (patch.locked !== undefined) object.locked = Boolean(patch.locked);
    // The drag is over, so the live frame is now the saved truth.
    this.live.delete(id);
    this.bump();
    return object;
  }

  /** Nudges an object and returns it without touching the revision counter:
   *  used for the live preview channel while a drag is still in progress. */
  /**
   * A live drag frame. It is deliberately kept beside the saved state instead
   * of on top of it: the pointer fires a frame every few milliseconds, and
   * writing them straight onto the object would let any unrelated save (another
   * mod uploading, for instance) commit a half finished drag.
   */
  previewObject(id, patch) {
    const object = this.findObject(id);
    if (!object) return null;
    const merged = sanitizeObject(
      { ...object, ...this.live.get(id), ...patch },
      { ...this.canvas, cut: this.cut, scene: object.scene },
    );
    const frame = {};
    for (const key of ['x', 'y', 'w', 'h', 'rot']) {
      if (patch[key] !== undefined) frame[key] = merged[key];
    }
    this.live.set(id, { ...this.live.get(id), ...frame });
    return { ...object, ...this.live.get(id) };
  }

  duplicateObject(id) {
    const object = this.findObject(id);
    if (!object) return null;
    const sceneRef = this.scenes[object.scene];
    const copy = sanitizeObject(
      { ...object, id: newMediaId(), x: object.x + 24, y: object.y + 24, z: topZ(sceneRef) + 1 },
      { ...this.canvas, cut: this.cut, scene: object.scene, fallbackZ: topZ(sceneRef) + 1 },
    );
    sceneRef.objects.push(copy);
    this.bump();
    return copy;
  }

  /** Relative order change, the way the bring forward / send back buttons work. */
  reorderObject(id, direction) {
    const object = this.findObject(id);
    if (!object) return null;
    const sceneRef = this.scenes[object.scene];
    const ordered = sortObjects(sceneRef);
    const at = ordered.findIndex((o) => o.id === id);
    if (at === -1) return null;
    const to = direction === 'front' ? ordered.length - 1
      : direction === 'back' ? 0
      : direction === 'up' ? Math.min(ordered.length - 1, at + 1)
      : Math.max(0, at - 1);
    const rest = ordered.filter((o) => o.id !== id);
    rest.splice(to, 0, object);
    // Renumber from the bottom so z stays dense and predictable.
    rest.forEach((o, index) => { o.z = index + 1; });
    this.bump();
    return object;
  }

  removeObject(id, { deleteFile = this.config.deleteOnClear } = {}) {
    const object = this.findObject(id);
    if (!object) return false;
    const sceneRef = this.scenes[object.scene];
    sceneRef.objects = sceneRef.objects.filter((o) => o.id !== id);
    this.live.delete(id);
    // Only the last user of a file may delete it.
    if (deleteFile && !this.findObjectByUpload(object.uploadId)) {
      const twin = SCENES.some((id2) => this.scenes[id2].objects.some((o) => o.file === object.file));
      if (!twin) safeUnlink(this.filePath(object.file));
    }
    this.bump();
    return true;
  }

  clearScene(id, { deleteFiles = this.config.deleteOnClear } = {}) {
    const sceneRef = this.scenes[id];
    if (!sceneRef) return 0;
    const going = [...sceneRef.objects];
    const removed = going.length;
    // Empty the screen first: a duplicate left on the other screen still points
    // at the same file, and only the last user of a file may delete it.
    sceneRef.objects = [];
    for (const object of going) this.live.delete(object.id);
    if (deleteFiles) {
      for (const object of going) {
        if (this.findObjectByUpload(object.uploadId)) continue;
        if (SCENES.some((s) => this.scenes[s]?.objects.some((o) => o.file === object.file))) continue;
        safeUnlink(this.filePath(object.file));
      }
    }
    if (removed) this.bump();
    return removed;
  }

  /**
   * Empties only the lower half of the screen, the part that is not on air.
   * This is what "vaciar el banco" means: the emission half is left alone,
   * because taking everything off air is "sacar todo de directo" and that is
   * clearing the whole screen. Anything that straddles the cut goes too, since
   * keeping half an object would leave a slice on air that nobody can select to
   * remove.
   */
  clearBank({ deleteFiles = this.config.deleteOnClear } = {}) {
    const sceneRef = this.scenes.program;
    const cut = this.cut;
    const going = sceneRef.objects.filter((o) => o.y + o.h > cut);
    if (!going.length) return 0;
    const gone = new Set(going.map((o) => o.id));
    sceneRef.objects = sceneRef.objects.filter((o) => !gone.has(o.id));
    for (const object of going) this.live.delete(object.id);
    if (deleteFiles) {
      for (const object of going) {
        if (this.findObjectByUpload(object.uploadId)) continue;
        if (sceneRef.objects.some((o) => o.file === object.file)) continue;
        safeUnlink(this.filePath(object.file));
      }
    }
    this.bump();
    return going.length;
  }

  /**
   * Legacy helper kept for the old "push to air" flow: it now drops every
   * pending upload in the bank instead of stacking full bleed layers.
   */
  push(uploadIds) {
    const created = [];
    for (const id of uploadIds) {
      const object = this.placeUpload(id, { scene: 'program' });
      if (object) created.push(object.id);
    }
    return created;
  }

  findLayer(id) {
    return this.findObject(id);
  }

  /* ------------------------------ stream ------------------------------ */

  /**
   * Takes the whole show off the air and brings it back as it was.
   *
   * Hiding is not deleting anything: the objects stay exactly where they are and
   * the source is only told to draw nothing and to keep quiet, so turning it back
   * on is the same show a moment later. That is what makes it safe to hit in the
   * middle of a stream, and why it lives here and not in each object.
   */
  setHidden(hidden) {
    const next = hidden === true;
    if (next === this.hidden) return this.hidden;
    this.hidden = next;
    this.bump();
    return this.hidden;
  }

  /* ------------------------------ agents ------------------------------ */

  touchAgent(id, info = {}) {
    if (!id) return null;
    const prev = this.agents.get(id) ?? { id, connected: false };
    const next = {
      ...prev,
      ...info,
      id,
      connected: true,
      seenAt: nowIso(),
    };
    this.agents.set(id, next);
    return next;
  }

  disconnectAgent(id) {
    const prev = this.agents.get(id);
    if (!prev) return null;
    const next = { ...prev, connected: false, seenAt: nowIso() };
    this.agents.set(id, next);
    this.agents = new Map(
      [...this.agents.entries()].filter(([, a]) => Date.now() - Date.parse(a.seenAt) < 3600_000),
    );
    return next;
  }

  listAgents() {
    const now = Date.now();
    const cutoff = now - 3600_000;
    this.agents = new Map(
      [...this.agents.entries()].filter(([, a]) => Date.parse(a.seenAt) >= cutoff),
    );
    return [...this.agents.values()].map((a) => ({
      id: a.id,
      kind: a.kind ?? 'agent',
      name: a.name ?? 'OBS',
      canvas: a.canvas ?? '',
      // What the source itself says it is painting. A black screen and a source
      // that never started look the same without this.
      diag: a.diag ?? null,
      version: a.version ?? '',
      connected: Boolean(a.connected),
      // When it last drew something, as a moment in time: the panel counts the
      // seconds itself, so the number keeps moving between two messages
      // instead of standing still until the next one arrives.
      renderedAt: typeof a.renderedAt === 'string' ? a.renderedAt : null,
      // connected=false wins: a dropped socket must show as offline at once.
      online: a.connected !== false && now - Date.parse(a.seenAt) < 60000,
      seenAt: a.seenAt,
      layers: Array.isArray(a.layers) ? a.layers : [],
      source: a.source ?? 'ws',
    }));
  }

  /* ----------------------------- snapshot ----------------------------- */

  mediaUrl(baseUrl, file) {
    const sig = signMedia(this.config.token, file);
    const base = String(baseUrl ?? '').replace(/\/+$/, '');
    return `${base}/media/${file}?k=${sig}`;
  }

  publicObject(baseUrl, object) {
    return {
      id: object.id,
      scene: object.scene,
      name: object.name,
      kind: object.kind,
      render: object.render || renderKind(object.name, object.mime),
      ext: object.ext,
      size: object.size,
      naturalWidth: object.naturalWidth,
      naturalHeight: object.naturalHeight,
      x: object.x,
      y: object.y,
      w: object.w,
      h: object.h,
      rot: object.rot,
      opacity: object.opacity,
      volume: object.volume,
      // Kept for anything that still asks the old question.
      muted: object.volume === 0,
      audioOnly: object.audioOnly === true,
      text: object.text ?? '',
      textFont: object.textFont,
      // The full stack, resolved here, so the stage never has to know the list of
      // allowed fonts: it just applies what it is told.
      textFontStack: textFontStack(object.textFont),
      textSize: object.textSize,
      textColor: object.textColor,
      textAlign: object.textAlign,
      loop: object.loop !== false,
      playAt: Number.isFinite(object.playAt) ? object.playAt : 0,
      seek: object.seek ? { pos: object.seek.pos, at: object.seek.at } : null,
      z: object.z,
      visible: object.visible,
      locked: object.locked,
      addedAt: object.addedAt,
      url: this.mediaUrl(baseUrl, object.file),
    };
  }

  publicScene(id, baseUrl) {
    const scene = this.scenes[id];
    if (!scene) return null;
    return {
      id: scene.id,
      name: scene.name,
      width: scene.width,
      height: scene.height,
      objects: sortObjects(scene).map((o) => this.publicObject(baseUrl, o)),
    };
  }

  /**
   * The OBS facing payload: the one screen, and the cut that says which half of
   * it goes out. A browser source that ignores the cut would air the bank, so
   * the cut travels with the scene rather than being guessed on the client.
   */
  snapshot({ baseUrl, includeUploads = false } = {}) {
    const out = {
      rev: this.rev,
      serverTime: nowIso(),
      program: this.publicScene('program', baseUrl),
      cut: this.cut,
      hidden: this.hidden,
      agents: this.listAgents(),
      config: {
        canvas: this.config.canvas,
        screen: this.config.screen,
      },
    };
    if (includeUploads) {
      out.uploads = [...this.uploads.values()].map((u) => ({
        id: u.id,
        name: u.name,
        size: u.size,
        kind: u.kind,
        width: u.width,
        height: u.height,
        uploadedAt: u.uploadedAt,
      }));
    }
    return out;
  }

  /** Everything a signed in moderator needs to draw the one screen. */
  workspace({ baseUrl } = {}) {
    return {
      rev: this.rev,
      // The font picker is built from this, so the list of typefaces lives in one
      // place only.
      fonts: TEXT_FONTS.map((font) => ({ id: font.id, label: font.label })),
      serverTime: nowIso(),
      cut: this.cut,
      hidden: this.hidden,
      scenes: {
        program: this.publicScene('program', baseUrl),
      },
      uploads: [...this.uploads.values()].map((u) => ({
        id: u.id,
        name: u.name,
        size: u.size,
        kind: u.kind,
        width: u.width,
        height: u.height,
        uploadedAt: u.uploadedAt,
      })),
      agents: this.listAgents(),
      config: {
        canvas: this.config.canvas,
        screen: this.config.screen,
      },
    };
  }

  /* ------------------------------- gc --------------------------------- */

  garbageCollect() {
    const referenced = new Set();
    for (const sceneId of SCENES) {
      for (const object of this.scenes[sceneId].objects) if (object.file) referenced.add(object.file);
    }
    for (const up of this.uploads.values()) if (up.file) referenced.add(up.file);
    let removed = 0;
    let entries = [];
    try {
      entries = fs.readdirSync(this.config.mediaDir);
    } catch {
      return;
    }
    for (const file of entries) {
      if (referenced.has(file)) continue;
      if (safeUnlink(path.join(this.config.mediaDir, file))) removed += 1;
    }
    if (removed) this.log('info', `removed ${removed} orphaned media file(s) on startup`);
  }
}
