/**
 * Picks the base URL used to build media links.
 *
 * Priority:
 *   1. an explicit --public-url (reverse proxy, tunnel, VPS…)
 *   2. whatever fallback the caller knows: the host the request came in on, or
 *      the last address a browser reached the server on for websocket pushes
 */
export function resolveBaseUrl({ publicUrl, fallback = '' } = {}) {
  const explicit = String(publicUrl ?? '').replace(/\/+$/, '');
  if (explicit) return explicit;
  return String(fallback ?? '').replace(/\/+$/, '');
}
