import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

const SCRYPT = { N: 16384, r: 8, p: 1, keylen: 64, saltBytes: 16 };
const USERNAME_RE = /^[a-z0-9][a-z0-9._-]{2,31}$/;
const ROLES = new Set(['admin', 'mod']);
const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 30;
const MIN_PASSWORD = 10;
const MAX_PASSWORD = 200;
const SESSION_ID_BYTES = 32;
const LAST_SEEN_EVERY_MS = 5 * 60 * 1000;

export const SESSION_COOKIE = 'd2o_user';
const COOKIE_TTL_MS = SESSION_TTL_MS;

export class AuthError extends Error {
  constructor(code, message, status = 400) {
    super(message);
    this.code = code;
    this.status = status;
  }
}

function nowIso() {
  return new Date().toISOString();
}

export function normalizeUsername(value) {
  return String(value ?? '')
    .trim()
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');
}

export function validateUsername(value) {
  const name = normalizeUsername(value);
  if (!USERNAME_RE.test(name)) {
    throw new AuthError(
      'invalid_username',
      'El usuario debe tener entre 3 y 32 caracteres: minúsculas, números, punto, guion o guion bajo.',
    );
  }
  return name;
}

export function validatePassword(value) {
  const password = String(value ?? '');
  if (password.length < MIN_PASSWORD) {
    throw new AuthError('weak_password', `La contraseña necesita al menos ${MIN_PASSWORD} caracteres.`);
  }
  if (password.length > MAX_PASSWORD) {
    throw new AuthError('weak_password', `La contraseña no puede pasar de ${MAX_PASSWORD} caracteres.`);
  }
  return password;
}

export function validateRole(value) {
  const role = String(value ?? 'mod').trim().toLowerCase();
  if (!ROLES.has(role)) throw new AuthError('invalid_role', 'El rol debe ser admin o mod.');
  return role;
}

export function hashPassword(password) {
  const salt = crypto.randomBytes(SCRYPT.saltBytes);
  const key = crypto.scryptSync(password, salt, SCRYPT.keylen, {
    N: SCRYPT.N,
    r: SCRYPT.r,
    p: SCRYPT.p,
    maxmem: 128 * SCRYPT.N * SCRYPT.r * 2,
  });
  return `scrypt$${SCRYPT.N}$${SCRYPT.r}$${SCRYPT.p}$${salt.toString('base64url')}$${key.toString('base64url')}`;
}

export function verifyPassword(password, stored) {
  const parts = String(stored ?? '').split('$');
  if (parts.length !== 6 || parts[0] !== 'scrypt') return false;
  const [, nRaw, rRaw, pRaw, saltRaw, keyRaw] = parts;
  const N = Number(nRaw);
  const r = Number(rRaw);
  const p = Number(pRaw);
  if (!Number.isInteger(N) || !Number.isInteger(r) || !Number.isInteger(p)) return false;
  try {
    const salt = Buffer.from(saltRaw, 'base64url');
    const expected = Buffer.from(keyRaw, 'base64url');
    if (salt.length === 0 || expected.length === 0) return false;
    const actual = crypto.scryptSync(password, salt, expected.length, {
      N,
      r,
      p,
      maxmem: 128 * N * r * 2,
    });
    return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
  } catch {
    return false;
  }
}

export function publicUser(user) {
  if (!user) return null;
  return {
    id: user.id,
    username: user.username,
    role: user.role,
    disabled: Boolean(user.disabled),
    mustChangePassword: Boolean(user.mustChangePassword),
    createdAt: user.createdAt,
    lastLoginAt: user.lastLoginAt ?? null,
  };
}

export function readCookie(header, name) {
  if (!header) return null;
  for (const part of String(header).split(';')) {
    const idx = part.indexOf('=');
    if (idx === -1) continue;
    if (part.slice(0, idx).trim() !== name) continue;
    try {
      return decodeURIComponent(part.slice(idx + 1).trim());
    } catch {
      return part.slice(idx + 1).trim();
    }
  }
  return null;
}

export function readUserCookie(req) {
  return readCookie(req?.headers?.cookie, SESSION_COOKIE);
}

export function buildUserCookie(value, secure) {
  const attrs = [
    `${SESSION_COOKIE}=${encodeURIComponent(value)}`,
    'Path=/',
    'HttpOnly',
    'SameSite=Lax',
    `Max-Age=${Math.floor(COOKIE_TTL_MS / 1000)}`,
  ];
  if (secure) attrs.push('Secure');
  return attrs.join('; ');
}

export function clearUserCookie(secure) {
  const attrs = [`${SESSION_COOKIE}=`, 'Path=/', 'HttpOnly', 'SameSite=Lax', 'Max-Age=0'];
  if (secure) attrs.push('Secure');
  return attrs.join('; ');
}

/** Blocks brute force: failures per ip+user, and a wider per-ip bucket. */
export class LoginThrottle {
  constructor({ maxPerUser = 5, maxPerIp = 30, windowMs = 15 * 60 * 1000 } = {}) {
    this.maxPerUser = maxPerUser;
    this.maxPerIp = maxPerIp;
    this.windowMs = windowMs;
    this.hits = new Map();
  }

  #prune(now) {
    for (const [key, bucket] of this.hits) {
      bucket.times = bucket.times.filter((t) => now - t < this.windowMs);
      if (!bucket.times.length) this.hits.delete(key);
    }
  }

  /** Throws AuthError('too_many_attempts') when the caller is locked out. */
  check(ip, username) {
    const now = Date.now();
    this.#prune(now);
    for (const [key, limit] of [
      [`u:${username}`, this.maxPerUser],
      [`i:${ip}`, this.maxPerIp],
    ]) {
      const bucket = this.hits.get(key);
      if (bucket && bucket.times.length >= limit) {
        const wait = Math.ceil((this.windowMs - (now - bucket.times[0])) / 1000);
        throw new AuthError(
          'too_many_attempts',
          `Demasiados intentos. Prueba de nuevo en ${Math.max(1, wait)} s.`,
          429,
        );
      }
    }
  }

  fail(ip, username) {
    const now = Date.now();
    for (const key of [`u:${username}`, `i:${ip}`]) {
      const bucket = this.hits.get(key) ?? { times: [] };
      bucket.times.push(now);
      this.hits.set(key, bucket);
    }
  }

  clear(ip, username) {
    this.hits.delete(`u:${username}`);
    this.hits.delete(`i:${ip}`);
  }
}

export class UserStore {
  constructor({ config, log = () => {} }) {
    this.config = config;
    this.log = log;
    this.file = path.join(config.dataDir, 'auth.json');
    this.users = new Map();
    this.sessions = new Map();
    this.watcher = null;
    this.reloadTimer = null;
    this.lastWritten = null;
    this.lastSeenText = null;
    this.onReload = null;
    // Until the first account exists the server token is the only way in, so it
    // keeps full control and the owner is never locked out. `create` latches
    // this off for good, even if every account is deleted later.
    this.bootstrap = true;
  }

  /** True while nobody has created an account yet. */
  isBootstrap() {
    return this.bootstrap && this.users.size === 0;
  }

  /* ------------------------------ storage ----------------------------- */

  /**
   * Watches auth.json so the cli works against a live server: when the file is
   * replaced by something that is not our own write, it is reloaded.
   */
  watch() {
    if (this.watcher) return;
    try {
      this.watcher = fs.watch(path.dirname(this.file), (_event, name) => {
        if (name && name !== path.basename(this.file)) return;
        // A rename plus a change event arrive for the same write, so the
        // reload is debounced and re-reads the file it is about to trust.
        clearTimeout(this.reloadTimer);
        this.reloadTimer = setTimeout(() => {
          this.reloadTimer = null;
          let text;
          try {
            text = fs.readFileSync(this.file, 'utf8');
          } catch {
            return;
          }
          if (text === this.lastWritten) return;
          this.load();
          this.lastWritten = text;
          this.log('info', 'auth.json cambiado fuera: recargado');
          this.onReload?.();
        }, 60);
        this.reloadTimer.unref?.();
      });
      this.watcher.unref?.();
    } catch (err) {
      this.log('warn', `no se pudo vigilar auth.json: ${err.message}`);
    }
  }

  stopWatching() {
    clearTimeout(this.reloadTimer);
    this.reloadTimer = null;
    try {
      this.watcher?.close();
    } catch {
      /* ignore */
    }
    this.watcher = null;
  }

  load() {
    let raw;
    try {
      this.lastSeenText = fs.readFileSync(this.file, 'utf8');
      raw = JSON.parse(this.lastSeenText);
    } catch {
      raw = null;
    }
    this.users.clear();
    this.sessions.clear();
    if (raw && typeof raw === 'object') {
      // The latch is only ever true while the file has no accounts at all, so a
      // file written before it existed (or edited by hand) cannot reopen it.
      const rawUsers = Array.isArray(raw.users) ? raw.users : [];
      this.bootstrap = raw.bootstrap === true && rawUsers.length === 0;
      for (const user of Array.isArray(raw.users) ? raw.users : []) {
        if (user?.id && user?.username && user?.passwordHash) this.users.set(user.id, user);
      }
      for (const session of Array.isArray(raw.sessions) ? raw.sessions : []) {
        if (session?.id && session?.userId) this.sessions.set(session.id, session);
      }
    }
    this.prune();
  }

  /**
   * Writes right away. auth.json is a few kB and changes are rare (a sign in, a
   * role change), so there is nothing to batch: writing immediately is what
   * keeps the cli and a running server from stepping on each other, because a
   * pending write could resurrect an account the cli just deleted.
   */
  save() {
    {
      // The cli writes the same file. If it did so since we last looked, take
      // its version first, otherwise our write would resurrect what it deleted.
      let onDisk = null;
      try {
        onDisk = fs.readFileSync(this.file, 'utf8');
      } catch {
        /* first write */
      }
      if (onDisk !== null && onDisk !== this.lastSeenText) this.load();
      const payload = {
        version: 1,
        savedAt: nowIso(),
        bootstrap: this.bootstrap,
        users: [...this.users.values()],
        sessions: [...this.sessions.values()],
      };
      const tmp = `${this.file}.${process.pid}.tmp`;
      const text = `${JSON.stringify(payload, null, 2)}\n`;
      try {
        fs.writeFileSync(tmp, text, { mode: 0o600 });
        this.lastWritten = text;
        this.lastSeenText = text;
        fs.renameSync(tmp, this.file);
        fs.chmodSync(this.file, 0o600);
      } catch (err) {
        this.log('error', `no se pudo guardar auth.json: ${err.message}`);
        try {
          fs.unlinkSync(tmp);
        } catch {
          /* ignore */
        }
      }
    }
  }

  prune() {
    const now = Date.now();
    let changed = false;
    for (const [id, session] of this.sessions) {
      if (now - Date.parse(session.expiresAt) > 0) {
        this.sessions.delete(id);
        changed = true;
      }
    }
    for (const user of this.users.values()) {
      if (user.passwordChangedAt && !user.sessionEpoch) user.sessionEpoch = user.passwordChangedAt;
    }
    if (changed) this.save();
  }

  /* ------------------------------- users ------------------------------ */

  get count() {
    return this.users.size;
  }

  list() {
    return [...this.users.values()].sort((a, b) => a.username.localeCompare(b.username));
  }

  byId(id) {
    return this.users.get(String(id ?? '')) ?? null;
  }

  byName(username) {
    const name = normalizeUsername(username);
    for (const user of this.users.values()) if (user.username === name) return user;
    return null;
  }

  adminCount() {
    let n = 0;
    for (const user of this.users.values()) if (user.role === 'admin' && !user.disabled) n += 1;
    return n;
  }

  create({ username, password, role = 'mod', mustChangePassword = false }) {
    const name = validateUsername(username);
    const pass = validatePassword(password);
    const rol = validateRole(role);
    if (this.byName(name)) throw new AuthError('username_taken', `El usuario «${name}» ya existe.`);
    const user = {
      id: crypto.randomBytes(9).toString('base64url'),
      username: name,
      role: rol,
      passwordHash: hashPassword(pass),
      mustChangePassword: Boolean(mustChangePassword),
      disabled: false,
      createdAt: nowIso(),
      lastLoginAt: null,
      passwordChangedAt: nowIso(),
      sessionEpoch: nowIso(),
    };
    this.users.set(user.id, user);
    // First account ever: from now on the token only reads.
    this.bootstrap = false;
    this.save();
    this.log('info', `user created: ${name} (${rol})`);
    return user;
  }

  /** Applies {username, role, disabled, password, mustChangePassword}. */
  update(id, patch, { actorId = null } = {}) {
    const user = this.byId(id);
    if (!user) throw new AuthError('not_found', 'Ese usuario no existe.', 404);
    const next = { ...user };

    if (patch.username !== undefined) {
      const name = validateUsername(patch.username);
      const other = this.byName(name);
      if (other && other.id !== user.id) {
        throw new AuthError('username_taken', `El usuario «${name}» ya existe.`);
      }
      next.username = name;
    }
    if (patch.role !== undefined) next.role = validateRole(patch.role);
    if (patch.disabled !== undefined) next.disabled = Boolean(patch.disabled);
    if (patch.mustChangePassword !== undefined) {
      next.mustChangePassword = Boolean(patch.mustChangePassword);
    }
    if (patch.password !== undefined && String(patch.password) !== '') {
      next.passwordHash = hashPassword(validatePassword(patch.password));
      next.passwordChangedAt = nowIso();
      // Bumping the epoch logs every other device out of this account.
      next.sessionEpoch = nowIso();
    }
    if (user.id === actorId && next.disabled) {
      throw new AuthError('self_disable', 'No puedes desactivar tu propia cuenta.');
    }
    // Losing admin rights or the ability to sign in must never leave the
    // install without an administrator to log in with.
    const losesAdmin = user.role === 'admin' && (next.role !== 'admin' || next.disabled);
    if (losesAdmin && this.adminCount() <= 1) {
      throw new AuthError('last_admin', 'No puedes dejar la instalación sin administrador.');
    }

    this.users.set(user.id, next);
    if (next.sessionEpoch !== user.sessionEpoch) this.destroyUserSessions(user.id, { except: actorId });
    this.save();
    this.log('info', `user updated: ${next.username}${patch.password ? ' (password changed)' : ''}`);
    return next;
  }

  delete(id, { actorId = null } = {}) {
    const user = this.byId(id);
    if (!user) throw new AuthError('not_found', 'Ese usuario no existe.', 404);
    if (user.id === actorId) throw new AuthError('self_delete', 'No puedes eliminar tu propia cuenta.');
    if (user.role === 'admin' && this.adminCount() <= 1) {
      throw new AuthError('last_admin', 'No puedes eliminar al único administrador.');
    }
    this.users.delete(user.id);
    this.destroyUserSessions(user.id);
    this.save();
    this.log('info', `user deleted: ${user.username}`);
    return true;
  }

  /* ------------------------------ sessions ---------------------------- */

  authenticate(username, password) {
    const user = this.byName(username);
    const stored = user?.passwordHash;
    // Verify even when the user does not exist so timing does not leak it.
    const ok = verifyPassword(String(password ?? ''), stored ?? 'scrypt$16384$8$1$AAAA$AAAA');
    if (!user || !ok || user.disabled) return null;
    return user;
  }

  createSession(user, { ip = '', userAgent = '' } = {}) {
    const id = crypto.randomBytes(SESSION_ID_BYTES).toString('base64url');
    const session = {
      id,
      userId: user.id,
      createdAt: nowIso(),
      lastSeenAt: nowIso(),
      expiresAt: new Date(Date.now() + SESSION_TTL_MS).toISOString(),
      ip: String(ip).slice(0, 60),
      userAgent: String(userAgent).slice(0, 120),
    };
    this.sessions.set(id, session);
    this.users.set(user.id, { ...user, lastLoginAt: nowIso() });
    this.save();
    return session;
  }

  /** Resolves a session id to {session, user}, sliding the expiry forward. */
  resolveSession(id) {
    if (!id) return null;
    const session = this.sessions.get(String(id));
    if (!session) return null;
    if (Date.parse(session.expiresAt) <= Date.now()) {
      this.sessions.delete(session.id);
      this.save();
      return null;
    }
    const user = this.byId(session.userId);
    if (!user || user.disabled) {
      this.sessions.delete(session.id);
      this.save();
      return null;
    }
    // A password change after the session started invalidates it.
    if (user.sessionEpoch && session.createdAt < user.sessionEpoch) {
      this.sessions.delete(session.id);
      this.save();
      return null;
    }
    if (Date.now() - Date.parse(session.lastSeenAt) > LAST_SEEN_EVERY_MS) {
      session.lastSeenAt = nowIso();
      this.save();
    }
    return { session, user };
  }

  destroySession(id) {
    if (!id) return false;
    const gone = this.sessions.delete(String(id));
    if (gone) this.save();
    return gone;
  }

  destroyUserSessions(userId, { except = null } = {}) {
    let n = 0;
    for (const [id, session] of this.sessions) {
      if (session.userId !== userId) continue;
      if (except && session.id === except) continue;
      this.sessions.delete(id);
      n += 1;
    }
    if (n) this.save();
    return n;
  }

  listSessions(userId) {
    return [...this.sessions.values()]
      .filter((s) => !userId || s.userId === userId)
      .sort((a, b) => (a.lastSeenAt < b.lastSeenAt ? 1 : -1));
  }

  changeOwnPassword(user, currentPassword, newPassword) {
    if (!verifyPassword(String(currentPassword ?? ''), user.passwordHash)) {
      // 400 and not 401: the caller is authenticated, a 401 would be read as an
      // expired session and throw the person back to the login page.
      throw new AuthError('wrong_password', 'La contraseña actual no es correcta.', 400);
    }
    validatePassword(newPassword);
    const next = {
      ...user,
      passwordHash: hashPassword(String(newPassword)),
      passwordChangedAt: nowIso(),
      sessionEpoch: nowIso(),
      mustChangePassword: false,
    };
    this.users.set(user.id, next);
    this.destroyUserSessions(user.id);
    this.save();
    this.log('info', `password changed for ${user.username}`);
    return next;
  }
}
