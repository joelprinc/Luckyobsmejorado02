/*
 * What happened in the show, and who did it.
 *
 * Two things live here, both in one file so there is a single write path and a
 * single thing to look at when something goes wrong:
 *
 *   - a log of the media going in and out: which file, when, and the moderator
 *     who did it. It is an audit trail, so it is kept across restarts and only
 *     an administrator can empty it.
 *   - who is around right now. Presence is in memory (it is about open tabs)
 *     while the last time each account was seen is kept, so a moderator who
 *     closed the page an hour ago still appears in the list with his hour.
 */
import fs from 'node:fs';
import path from 'node:path';

const FILE = 'actividad.json';
const DEFAULT_LIMIT = 500;
/** Above this the file stops growing: an audit trail of the recent show. */
const HARD_LIMIT = 5000;

function nowIso() {
  return new Date().toISOString();
}

export class Activity {
  constructor({ dataDir, log = () => {}, limit = DEFAULT_LIMIT }) {
    this.file = path.join(dataDir, FILE);
    this.log = log;
    this.limit = Math.min(limit, HARD_LIMIT);
    /** username -> { username, role, since, connections } */
    this.online = new Map();
    this.entries = [];
    this.lastSeen = {};
    this.onChange = () => {};
    this.saveTimer = null;
  }

  load() {
    let raw;
    try {
      raw = JSON.parse(fs.readFileSync(this.file, 'utf8'));
    } catch {
      raw = null;
    }
    if (raw && typeof raw === 'object') {
      this.entries = Array.isArray(raw.entries) ? raw.entries.slice(-this.limit) : [];
      this.lastSeen = raw.lastSeen && typeof raw.lastSeen === 'object' ? raw.lastSeen : {};
    }
  }

  save({ immediate = false } = {}) {
    if (this.saveTimer) {
      if (!immediate) return;
      clearTimeout(this.saveTimer);
      this.saveTimer = null;
    }
    const write = () => {
      this.saveTimer = null;
      const payload = {
        savedAt: nowIso(),
        entries: this.entries.slice(-this.limit),
        lastSeen: this.lastSeen,
      };
      const tmp = `${this.file}.${process.pid}.tmp`;
      try {
        fs.writeFileSync(tmp, JSON.stringify(payload, null, 2));
        fs.renameSync(tmp, this.file);
      } catch (err) {
        this.log('error', `no se pudo guardar la actividad: ${err.message}`);
      }
    };
    if (immediate) write();
    else this.saveTimer = setTimeout(write, 400);
  }

  /* ------------------------------ history ------------------------------ */

  /**
   * One line in the trail. `action` is what happened (uploaded, removed, ...),
   * `name` the file it happened to and `who` the moderator, taken from the
   * session rather than from anything the client can choose.
   */
  record({ action, name = '', who = '', detail = '' }) {
    if (!action) return null;
    const entry = {
      id: `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`,
      at: nowIso(),
      action,
      name: String(name).slice(0, 160),
      detail: String(detail).slice(0, 200),
      who: String(who).slice(0, 60),
    };
    this.entries.push(entry);
    if (this.entries.length > this.limit) this.entries = this.entries.slice(-this.limit);
    this.save();
    this.onChange(entry);
    return entry;
  }

  clear() {
    const removed = this.entries.length;
    this.entries = [];
    this.save({ immediate: true });
    this.onChange(null);
    return removed;
  }

  list(limit = this.limit) {
    return this.entries.slice(-limit).reverse();
  }

  /* ----------------------------- presence ------------------------------ */

  /** A control page opened by somebody. */
  connect(username, role = 'mod') {
    if (!username) return null;
    const now = Date.now();
    const found = this.online.get(username);
    const entry = {
      username,
      role: role || found?.role || 'mod',
      since: found?.since ?? new Date(now).toISOString(),
      connections: (found?.connections ?? 0) + 1,
    };
    this.online.set(username, entry);
    this.lastSeen[username] = { at: entry.since, role: entry.role, connected: true };
    this.save();
    this.onChange(null);
    return entry;
  }

  /** A control page closed: the account stays in the list with its last hour. */
  disconnect(username) {
    if (!username) return;
    const found = this.online.get(username);
    if (!found) return;
    if (found.connections > 1) {
      this.online.set(username, { ...found, connections: found.connections - 1 });
      return;
    }
    this.online.delete(username);
    this.lastSeen[username] = { at: nowIso(), role: found.role, connected: false };
    this.save();
    this.onChange(null);
  }

  /** Everyone, connected first, then whoever is left with their last moment. */
  accounts(userList = []) {
    const names = new Map();
    for (const user of userList) {
      names.set(user.username, {
        username: user.username,
        role: user.role,
        connected: false,
        since: null,
        lastSeen: this.lastSeen[user.username]?.at ?? null,
      });
    }
    // An account deleted while it was online would otherwise vanish from the
    // list while its tab is still open.
    for (const [username, entry] of this.online) {
      if (!names.has(username)) {
        names.set(username, {
          username,
          role: entry.role,
          connected: true,
          since: entry.since,
          lastSeen: entry.since,
        });
      }
    }
    const list = [...names.values()].map((person) => {
      const online = this.online.get(person.username);
      return {
        ...person,
        connected: Boolean(online),
        since: online?.since ?? null,
        lastSeen: online?.since ?? person.lastSeen,
      };
    });
    list.sort((a, b) => {
      if (a.connected !== b.connected) return a.connected ? -1 : 1;
      const at = String(b.lastSeen ?? '');
      return at.localeCompare(String(a.lastSeen ?? '')) || a.username.localeCompare(b.username);
    });
    return list;
  }

  get onlineCount() {
    return this.online.size;
  }
}