#!/usr/bin/env node
/**
 * User management from the terminal.
 *
 *   node server/cli-users.js list
 *   node server/cli-users.js count
 *   node server/cli-users.js ensure ana --admin
 *   node server/cli-users.js add ana --admin
 *   node server/cli-users.js add ana --role mod --password 'mi clave'
 *   node server/cli-users.js pass ana
 *   node server/cli-users.js role ana mod
 *   node server/cli-users.js disable ana | enable ana
 *   node server/cli-users.js remove ana
 *
 * Without --password a strong one is generated and printed once (ensure also
 * prints CLAVE=... so scripts can pick it up). It works on the same auth.json
 * the server uses: a running server reloads the file by itself, so there is no
 * need to stop the service.
 */
import crypto from 'node:crypto';
import { loadConfig } from './config.js';
import { AuthError, UserStore } from './users.js';

const config = loadConfig([]);
const store = new UserStore({ config });
store.load();

const [, , command, ...rest] = process.argv;
const flags = new Map();
const positional = [];
for (let i = 0; i < rest.length; i += 1) {
  if (rest[i].startsWith('--')) {
    const key = rest[i].slice(2);
    const next = rest[i + 1];
    if (next && !next.startsWith('--')) {
      flags.set(key, next);
      i += 1;
    } else {
      flags.set(key, 'true');
    }
    continue;
  }
  positional.push(rest[i]);
}

function die(message) {
  process.stderr.write(`✘ ${message}\n`);
  process.exit(1);
}

function generatedPassword() {
  // Ambiguous characters removed: this gets read off a screen and typed.
  const alphabet = 'abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const bytes = crypto.randomBytes(20);
  return Array.from(bytes, (b) => alphabet[b % alphabet.length]).join('');
}

function printUser(user) {
  const tags = [
    user.role === 'admin' ? 'admin' : 'mod',
    user.disabled ? 'desactivado' : 'activo',
    user.mustChangePassword ? 'debe cambiar la clave' : '',
  ].filter(Boolean);
  const when = user.lastLoginAt ? `último acceso ${user.lastLoginAt}` : 'nunca ha entrado';
  const label = tags.join(' · ');
  process.stdout.write(
    `${user.username.padEnd(14)}${user.id.padEnd(15)}${label.padEnd(42)}${when}\n`,
  );
}

try {
  switch (command) {
    case 'list': {
      const all = store.list();
      if (!all.length) {
        process.stdout.write('No hay usuarios. Crea uno con: node server/cli-users.js add ana --admin\n');
        break;
      }
      process.stdout.write(`${all.length} usuario(s):\n`);
      all.forEach(printUser);
      break;
    }
    case 'count': {
      // Cuantas cuentas hay. El instalador lo usa para no volver a crear un
      // administrador que el dueno haya borrado a proposito.
      process.stdout.write(`${store.count}\n`);
      break;
    }

    case 'ensure': {
      // What the installer uses: create the account if it is missing, never
      // touch an existing one.
      const username = positional[0];
      if (!username) die('Falta el nombre: ensure <usuario> [--admin]');
      const existing = store.byName(username);
      if (existing) {
        process.stdout.write(`${existing.username} ya existe (${existing.role}). No se ha tocado su clave.\n`);
        break;
      }
      const password = flags.get('password') ?? generatedPassword();
      const user = store.create({
        username,
        password,
        role: flags.get('admin') ? 'admin' : (flags.get('role') ?? 'mod'),
        mustChangePassword: !flags.has('password'),
      });
      store.save();
      printUser(user);
      process.stdout.write(`CLAVE=${password}\n`);
      break;
    }
    case 'add': {
      const username = positional[0];
      if (!username) die('Falta el nombre: add <usuario> [--admin] [--password <clave>]');
      const password = flags.get('password') ?? generatedPassword();
      const user = store.create({
        username,
        password,
        role: flags.get('admin') ? 'admin' : (flags.get('role') ?? 'mod'),
        mustChangePassword: !flags.has('password'),
      });
      printUser(user);
      if (!flags.has('password')) {
        process.stdout.write(`\nClave de ${user.username}: ${password}\n(Cámbiala al entrar.)\n`);
      }
      store.save();
      break;
    }
    case 'pass': {
      const username = positional[0];
      const user = store.byName(username) ?? store.list().find((u) => u.id === username);
      if (!user) die(`No existe el usuario ${username}`);
      const password = flags.get('password') ?? generatedPassword();
      store.update(user.id, { password, mustChangePassword: false });
      store.save();
      process.stdout.write(`Clave de ${user.username}: ${password}\n`);
      break;
    }
    case 'role': {
      const username = positional[0];
      const role = positional[1];
      const user = store.byName(username) ?? store.list().find((u) => u.id === username);
      if (!user) die(`No existe el usuario ${username}`);
      printUser(store.update(user.id, { role }));
      store.save();
      break;
    }
    case 'disable':
    case 'enable': {
      const username = positional[0];
      const user = store.byName(username) ?? store.list().find((u) => u.id === username);
      if (!user) die(`No existe el usuario ${username}`);
      printUser(store.update(user.id, { disabled: command === 'disable' }));
      store.save();
      break;
    }
    case 'remove': {
      const username = positional[0];
      const user = store.byName(username) ?? store.list().find((u) => u.id === username);
      if (!user) die(`No existe el usuario ${username}`);
      store.delete(user.id);
      store.save();
      process.stdout.write(`Usuario ${user.username} eliminado.\n`);
      break;
    }
    default:
      process.stdout.write(
        [
          'Uso:',
          '  list                          lista los usuarios',
          '  ensure <usuario> [--admin]    crea la cuenta si no existe',
          '  add <usuario> [--admin|--role admin|mod] [--password X]',
          '                                crea uno (rol mod por defecto)',
          '  pass <usuario> [--password X] genera una clave nueva',
          '  role <usuario> admin|mod      cambia el rol',
          '  enable|disable <usuario>      activa o desactiva el acceso',
          '  remove <usuario>              lo borra',
          '',
        ].join('\n'),
      );
      process.exit(command ? 1 : 0);
  }
} catch (err) {
  if (err instanceof AuthError) die(err.message);
  throw err;
}


