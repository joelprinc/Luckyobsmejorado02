import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';
import { JSDOM, VirtualConsole } from 'jsdom';

const here = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.join(here, '..', 'public');

/**
 * The stage is what OBS shows, and it only exists in a browser: no test touched
 * it, so the most common failure of the whole program, a source that renders
 * nothing at all, could only be found by looking at a stream. These load the
 * real stage page and check the two things that decide what OBS shows: whether
 * the scene is drawn, and whether a link that has gone stale says so instead of
 * leaving a black rectangle.
 */
function startStage({ url, state = null, status = 200 }) {
  const noise = [];
  const console_ = new VirtualConsole();
  for (const level of ['error', 'warn']) {
    console_.on(level, (...rest) => noise.push(`${level}: ${rest.map(String).join(' ')}`));
  }
  console_.on('jsdomError', (err) => noise.push(`jsdomError: ${err.message}`));

  const dom = new JSDOM(fs.readFileSync(path.join(publicDir, 'stage.html'), 'utf8'), {
    url,
    runScripts: 'dangerously',
    pretendToBeVisual: true,
    virtualConsole: console_,
  });
  const { window } = dom;

  window.fetch = async () => ({
    ok: status === 200,
    status,
    json: async () => JSON.parse(JSON.stringify(state ?? { error: 'unauthorized' })),
    text: async () => JSON.stringify(state ?? {}),
  });

  window.WebSocket = class {
    constructor(wsUrl) { this.url = wsUrl; this.readyState = 1; this.listeners = {}; }
    addEventListener(type, fn) { (this.listeners[type] ??= []).push(fn); }
    send() {}
    close() { this.readyState = 3; }
  };

  const rect = { x: 0, y: 0, left: 0, top: 0, right: 1920, bottom: 1080, width: 1920, height: 1080 };
  window.Element.prototype.getBoundingClientRect = () => rect;
  window.Element.prototype.scrollIntoView = () => {};
  window.HTMLElement.prototype.focus = () => {};
  window.HTMLCanvasElement.prototype.getContext = () => null;
  window.HTMLMediaElement.prototype.play = () => Promise.resolve();
  window.HTMLMediaElement.prototype.pause = () => {};

  const strip = (code) => code
    .replace(/^import\s+\{[\s\S]*?\}\s+from\s+'[^']+';\s*$/gm, '')
    .replace(/^import\s+[\s\S]*?from\s+'[^']+';\s*$/gm, '')
    .replace(/^export\s+/gm, '');
  const read = (file) => strip(fs.readFileSync(path.join(publicDir, file), 'utf8'));
  window.eval([read('geometry.js'), read('scene.js'), read('stage.js')].join('\n'));

  return {
    window,
    document: window.document,
    stage: window.document.getElementById('stage'),
    note: () => window.document.querySelector('.stage-note'),
    noise,
    close() { window.close(); },
    async settle(ms = 300) {
      await new Promise((r) => setTimeout(r, ms));
    },
  };
}

const LIVE = {
  rev: 3,
  cut: 1080,
  hidden: false,
  program: {
    id: 'program',
    width: 1920,
    height: 2160,
    objects: [{
      id: 'o1', scene: 'program', name: 'foto', kind: 'image', render: 'image',
      url: 'https://luckyobs.w4rfin.com/media/foto.jpg',
      x: 100, y: 100, w: 400, h: 225, rot: 0, opacity: 1, z: 1,
      visible: true, volume: 1, muted: false, audioOnly: false,
      addedAt: new Date().toISOString(),
    }],
  },
};

test('the stage draws what is on air', async () => {
  const app = startStage({
    url: 'https://luckyobs.w4rfin.com/stage?t=bueno',
    state: LIVE,
  });
  try {
    await app.settle();
    assert.equal(app.stage.querySelectorAll('.scene-object').length, 1, 'OBS dibuja el objeto sin controles de edición');
    assert.equal(app.note(), null, 'a working link must not show the expired warning');
    assert.deepEqual(app.noise, []);
  } finally {
    app.close();
  }
});

test('a link that has expired says so instead of showing black', async () => {
  const app = startStage({
    url: 'https://luckyobs.w4rfin.com/stage?t=el-token-que-ya-no-existe',
    state: { error: 'unauthorized' },
    status: 401,
  });
  try {
    await app.settle();
    const note = app.note();
    assert.ok(note, 'the stage has to say that the link expired');
    assert.match(note.textContent, /caducado/i);
    assert.deepEqual(app.noise, []);
  } finally {
    app.close();
  }
});