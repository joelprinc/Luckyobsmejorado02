import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';
import { JSDOM, VirtualConsole } from 'jsdom';

const here = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.join(here, '..', 'public');

const CUT = 1080;

/** An ISO moment that long ago, for the fixtures about the age of the source. */
function secondsAgo(seconds) {
  return new Date(Date.now() - seconds * 1000).toISOString();
}

/** An object as the server describes it, with the fields the panel reads. */
function fakeObject(over = {}) {
  return {
    id: 'o1', scene: 'program', name: 'rojo', kind: 'image', render: 'image',
    url: 'https://luckyobs.w4rfin.com/media/rojo.png',
    x: 100, y: 100, w: 400, h: 225, rot: 0, opacity: 1, z: 1,
    visible: true, locked: false, volume: 1, muted: false, audioOnly: false,
    text: '', textFont: 'arial', textSize: 96, textColor: '#ffffff',
    textAlign: 'center', textFontStack: 'Arial, sans-serif',
    loop: true, playAt: 0, addedAt: new Date().toISOString(),
    ...over,
  };
}

/**
 * The panel runs in a browser, and its tests used to live nowhere: the whole
 * suite is about the server, so a missing function in the browser side shipped
 * as a panel that came up dead, with nothing red. This loads the real index.html
 * plus the four scripts that make up the panel and checks it comes up.
 *
 * app.js is an ES module and jsdom does not load modules, so the four files are
 * turned into one classic script: the import and export lines go and the rest is
 * evaluated in order inside the window.
 */
function startPanel({ hidden = false, silentFor = 0, frozenFor = 0 } = {}) {
  const asked = [];
  const noise = [];
  const console_ = new VirtualConsole();
  for (const level of ['error', 'warn']) {
    console_.on(level, (...rest) => noise.push(`${level}: ${rest.map(String).join(' ')}`));
  }
  console_.on('jsdomError', (err) => noise.push(`jsdomError: ${err.message}`));

  const dom = new JSDOM(fs.readFileSync(path.join(publicDir, 'index.html'), 'utf8'), {
    url: 'https://luckyobs.w4rfin.com/',
    runScripts: 'dangerously',
    pretendToBeVisual: true,
    virtualConsole: console_,
  });
  const { window } = dom;

  const workspace = {
    rev: 1,
    cut: CUT,
    hidden,
    fonts: [
      { id: 'arial', label: 'Arial' },
      { id: 'comic', label: 'Comic Sans' },
      { id: 'papyrus', label: 'Papyrus' },
    ],
    scenes: {
      program: {
        id: 'program',
        name: 'Pantalla',
        width: 1920,
        height: 2160,
        // One on air and one waiting in the bank, because the panel has to draw
        // both halves and the bank being full is what shrinks the drop area.
        objects: [
          fakeObject(),
          fakeObject({ id: 'o2', name: 'clip', y: 1300, w: 320, h: 180 }),
          // A video waiting in the bank, for the scrubber: an image has no
          // length, so it must not get the bar.
          fakeObject({
            id: 'o3', name: 'intro', y: 1400, w: 320, h: 180, kind: 'video',
            render: 'media', volume: 0.8,
          }),
        ],
      },
    },
    uploads: [],
    // The OBS browser source, which is what the stage indicator watches.
    agents: [{
      id: 'a1', name: 'Pantalla OBS', kind: 'stage', online: true,
      canvas: '1920×1080',
      seenAt: secondsAgo(silentFor),
      renderedAt: secondsAgo(frozenFor),
    }],
  };
  const answers = {
    '/api/auth/me': {
      user: { id: 'u1', username: 'ana', role: 'admin', createdAt: new Date().toISOString() },
      tokenFallback: false,
    },
    '/api/workspace': workspace,
    // The server says which address it has, and it is not this window's: the
    // friend gets a link that works from anywhere.
    '/api/share': {
      stagePath: '/stage',
      publicUrl: 'https://luckyobs.w4rfin.com',
      stageUrl: 'https://luckyobs.w4rfin.com/stage?t=tok',
      token: 'tok',
      canvas: '1920x1080',
      controlUrl: 'https://luckyobs.w4rfin.com/api/control/hidden?key=k',
    },
  };

  window.fetch = async (url, options = {}) => {
    const pathname = String(url).replace(window.location.origin, '').split('?')[0];
    asked.push(`${options.method ?? 'GET'} ${pathname}`);
    const ok = pathname in answers || (options.method ?? 'GET') === 'PATCH';
    const body = answers[pathname] ?? (ok ? { rev: 2 } : { error: 'not_found' });
    return {
      ok,
      status: ok ? 200 : 404,
      json: async () => JSON.parse(JSON.stringify(body)),
      text: async () => JSON.stringify(body),
    };
  };

  // The panel gets presence and the trail over the socket, so the stub keeps the
  // sockets around and lets a test push a frame into them.
  const sockets = [];
  window.WebSocket = class {
    constructor(url) { this.url = url; this.readyState = 1; this.listeners = {}; sockets.push(this); }
    addEventListener(type, fn) { (this.listeners[type] ??= []).push(fn); }
    send() {}
    close() { this.readyState = 3; }
    push(frame) { for (const fn of this.listeners.message ?? []) fn({ data: JSON.stringify(frame) }); }
  };

  // jsdom has no layout and no pointer capture; both are only shapes here.
  const rect = { x: 0, y: 0, left: 0, top: 0, right: 1920, bottom: 1080, width: 1920, height: 1080 };
  window.Element.prototype.getBoundingClientRect = () => rect;
  window.Element.prototype.scrollIntoView = () => {};
  window.Element.prototype.setPointerCapture = () => {};
  window.Element.prototype.releasePointerCapture = () => {};
  window.Element.prototype.hasPointerCapture = () => false;
  window.HTMLElement.prototype.focus = () => {};
  window.HTMLCanvasElement.prototype.getContext = () => null;
  // jsdom has no media stack at all: without this every clip throws on play().
  window.HTMLMediaElement.prototype.play = () => Promise.resolve();
  window.HTMLMediaElement.prototype.pause = () => {};

  const strip = (code) => code
    .replace(/^import\s+\{[\s\S]*?\}\s+from\s+'[^']+';\s*$/gm, '')
    .replace(/^import\s+[\s\S]*?from\s+'[^']+';\s*$/gm, '')
    .replace(/^export\s+/gm, '');
  const read = (file) => strip(fs.readFileSync(path.join(publicDir, file), 'utf8'));
  window.eval([
    read('geometry.js'),
    read('scene.js'),
    read('editor.js'),
    read('app.js'),
  ].join('\n'));

  return {
    dom,
    window,
    document: window.document,
    close() { window.close(); },
    asked,
    noise,
    sockets,
    async settle(ms = 600) {
      await new Promise((r) => setTimeout(r, ms));
    },
  };
}

test('the control page comes up and fills in with what the server says', async (t) => {
  const panel = startPanel();
  t.after(() => panel.close());
  await panel.settle();

  const { document } = panel;
  assert.deepEqual(
    panel.noise.filter((line) => !line.includes('conectando')),
    [],
    'el panel no debe quejarse al arrancar',
  );

  // The session: without this the name stays as the dots it ships with.
  assert.equal(document.getElementById('userName').textContent, 'ana');
  // The objects on the screen, one per half.
  assert.equal(document.querySelectorAll('#airList li').length, 1, 'el de directo');
  assert.equal(document.querySelectorAll('#bankList li').length, 2, 'los del banco');
  // And the typeface picker, which is built from the list the server sends.
  assert.equal(document.getElementById('obTextFont').options.length, 3);
  // The stage indicator: it names OBS, not the panel, because that is what is
  // being connected or not.
  assert.match(document.getElementById('stageText').textContent, /^OBS conectado/);
  assert.match(document.getElementById('stageDot').className, /ok/);

  // The "nothing here" lines carry the class that keeps the column square: the
  // second label must not end up glued to them.
  for (const id of ['airHint', 'bankHint']) {
    assert.match(document.getElementById(id).className, /list-empty/, `${id} lleva la clase`);
  }

  // The drop area stays on screen and clickable even though the bank already
  // holds something: it is the only click that opens the file picker.
  const hint = document.getElementById('dropHint');
  assert.equal(hint.hidden, false, 'el aviso de soltar no se esconde');
  assert.equal(hint.classList.contains('compact'), true, 'se encoge en vez de desaparecer');
  assert.match(hint.textContent, /haz clic para elegir/, 'y sigue.invoke invitando a hacer clic');
});

test('while the show is hidden the stage says so, and there is no banner', async (t) => {
  const panel = startPanel({ hidden: true });
  t.after(() => panel.close());
  await panel.settle();

  const { document } = panel;
  assert.equal(document.getElementById('stageText').textContent, 'Pantalla no visible');
  assert.match(document.getElementById('stageDot').className, /warn/, 'la led en amarillo');
  assert.equal(document.getElementById('hideToggle').getAttribute('aria-pressed'), 'true');
  // The strip that used to cross the page is gone for good.
  assert.equal(document.getElementById('hiddenBanner'), null);
});

test('the OBS link is the public one, not the address this window was opened with', async (t) => {
  const panel = startPanel();
  t.after(() => panel.close());
  await panel.settle(600);

  const link = panel.document.getElementById('stageUrl').value;
  assert.match(link, /^https:\/\/luckyobs\.w4rfin\.com\/stage\?t=tok$/, `el enlace es: ${link}`);
  const deck = panel.document.getElementById('controlUrl').value;
  assert.match(deck, /^https:\/\/luckyobs\.w4rfin\.com\/api\/control\/hidden\?key=k$/, `el boton es: ${deck}`);
});

test('a clip gets a scrubber, and dragging it jumps the clip', async (t) => {
  const panel = startPanel();
  t.after(() => panel.close());
  await panel.settle();

  const { document, window } = panel;
  const click = (node) => {
    const box = node.getBoundingClientRect();
    const x = box.left + box.width / 2;
    const y = box.top + box.height / 2;
    for (const type of ['pointerdown', 'pointerup']) {
      node.dispatchEvent(new window.MouseEvent(type, { clientX: x, clientY: y, bubbles: true, cancelable: true }));
    }
  };

  // An image has no length, so no scrubber.
  click(document.querySelector('.scene-object'));
  await panel.settle(200);
  assert.equal(document.getElementById('obSeekRow').hidden, true, 'una imagen no tiene barra de tiempo');

  // The video does, and moving it asks the server for that moment.
  const nodes = [...document.querySelectorAll('.scene-object')];
  click(nodes[nodes.length - 1]);
  await panel.settle(200);
  const row = document.getElementById('obSeekRow');
  assert.equal(row.hidden, false, 'un vídeo sí tiene barra de tiempo');

  const slider = document.getElementById('obSeek');
  slider.value = '42.4';
  slider.dispatchEvent(new window.Event('input', { bubbles: true }));
  slider.dispatchEvent(new window.Event('change', { bubbles: true }));
  await panel.settle(300);

  assert.match(
    document.getElementById('obSeekTime').textContent,
    /0:42/,
    'la cuenta va con el pulgar',
  );
  const sent = panel.asked.filter((call) => call.startsWith('PATCH') && call.includes('/api/objects/'));
  assert.ok(sent.length >= 1, `el salto tiene que salir a la API; se pidio: ${panel.asked.join(', ')}`);
});

test('the OBS indicator counts its age, and calls out a source that froze', async (t) => {
  const fresh = startPanel();
  t.after(() => fresh.close());
  await fresh.settle();
  const text = fresh.document.getElementById('stageText').textContent;
  assert.match(text, /^OBS conectado/, `una fuente sana lo dice: ${text}`);
  assert.match(text, /hace \d+ s/, 'y enseña cuántos segundos lleva hablando');
  assert.match(fresh.document.getElementById('stageDot').className, /ok/);

  // It answers but it has not drawn for a while: the frozen source, which is
  // the one that gets noticed halfway through a stream.
  const frozen = startPanel({ frozenFor: 40 });
  t.after(() => frozen.close());
  await frozen.settle();
  assert.match(frozen.document.getElementById('stageText').textContent, /^OBS congelado · hace 4\d s/);
  assert.match(frozen.document.getElementById('stageDot').className, /warn/, 'led en amarillo');

  // It has stopped answering altogether: gone, not frozen.
  const gone = startPanel({ silentFor: 90, frozenFor: 95 });
  t.after(() => gone.close());
  await gone.settle();
  assert.match(gone.document.getElementById('stageText').textContent, /^OBS sin respuesta/);
  assert.match(gone.document.getElementById('stageDot').className, /err/, 'led en rojo');
});

test('the sound of the panel is a button, and it starts silent', async (t) => {
  const panel = startPanel();
  t.after(() => panel.close());
  await panel.settle();

  const { document } = panel;
  const button = document.getElementById('listenToggle');
  assert.ok(button, 'el boton esta');
  assert.equal(button.hidden, false, 'un administrador lo ve');
  assert.equal(button.getAttribute('aria-pressed'), 'false', 'y empieza sin sonido');

  button.click();
  assert.equal(button.getAttribute('aria-pressed'), 'true', 'pulsado, suena');
  assert.equal(document.getElementById('listenToggleText').textContent, 'Sonando');
  button.click();
  assert.equal(button.getAttribute('aria-pressed'), 'false', 'pulsado otra vez, callado');
});

test('presence and the trail arrive over the socket and are drawn', async (t) => {
  const panel = startPanel();
  t.after(() => panel.close());
  await panel.settle(400);
  assert.ok(panel.sockets.length, 'el panel abre el socket');

  panel.sockets.forEach((ws) => ws.push({
    type: 'activity',
    history: [
      { id: 'h1', action: 'subido', who: 'ana', at: new Date().toISOString(), detail: 'rojo.png' },
      { id: 'h2', action: 'al banco', who: 'bea', at: new Date().toISOString(), detail: 'clip.mp4' },
    ],
    moderators: [{ username: 'ana', role: 'admin', connected: true, lastSeen: new Date().toISOString() }],
  }));
  await panel.settle(300);

  assert.ok(panel.document.querySelectorAll('#modList li').length > 0, 'la lista de moderadores se llena');
  assert.ok(panel.document.querySelectorAll('#historyList li, #history li').length > 0, 'el historial se llena');
});

test('an object can be dragged, and the move is sent', async (t) => {
  const panel = startPanel();
  t.after(() => panel.close());
  await panel.settle();

  const node = panel.document.querySelector('.scene-object');
  assert.ok(node, 'el objeto se dibuja en la pantalla');

  const box = node.getBoundingClientRect();
  const cx = box.left + box.width / 2;
  const cy = box.top + box.height / 2;
  const event = (type, x, y) => new panel.window.MouseEvent(type, {
    clientX: x, clientY: y, bubbles: true, cancelable: true,
  });
  node.dispatchEvent(event('pointerdown', cx, cy));
  node.dispatchEvent(event('pointermove', cx + 60, cy + 40));
  node.dispatchEvent(event('pointerup', cx + 60, cy + 40));
  await panel.settle(300);

  // While the pointer is down the frames go out live; when it is let go, the
  // position is saved. Either one means the object was moved and not just
  // painted, which is the bug this guards.
  assert.ok(
    panel.asked.some((call) => call.startsWith('PATCH') && call.includes('/api/objects/')),
    `el arrastre tiene que salir a la API; se pidio: ${panel.asked.join(', ')}`,
  );
  assert.deepEqual(
    panel.noise.filter((line) => !line.includes('conectando')),
    [],
    'arrastrar no debe quejarse',
  );
});