import assert from 'node:assert/strict';
import { spawn, spawnSync } from 'node:child_process';
import { once } from 'node:events';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import test, { after, before } from 'node:test';
import { WebSocket } from 'ws';

import { REACH } from '../public/geometry.js';
import { sanitizeObject } from '../server/scenes.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const assets = path.join(here, 'assets');
const PORT = 8899 + (process.pid % 200);
const BASE = `http://127.0.0.1:${PORT}`;
const TOKEN = 'test-token-1234567890';
const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'd2o-test-'));
const scratch = fs.mkdtempSync(path.join(os.tmpdir(), 'd2o-assets-'));
const mediaDir = path.join(dataDir, 'media');

let child = null;
let seq = 0;
let sessionCookie = '';

const ADMIN = { username: 'ana', password: 'clave-admin-123', role: 'admin' };
const MOD = { username: 'bea', password: 'clave-mod-456', role: 'mod' };

/** Creates accounts with the same cli the installer uses. */
function seedUsers(dataDirectory) {
  const result = spawnSync(
    process.execPath,
    [
      path.join(root, 'server', 'cli-users.js'),
      'add',
      ADMIN.username,
      '--role',
      ADMIN.role,
      '--password',
      ADMIN.password,
    ],
    { env: { ...process.env, D2O_DATA_DIR: dataDirectory }, encoding: 'utf8' },
  );
  if (result.status !== 0) throw new Error(`cli-users failed: ${result.stderr}`);
  const mod = spawnSync(
    process.execPath,
    [
      path.join(root, 'server', 'cli-users.js'),
      'add',
      MOD.username,
      '--role',
      MOD.role,
      '--password',
      MOD.password,
    ],
    { env: { ...process.env, D2O_DATA_DIR: dataDirectory }, encoding: 'utf8' },
  );
  if (mod.status !== 0) throw new Error(`cli-users failed: ${mod.stderr}`);
}

/* ----------------------------- test helpers ----------------------------- */

function startServer() {
  child = spawn(process.execPath, [path.join(root, 'server', 'index.js')], {
    env: {
      ...process.env,
      D2O_PORT: String(PORT),
      D2O_HOST: '127.0.0.1',
      D2O_DATA_DIR: dataDir,
      D2O_TOKEN: TOKEN,
      D2O_LOG_REQUESTS: 'false',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  child.stdout.resume();
  child.stderr.resume();
}

/** Polls until check() returns truthy. */
async function waitFor(check, timeoutMs = 5000, message = 'no se cumplió la condición') {
  const deadline = Date.now() + timeoutMs;
  for (;;) {
    if (await check()) return;
    if (Date.now() > deadline) assert.fail(message);
    await new Promise((r) => setTimeout(r, 100));
  }
}

async function waitForServer(timeoutMs = 15000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const res = await fetch(`${BASE}/healthz`);
      if (res.ok) return;
    } catch {
      /* not up yet */
    }
    await new Promise((r) => setTimeout(r, 100));
  }
  throw new Error('server did not start');
}

async function stopServer() {
  if (!child) return;
  const proc = child;
  child = null;
  proc.kill('SIGTERM');
  const timer = setTimeout(() => proc.kill('SIGKILL'), 4000);
  await once(proc, 'exit');
  clearTimeout(timer);
}

function api(pathname, options = {}) {
  return fetch(`${BASE}${pathname}`, {
    ...options,
    headers: {
      authorization: `Bearer ${TOKEN}`,
      ...(sessionCookie ? { cookie: sessionCookie } : {}),
      ...(typeof options.body === 'string' ? { 'content-type': 'application/json' } : {}),
      ...(options.headers ?? {}),
    },
  });
}

/** The stage token on its own: reads yes, writes no. */
function tokenOnly(pathname, options = {}) {
  return fetch(`${BASE}${pathname}`, {
    ...options,
    headers: {
      authorization: `Bearer ${TOKEN}`,
      ...(typeof options.body === 'string' ? { 'content-type': 'application/json' } : {}),
      ...(options.headers ?? {}),
    },
  });
}

async function login(username, password) {
  const res = await fetch(`${BASE}/api/auth/login`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ username, password }),
  });
  const setCookie = res.headers.get('set-cookie') ?? '';
  const cookie = setCookie.split(';')[0] ?? '';
  const body = await json(res);
  return { res, cookie, setCookie, body };
}

async function json(response) {
  const text = await response.text();
  return text ? JSON.parse(text) : {};
}

/** Upload the real fixture files, keeping their original names. */
async function upload(...names) {
  const form = new FormData();
  for (const name of names) {
    const buf = fs.readFileSync(path.join(assets, name));
    form.append('files', new Blob([buf]), name);
  }
  const res = await api('/api/upload', { method: 'POST', body: form });
  assert.equal(res.status, 200, `upload failed: ${res.status} ${await res.clone().text()}`);
  return json(res);
}

/** Upload a throwaway copy of a fixture under a unique name. */
async function uploadUnique(kind = 'png') {
  seq += 1;
  const source = {
    png: 'rojo-1280x720.png',
    mp4: 'clip.mp4',
    gif: 'anim.gif',
    txt: 'nota.txt',
    mp3: 'nota.mp3',
  }[kind];
  const name = `l${seq}.${kind}`;
  const target = path.join(scratch, name);
  fs.copyFileSync(path.join(assets, source), target);
  const form = new FormData();
  form.append('files', new Blob([fs.readFileSync(target)]), name);
  const res = await api('/api/upload', { method: 'POST', body: form });
  assert.equal(res.status, 200);
  const body = await json(res);
  return body.uploads[0];
}

// The cut on the long screen: above it is emission, below it is the bank. It is
// the only thing that separates the two now.
const CUT = 1080;

/** Everything on the one long screen, in draw order. */
const objects = (workspace) => workspace.scenes.program.objects;
/** The long screen as numbers, the same shape the server works with. */
const SCREEN = { width: 1920, height: CUT * 2 };

/**
 * Uploads some sample files straight onto the long screen, and returns those
 * objects. `where` is 'air' or 'bank': it picks the y, which is what decides
 * whether the file goes out or waits.
 */
async function placeUnique(where, ...kinds) {
  const uploads = [];
  for (const kind of kinds.length ? kinds : ['png']) uploads.push(await uploadUnique(kind));
  const res = await api('/api/scenes/program/place', {
    method: 'POST',
    body: JSON.stringify({
      ids: uploads.map((u) => u.id),
      x: 240,
      y: where === 'air' ? 240 : CUT + 240,
    }),
  });
  assert.equal(res.status, 200);
  const body = await json(res);
  return body.objects.filter((o) => uploads.some((u) => u.name === o.name));
}

async function waitForMessage(messages, predicate, timeoutMs = 5000, label = 'mensaje') {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const found = messages.find(predicate);
    if (found) return found;
    await new Promise((r) => setTimeout(r, 25));
  }
  throw new Error(`timeout esperando ${label}`);
}

function mediaFiles() {
  return fs.readdirSync(mediaDir).sort();
}

/* --------------------------------- setup --------------------------------- */

before(async () => {
  seedUsers(dataDir);
  startServer();
  await waitForServer();
  const session = await login(ADMIN.username, ADMIN.password);
  assert.equal(session.res.status, 200, `admin login failed: ${JSON.stringify(session.body)}`);
  sessionCookie = session.cookie;
});

after(async () => {
  await stopServer();
  fs.rmSync(dataDir, { recursive: true, force: true });
  fs.rmSync(scratch, { recursive: true, force: true });
});

/* --------------------------------- tests --------------------------------- */

test('healthz is public and reports the revision', async () => {
  const res = await fetch(`${BASE}/healthz`);
  assert.equal(res.status, 200);
  const body = await json(res);
  assert.equal(body.ok, true);
  assert.equal(body.rev, 0);
  assert.equal(body.screens, 0);
});

test('api rejects requests without a token', async () => {
  assert.equal((await fetch(`${BASE}/api/state`)).status, 401);
});

test('html without a session is sent to the login page, assets included', async () => {
  const res = await fetch(`${BASE}/`, {
    headers: { accept: 'text/html' },
    redirect: 'manual',
  });
  assert.equal(res.status, 302);
  assert.equal(res.headers.get('location'), '/login?next=%2F');

  const page = await fetch(`${BASE}/login`);
  assert.equal(page.status, 200);
  const html = await page.text();
  assert.match(html, /name="username"/);
  assert.match(html, /name="password"/);
  assert.match(html, /login\.css/);
  assert.match(html, /login\.js/);

  const css = await fetch(`${BASE}/login.css`);
  assert.equal(css.status, 200, 'el css del login no puede pedir contraseña');
  assert.match(css.headers.get('content-type') ?? '', /text\/css/);

  const js = await fetch(`${BASE}/login.js`);
  assert.equal(js.status, 200, 'el js del login no puede pedir contraseña');
  assert.match(js.headers.get('content-type') ?? '', /javascript/);
});

test('a valid token becomes a stage cookie, never a user session', async () => {
  const res = await fetch(`${BASE}/?t=${TOKEN}`, {
    headers: { accept: 'text/html' },
    redirect: 'manual',
  });
  assert.equal(res.status, 302);
  assert.equal(res.headers.get('location'), '/', 'el token se quita de la url');
  const cookie = res.headers.get('set-cookie') ?? '';
  assert.match(cookie, /d2o_session=/);
  assert.doesNotMatch(cookie, /d2o_user=/);
  const stage = cookie.split(';')[0];

  // the stage cookie reads fine, but the control page is not for it
  const follow = await fetch(`${BASE}/api/state`, { headers: { cookie: stage } });
  assert.equal(follow.status, 200);

  const page = await fetch(`${BASE}/`, {
    headers: { cookie: stage, accept: 'text/html' },
    redirect: 'manual',
  });
  assert.equal(page.status, 302);
  assert.equal(page.headers.get('location'), '/login?next=%2F', 'el token no abre la gestión');

  const write = await fetch(`${BASE}/api/scenes/program/place`, {
    method: 'POST',
    headers: { cookie: stage, 'content-type': 'application/json' },
    body: JSON.stringify({ ids: [] }),
  });
  assert.equal(write.status, 401);
  assert.equal((await json(write)).error, 'login_required');
});

test('uploads are classified and still images report their real size', async () => {
  const { uploads } = await upload('rojo-1280x720.png', 'clip.mp4', 'anim.gif', 'nota.txt');
  assert.equal(uploads.length, 4);
  const byName = Object.fromEntries(uploads.map((u) => [u.name, u]));
  assert.equal(byName['rojo-1280x720.png'].kind, 'image');
  assert.equal(byName['rojo-1280x720.png'].width, 1280);
  assert.equal(byName['rojo-1280x720.png'].height, 720);
  assert.equal(byName['clip.mp4'].kind, 'video');
  assert.equal(byName['anim.gif'].kind, 'image', 'animated images are plain images now');
  assert.equal(byName['nota.txt'].kind, 'browser');
  for (const up of uploads) {
    assert.ok(fs.existsSync(path.join(mediaDir, up.file)), 'file lands in the media dir');
  }
});

test('files with no drop point land in the bank, never on air', async () => {
  const { uploads } = await upload('rojo-1280x720.png', 'clip.mp4', 'anim.gif', 'nota.txt');
  const res = await api('/api/scenes/program/place', {
    method: 'POST',
    body: JSON.stringify({ ids: uploads.map((u) => u.id) }),
  });
  assert.equal(res.status, 200);
  const body = await json(res);
  assert.equal(body.objects.length, 4, 'los cuatro van a la pantalla');
  assert.ok(
    body.objects.every((o) => o.y >= CUT),
    'sin punto de soltado, todo cae bajo el corte y no se emite',
  );

  const state = await json(await api('/api/state'));
  assert.equal(state.cut, CUT, 'el corte viaja con el estado para que la fuente recorte');
  assert.ok(
    state.program.objects.every((o) => o.y >= CUT),
    'nada de lo que se coloca sin querer sale en directo',
  );
  for (const up of uploads) {
    assert.equal(state.uploads.find((u) => u.id === up.id), undefined, 'el archivo se consume al colocarlo');
  }
});

test('a second drop stacks instead of replacing', async () => {
  const before = await json(await api('/api/workspace'));
  const there = objects(before).length;
  const placed = await placeUnique('bank', 'png', 'gif');
  assert.equal(placed.length, 2);
  const state = await json(await api('/api/workspace'));
  assert.equal(objects(state).length, there + 2, 'lo que ya estaba sigue en su sitio');
});

test('media is served with a signed url and refuses unsigned requests', async () => {
  const object = (await placeUnique('bank', 'png')).at(-1);
  assert.match(object.url, /\/media\/[a-z0-9]+\.png\?k=/);

  const ok = await fetch(object.url);
  assert.equal(ok.status, 200);
  const expected = fs.statSync(path.join(assets, 'rojo-1280x720.png')).size;
  assert.equal(Number(ok.headers.get('content-length')), expected);
  assert.match(ok.headers.get('accept-ranges') ?? '', /bytes/, 'range requests are supported');
  assert.match(ok.headers.get('content-type') ?? '', /image\/png/);

  assert.equal((await fetch(object.url.replace(/k=.*/, 'k=basura'))).status, 403);
  assert.equal((await fetch(object.url.split('?')[0])).status, 403);
  assert.equal((await fetch(`${BASE}/media/%2e%2e%2ftoken.txt?k=x`)).status, 403);
  assert.equal((await fetch(`${BASE}/media/token.txt?k=x`)).status, 403);
});

test('objects can be hidden, shown and deleted', async () => {
  const object = (await placeUnique('bank', 'mp4')).at(-1);
  assert.equal(object.visible, true);

  await api(`/api/objects/${object.id}`, { method: 'PATCH', body: JSON.stringify({ visible: false }) });
  let state = await json(await api('/api/workspace'));
  assert.equal(objects(state).find((o) => o.id === object.id).visible, false);

  await api(`/api/objects/${object.id}`, { method: 'PATCH', body: JSON.stringify({ visible: true }) });
  state = await json(await api('/api/workspace'));
  assert.equal(objects(state).find((o) => o.id === object.id).visible, true);

  const filesBefore = mediaFiles().length;
  assert.equal((await api(`/api/objects/${object.id}`, { method: 'DELETE' })).status, 200);
  state = await json(await api('/api/workspace'));
  assert.equal(objects(state).find((o) => o.id === object.id), undefined);
  assert.equal(mediaFiles().length, filesBefore - 1, 'borrar un objeto borra su archivo');

  assert.equal((await api('/api/objects/does-not-exist', { method: 'DELETE' })).status, 404);
});

test('an object cannot be moved out of the screen for good', async () => {
  // A file pushed past the panel would be impossible to click again, so it could
  // neither be moved back nor deleted from the control page.
  const object = (await placeUnique('air', 'png')).at(-1);
  const res = await api(`/api/objects/${object.id}`, {
    method: 'PATCH',
    body: JSON.stringify({ x: 9000, y: 9000 }),
  });
  assert.equal(res.status, 200);
  const state = await json(await api('/api/workspace'));
  const found = objects(state).find((o) => o.id === object.id);
  assert.ok(found, 'el objeto sigue en la pantalla');
  assert.ok(found.x + REACH <= SCREEN.width, 'asoma por la derecha, así que se puede coger');
  assert.ok(found.y + REACH <= SCREEN.height, 'y por abajo');
  assert.ok(found.x + found.w >= REACH && found.y + found.h >= REACH, 'y por los otros dos lados');
});

test('a clip starts with sound, looping, and remembers both', async () => {
  const object = (await placeUnique('bank', 'mp4')).at(-1);
  assert.equal(object.render, 'media');
  assert.equal(object.volume, 1, 'un video nuevo suena entero en OBS');
  assert.equal(object.muted, false, 'y no empieza callado');
  assert.equal(object.loop, true, 'y se repite hasta que se le diga lo contrario');

  await api(`/api/objects/${object.id}`, { method: 'PATCH', body: JSON.stringify({ muted: true }) });
  const muted = (await json(await api('/api/workspace')))
    .scenes.program.objects.find((o) => o.id === object.id);
  assert.equal(muted.muted, true, 'silenciarlo se guarda');
  assert.equal(muted.loop, true, 'sin tocar el bucle');

  await api(`/api/objects/${object.id}`, { method: 'PATCH', body: JSON.stringify({ loop: false }) });
  const state = await json(await api('/api/workspace'));
  const found = objects(state).find((o) => o.id === object.id);
  assert.equal(found.muted, true);
  assert.equal(found.loop, false, 'quitar el bucle tambien se guarda');

  // Y lo ve el OBS, que es donde importa.
  const stage = await json(await api('/api/state'));
  assert.equal(stage.program.objects.find((o) => o.id === object.id).muted, true);
});

test('the volume of a clip is a level, not a switch', async () => {
  const object = (await placeUnique('bank', 'mp4')).at(-1);
  const read = async () => objects(await json(await api('/api/workspace')))
    .find((o) => o.id === object.id);

  // A media file can be turned down as well as off.
  for (const volume of [0.5, 0.25, 1, 0]) {
    await api(`/api/objects/${object.id}`, {
      method: 'PATCH',
      body: JSON.stringify({ volume }),
    });
    const found = await read();
    assert.equal(found.volume, volume, `el volumen ${volume} se guarda`);
    assert.equal(found.muted, volume === 0, 'el mute es solo el cero de siempre');
  }

  // Fuera de rango no se cuela nada: se queda en la orilla.
  for (const [sent, wanted] of [[9, 1], [-3, 0], [1.7, 1]]) {
    await api(`/api/objects/${object.id}`, {
      method: 'PATCH',
      body: JSON.stringify({ volume: sent }),
    });
    assert.equal((await read()).volume, wanted, `${sent} se recorta a ${wanted}`);
  }

  // El que mueve el mando es el OBS, no este panel.
  await api(`/api/objects/${object.id}`, { method: 'PATCH', body: JSON.stringify({ volume: 0.4 }) });
  const stage = await json(await api('/api/state'));
  assert.equal(stage.program.objects.find((o) => o.id === object.id).volume, 0.4);

  // El interruptor viejo sigue valiendo, por si algo lo sigue usando.
  await api(`/api/objects/${object.id}`, { method: 'PATCH', body: JSON.stringify({ muted: true }) });
  assert.equal((await read()).volume, 0, 'silenciar es volumen cero');
  await api(`/api/objects/${object.id}`, { method: 'PATCH', body: JSON.stringify({ muted: false }) });
  assert.equal((await read()).volume, 1, 'y quitarlo es volumen entero');
});

test('an object saved before the slider existed keeps its silence', async () => {
  // Lo que se guardaba era el interruptor: al leerlo, ese silencio es el cero
  // del volumen, y un objeto que no estaba callado suena entero.
  assert.equal(sanitizeObject({ name: 'clip.mp4', muted: true }, { width: 1920, height: 1080 }).volume, 0);
  assert.equal(sanitizeObject({ name: 'clip.mp4', muted: false }, { width: 1920, height: 1080 }).volume, 1);
  assert.equal(sanitizeObject({ name: 'clip.mp4' }, { width: 1920, height: 1080 }).volume, 1);
  assert.equal(sanitizeObject({ name: 'clip.mp4', volume: 0.3 }, { width: 1920, height: 1080 }).volume, 0.3);
});

test('an mp3 is sound with a face, not an empty box', async () => {
  const upload0 = await uploadUnique('mp3');
  assert.equal(upload0.kind, 'video', 'un audio entra por la puerta de los clips');
  const placed = await api('/api/scenes/program/place', {
    method: 'POST',
    body: JSON.stringify({ ids: [upload0.id], y: 40 }),
  });
  assert.equal(placed.status, 200);
  const object = (await json(placed)).objects[0];
  assert.equal(object.render, 'media', 'suena');
  assert.equal(object.audioOnly, true, 'y el escenario sabe que no tiene imagen');
  assert.equal(object.volume, 1, 'y entra con su volumen entero');
  // Una tarjeta con un nombre y cinco barras no necesita el cuarenta por ciento
  // de la pantalla: sale con una caja de su propio tamano.
  assert.ok(object.h <= 200, `alto ${object.h}: es una tarjeta, no un cuadro`);
  assert.ok(object.w <= 640, `ancho ${object.w}: tampoco hace falta mas`);

  // Un mp4 sigue siendo un clip con imagen: no se le pega la tarjeta.
  const video = (await placeUnique('air', 'mp4')).at(-1);
  assert.equal(video.audioOnly, false, 'un video no lleva la marca de audio');

  // Y el volumen se le baja igual que a cualquier clip.
  await api(`/api/objects/${object.id}`, { method: 'PATCH', body: JSON.stringify({ volume: 0.3 }) });
  const found = objects(await json(await api('/api/workspace'))).find((o) => o.id === object.id);
  assert.equal(found.volume, 0.3, 'el mp3 tambien tiene volumen propio');
  assert.equal(found.audioOnly, true, 'y sigue siendo audio-only con el volumen bajo');
});

test('a text can be put on the screen with no file at all', async () => {
  const res = await api('/api/objects', {
    method: 'POST',
    body: JSON.stringify({ scene: 'program', render: 'text', name: 'Rotulo', text: 'Hola' }),
  });
  assert.equal(res.status, 201);
  const object = (await json(res)).object;
  assert.equal(object.render, 'text');
  assert.equal(object.text, 'Hola');
  // Out of the box a label is Arial, big and white: readable over anything.
  assert.equal(object.textFont, 'arial');
  assert.equal(object.textSize, 96);
  assert.equal(object.textColor, '#ffffff');
  assert.equal(object.textAlign, 'center');
  // The stage does not need to know the list of fonts, only the stack to apply.
  assert.match(object.textFontStack, /Arial/);

  // The words and the look travel to the OBS source with everything else.
  const stage = await json(await api('/api/state'));
  const found = stage.program.objects.find((o) => o.id === object.id);
  assert.equal(found.text, 'Hola');
  assert.equal(found.textFontStack, object.textFontStack);
});

test('a new text lands in the bank, with a box shaped like a label', async () => {
  const res = await api('/api/objects', {
    method: 'POST',
    body: JSON.stringify({ scene: 'program', render: 'text', text: 'Hola' }),
  });
  const object = (await json(res)).object;
  // Nothing asked for a place, so it waits in the bank: something nobody has
  // placed yet has no business going out on air.
  assert.ok(object.y >= CUT, `y ${object.y} esta en el banco (corte ${CUT})`);
  assert.ok(Number.isFinite(object.x) && Number.isFinite(object.y), 'las coordenadas son numeros');
  // And a caption sized box, not the forty percent a picture gets.
  assert.ok(object.h < CUT * 0.5, `alto ${object.h}: es una etiqueta, no un cuadro`);
  assert.ok(object.w > 900, `ancho ${object.w}: cabe una linea`);

  // Un sitio concreto se respeta, como en cualquier otro objeto.
  const placed = await api('/api/objects', {
    method: 'POST',
    body: JSON.stringify({ scene: 'program', render: 'text', text: 'Arriba', x: 200, y: 300 }),
  });
  const onAir = (await json(placed)).object;
  assert.equal(onAir.x, 200);
  assert.equal(onAir.y, 300);
  assert.ok(onAir.y < CUT, 'y este si se pidio en directo');
  await api(`/api/objects/${onAir.id}`, { method: 'DELETE' });
  await api(`/api/objects/${object.id}`, { method: 'DELETE' });
});

test('the typefaces the app carries are served to whoever draws the stream', async () => {
  // The OBS source runs on another computer: if these do not come out of the
  // server itself, a label would come out in whatever that machine defaults to.
  for (const file of [
    'liberation-sans-regular.woff2',
    'liberation-sans-bold.woff2',
    'comic-neue-regular.woff2',
    'comic-neue-bold.woff2',
  ]) {
    const res = await fetch(`${BASE}/fuentes/${file}`);
    assert.equal(res.status, 200, `${file} se sirve`);
    assert.match(res.headers.get('content-type') ?? '', /woff2/, `${file} va como fuente`);
    assert.ok(Number(res.headers.get('content-length')) > 1000, `${file} no viene vacia`);
  }
  // Y la pagina las declara, que es lo que hace que el navegador las use.
  const css = await (await api('/stage.css')).text();
  assert.match(css, /@font-face/, 'stage.css declara las fuentes');
  assert.match(css, /comic-neue-regular\.woff2/, 'con la de Comic Sans');
  assert.match(css, /liberation-sans-regular\.woff2/, 'y la de Arial');
});

test('a text only draws what the server is willing to draw', async () => {
  const res = await api('/api/objects', {
    method: 'POST',
    body: JSON.stringify({ scene: 'program', render: 'text', text: 'x' }),
  });
  const object = (await json(res)).object;
  const id = object.id;

  // Una mano malintencionada no puede inventarse una fuente ni un color: esto
  // acaba en el estilo de la fuente de navegador del OBS.
  const bad = await api(`/api/objects/${id}`, {
    method: 'PATCH',
    body: JSON.stringify({
      textFont: 'url(https://malo.example/x.css)',
      textColor: 'red; background-image: url(https://malo.example/x.png)',
      textSize: 99999,
      textAlign: 'sideways',
    }),
  });
  assert.equal(bad.status, 200);
  const saved = (await json(bad)).object;
  assert.equal(saved.textFont, 'arial', 'la fuente cae en la de por defecto');
  assert.equal(saved.textColor, '#ffffff', 'el color cae en el de por defecto');
  assert.equal(saved.textSize, 800, 'el tamaño se recorta al máximo');
  assert.equal(saved.textAlign, 'center', 'una alineación rara cae en la de por defecto');
  assert.doesNotMatch(saved.textFontStack, /url|https/, 'la pila de fuentes es solo una lista');

  // Y lo que se manda de verdad, si se manda, se guarda.
  const good = await api(`/api/objects/${id}`, {
    method: 'PATCH',
    body: JSON.stringify({ textFont: 'comic', textSize: 120, textColor: '#3ddc84', textAlign: 'left', text: 'Ey' }),
  });
  const painted = (await json(good)).object;
  assert.equal(painted.textFont, 'comic');
  assert.match(painted.textFontStack, /Comic/);
  assert.equal(painted.textSize, 120);
  assert.equal(painted.textColor, '#3ddc84');
  assert.equal(painted.textAlign, 'left');
  assert.equal(painted.text, 'Ey');

  // Un texto endless se corta: el estado guardado no crece sin control.
  const huge = await api(`/api/objects/${id}`, {
    method: 'PATCH',
    body: JSON.stringify({ text: 'a'.repeat(5000) }),
  });
  assert.equal((await json(huge)).object.text.length, 2000);

  await api(`/api/objects/${id}`, { method: 'DELETE' });
});

test('the font picker is built from the list the server sends', async () => {
  const { fonts } = await json(await api('/api/workspace'));
  assert.ok(Array.isArray(fonts) && fonts.length >= 3, 'hay tipografias para elegir');
  const wanted = ['arial', 'comic', 'papyrus'];
  for (const id of wanted) {
    assert.ok(fonts.some((f) => f.id === id), `se ofrece ${id}`);
  }
  // Y un objeto sin archivo pero sin ser texto sigue siendo un error.
  const noFile = await api('/api/objects', {
    method: 'POST',
    body: JSON.stringify({ scene: 'program', name: 'nada' }),
  });
  assert.equal(noFile.status, 400);
});

test('a replay is stamped by the server so the stream gets it too', async () => {
  const object = (await placeUnique('bank', 'mp4')).at(-1);
  assert.equal(object.playAt, 0, 'nada ha sonado todavia');
  const before = Date.now();
  const res = await api(`/api/objects/${object.id}`, {
    method: 'PATCH',
    body: JSON.stringify({ replay: true }),
  });
  assert.equal(res.status, 200);
  const saved = (await json(res)).object;
  assert.ok(saved, 'el PATCH devuelve el objeto guardado');
  assert.ok(saved.playAt >= before, 'el servidor pone la hora, no el navegador');
  assert.ok(saved.playAt <= Date.now());

  // Un PATCH que no lo pide no lo inventa: el bucle no reinicia solo.
  await api(`/api/objects/${object.id}`, { method: 'PATCH', body: JSON.stringify({ loop: false }) });
  const after = objects(await json(await api('/api/workspace'))).find((o) => o.id === object.id);
  assert.equal(after.playAt, saved.playAt, 'mover o cambiar el bucle no reinicia el clip');
});

test('the show goes off the air and comes back exactly as it was', async () => {
  const object = (await placeUnique('air', 'png')).at(-1);

  const res = await api('/api/hidden', { method: 'POST', body: JSON.stringify({ hidden: true }) });
  assert.equal(res.status, 200);
  assert.equal((await json(res)).hidden, true);
  const stage = await json(await api('/api/state'));
  assert.equal(stage.hidden, true, 'la fuente de OBS lo ve de inmediato');
  assert.equal((await json(await api('/api/workspace'))).hidden, true, 'y el panel tambien');
  // Ocultar no borra nada ni mueve nada: por eso volver es seguro.
  assert.ok(
    stage.program.objects.some((o) => o.id === object.id),
    'el objeto sigue ahi, intacto',
  );

  // Sin decir que estado se quiere, alterna.
  const back = await api('/api/hidden', { method: 'POST', body: '{}' });
  assert.equal((await json(back)).hidden, false);
  assert.equal((await json(await api('/api/state'))).hidden, false);

  // Y aguanta que lo machaquen muchas veces.
  for (const hidden of [true, false, true, false]) {
    const step = await api('/api/hidden', { method: 'POST', body: JSON.stringify({ hidden }) });
    assert.equal((await json(step)).hidden, hidden);
    assert.equal((await json(await api('/api/state'))).hidden, hidden);
  }
  await api('/api/hidden', { method: 'POST', body: JSON.stringify({ hidden: false }) });
});

test('only an administrator takes the show off the air from the web', async () => {
  const mod = await login(MOD.username, MOD.password);
  const denied = await fetch(`${BASE}/api/hidden`, {
    method: 'POST',
    headers: { cookie: mod.cookie, 'content-type': 'application/json' },
    body: JSON.stringify({ hidden: true }),
  });
  assert.equal(denied.status, 403, 'un moderador no corta la emission');
  assert.equal((await json(await api('/api/state'))).hidden, false, 'y no ha cambiado nada');

  const admin = await fetch(`${BASE}/api/hidden`, {
    method: 'POST',
    headers: { cookie: sessionCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ hidden: true }),
  });
  assert.equal(admin.status, 200);
  assert.equal((await json(admin)).hidden, true);
  await api('/api/hidden', { method: 'POST', body: JSON.stringify({ hidden: false }) });
});

test('only the control key opens the stream deck route', async () => {
  const key = fs.readFileSync(path.join(dataDir, 'control.txt'), 'utf8').trim();
  assert.ok(key.length >= 16, 'la clave se guarda en el directorio de datos');

  // Sin clave no se entra, y la clave de la fuente de OBS tampoco vale: esa va
  // pegada en el OBS de quien retransmite y es de solo lectura.
  assert.equal((await fetch(`${BASE}/api/control/hidden`)).status, 401, 'sin nada');
  assert.equal((await tokenOnly('/api/control/hidden')).status, 401, 'con la clave de la fuente');
  assert.equal(
    (await fetch(`${BASE}/api/control/hidden?key=inventada`)).status, 401,
    'con una clave inventada',
  );

  // Un GET alterna, que es lo que un boton con una sola url puede hacer.
  const off = await json(await fetch(`${BASE}/api/control/hidden?key=${encodeURIComponent(key)}`));
  assert.equal(off.hidden, true);
  assert.equal((await json(await api('/api/state'))).hidden, true, 'la fuente lo obeye');
  const on = await json(await fetch(`${BASE}/api/control/hidden?key=${encodeURIComponent(key)}`));
  assert.equal(on.hidden, false);
  assert.equal((await json(await api('/api/state'))).hidden, false);

  // Tambien por cabecera, y un POST puede fijar el estado en vez de alternarlo:
  // es lo que necesita un boton con un pulsador de "oculto" y otro de "visible".
  const forced = await fetch(`${BASE}/api/control/hidden`, {
    method: 'POST',
    headers: { 'x-d2o-control': key, 'content-type': 'application/json' },
    body: JSON.stringify({ hidden: true }),
  });
  assert.equal((await json(forced)).hidden, true);
  await api('/api/hidden', { method: 'POST', body: JSON.stringify({ hidden: false }) });
});

test('the history says what happened, when and who', async () => {
  const { uploads } = await upload('rojo-1280x720.png');
  const placed = await api('/api/scenes/program/place', {
    method: 'POST',
    body: JSON.stringify({ ids: uploads.map((u) => u.id), y: CUT + 200 }),
  });
  assert.equal(placed.status, 200, 'el archivo se coloca');
  const object = (await json(placed)).objects[0];
  await api(`/api/objects/${object.id}`, { method: 'DELETE' });

  const body = await json(await api('/api/history'));
  const mine = body.history.filter((e) => e.name === 'rojo-1280x720.png');
  assert.ok(mine.length >= 2, 'se subio y luego se quito');
  const actions = mine.map((e) => e.action);
  assert.ok(actions.includes('subido'), `esperaba subido, hay ${actions.join(', ')}`);
  assert.ok(actions.includes('quitado'), `esperaba quitado, hay ${actions.join(', ')}`);
  // Lo de colocarlo en el banco se apunta como tal, no como "en directo".
  assert.ok(mine.some((e) => e.action === 'al banco'), 'y queda claro que fue al banco');
  for (const entry of mine) {
    assert.ok(entry.at && !Number.isNaN(Date.parse(entry.at)), 'cada entrada tiene su hora');
    assert.ok(entry.who, 'y quien lo hizo');
  }

  // El primero que aparece es el mas reciente.
  const times = body.history.map((e) => Date.parse(e.at));
  assert.deepEqual(times, [...times].sort((a, b) => b - a), 'de lo mas reciente a lo mas viejo');
});

test('the moderator list has the accounts, connected first', async () => {
  const body = await json(await api('/api/history'));
  const names = body.moderators.map((m) => m.username);
  assert.ok(names.includes(MOD.username), 'el moderador que esta usando aparece');
  assert.ok(names.includes(ADMIN.username), 'y tambien el admin');
  for (const person of body.moderators) {
    assert.equal(typeof person.connected, 'boolean');
    assert.ok(person.role === 'admin' || person.role === 'mod');
  }
});

test('only an administrator can empty the history', async () => {
  const mod = await login(MOD.username, MOD.password);
  const denied = await fetch(`${BASE}/api/history`, {
    method: 'DELETE',
    headers: { cookie: mod.cookie },
  });
  assert.equal(denied.status, 403);

  // El test no puede dar por hecho que queda rastro de antes: lo provoca.
  const { uploads } = await upload('pequeno-64x64.png');
  await api('/api/scenes/program/place', {
    method: 'POST',
    body: JSON.stringify({ ids: [uploads.map((u) => u.id)] }),
  });
  const before = await json(await api('/api/history'));
  assert.ok(before.history.some((e) => e.name === 'pequeno-64x64.png'), 'hay algo que vaciar');
  const done = await api('/api/history', { method: 'DELETE' });
  assert.equal(done.status, 200);
  assert.ok((await json(done)).removed > 0);
  const after = await json(await api('/api/history'));
  assert.deepEqual(after.history, [], 'la lista queda limpia');
});

test('the history survives a restart', async () => {
  const { uploads } = await upload('nota.txt');
  await api('/api/scenes/program/place', {
    method: 'POST',
    body: JSON.stringify({ ids: [uploads.map((u) => u.id)] }),
  });
  await stopServer();
  startServer();
  await waitForServer();
  const body = await json(await api('/api/history'));
  assert.ok(body.history.some((e) => e.name === 'nota.txt'), 'el rastro sigue al arrancar');
});

test('an object patch only touches the fields it carries', async () => {
  // The toolbar sends one field at a time and the answers can cross, so the
  // second edit must not bring back the value the first one already replaced.
  const object = (await placeUnique('bank', 'mp4')).at(-1);
  await api(`/api/objects/${object.id}`, {
    method: 'PATCH', body: JSON.stringify({ w: 1280 }),
  });
  const read = async () => objects(await json(await api('/api/workspace')))
    .find((o) => o.id === object.id);
  assert.equal((await read()).w, 1280);
  assert.notEqual((await read()).h, 1280, 'el alto sigue como estaba');

  // A second patch with only the height must keep the width just saved.
  await api(`/api/objects/${object.id}`, {
    method: 'PATCH', body: JSON.stringify({ h: 720 }),
  });
  const both = await read();
  assert.equal(both.w, 1280);
  assert.equal(both.h, 720);
});

test('unknown uploads are rejected', async () => {
  const res = await api('/api/scenes/program/place', {
    method: 'POST',
    body: JSON.stringify({ ids: ['nope'] }),
  });
  assert.equal(res.status, 400);
  assert.equal((await json(res)).error, 'unknown_upload');
  assert.equal(
    (await api('/api/scenes/program/place', { method: 'POST', body: JSON.stringify({ ids: [] }) })).status,
    400,
  );
});

test('the screen keeps one contiguous z order across both halves', async () => {
  const before = await json(await api('/api/workspace'));
  assert.ok(objects(before).length > 0);
  for (let i = 0; i < 3; i += 1) await placeUnique('bank', 'txt');
  const after = await json(await api('/api/workspace'));
  const zs = objects(after).map((o) => o.z);
  assert.deepEqual(zs, [...zs].sort((a, b) => a - b), 'va de abajo arriba');
  assert.equal(new Set(zs).size, zs.length, 'no repite z');
});

test('clearing the bank removes only the lower half and its files', async () => {
  const air = await placeUnique('air', 'txt');
  const bank = await placeUnique('bank', 'txt');
  const before = await json(await api('/api/workspace'));
  const bankFiles = bank.map((o) => o.url.split('/media/')[1].split('?')[0]);
  const airFiles = air.map((o) => o.url.split('/media/')[1].split('?')[0]);
  assert.ok(objects(before).some((o) => o.y < CUT), 'habia algo en directo');
  assert.ok(objects(before).some((o) => o.y >= CUT), 'y algo en el banco');

  const res = await api('/api/bank', { method: 'DELETE' });
  assert.equal(res.status, 200);
  const after = await json(await api('/api/workspace'));
  assert.equal(objects(after).filter((o) => o.y >= CUT).length, 0, 'el banco queda vacio');
  assert.ok(objects(after).filter((o) => o.y < CUT).length > 0, 'lo que estaba en directo sigue ahi');
  for (const file of bankFiles) {
    assert.equal(fs.existsSync(path.join(mediaDir, file)), false, `${file} should be deleted`);
  }
  for (const file of airFiles) {
    assert.equal(fs.existsSync(path.join(mediaDir, file)), true, `${file} was live, it stays`);
  }
});

test('the stage websocket registers the screen and pushes state updates', async () => {
  const bad = new WebSocket(`ws://127.0.0.1:${PORT}/stage?id=abc&t=equivale`);
  const [badError] = await once(bad, 'error');
  assert.match(badError.message, /401/, 'unauthenticated sockets are rejected');

  const ws = new WebSocket(`ws://127.0.0.1:${PORT}/stage?id=stage-test-1&t=${TOKEN}`);
  const collected = [];
  ws.on('message', (raw) => collected.push(JSON.parse(raw.toString())));
  await once(ws, 'open');
  const opening = await waitForMessage(collected, (m) => m.type === 'state', 5000, 'estado inicial');
  assert.ok(opening.program, 'la pantalla recibe el lienzo');
  assert.equal(opening.cut, CUT, 'y el corte que decide que se emite');
  assert.equal(opening.program.height, CUT * 2, 'el lienzo es el doble de alto que la emisión');
  assert.equal(opening.scenes, undefined, 'y nunca la vista de gestión');

  ws.send(JSON.stringify({ type: 'hello', name: 'Pantalla de prueba', canvas: '1920x1080' }));
  await waitForMessage(
    collected,
    (m) => m.type === 'agents' && m.agents.some((a) => a.id === 'stage-test-1' && a.canvas === '1920x1080'),
    5000,
    'la pantalla aparece con su tamaño de lienzo',
  );

  const object = (await placeUnique('air', 'gif')).at(-1);
  const pushed = await waitForMessage(
    collected,
    (m) => m.type === 'state' && m.program?.objects?.some((o) => o.id === object.id),
    5000,
    'state con el objeto nuevo',
  );
  const broadcast = pushed.program.objects.find((o) => o.id === object.id);
  assert.match(broadcast.url, /127\.0\.0\.1/, 'los enlaces apuntan al host que se conectó');
  assert.equal(broadcast.render, 'image', 'los gif animados se dibujan como imagen');

  const screens = await json(await api('/api/state'));
  const mine = screens.agents.find((a) => a.id === 'stage-test-1');
  assert.equal(mine.kind, 'stage');
  assert.equal(mine.online, true);
  assert.equal(mine.name, 'Pantalla de prueba');

  ws.close();
  await new Promise((r) => setTimeout(r, 300));
  const gone = await json(await api('/api/state'));
  assert.equal(gone.agents.find((a) => a.id === 'stage-test-1').online, false);
});

test('a clip can be jumped to another moment, and every screen lands on it', async () => {
  const object = (await placeUnique('bank', 'mp4')).at(-1);

  // The moderator asks for a second; the server is the one that says when, so
  // that the OBS source and the panel work out the same moment on their own.
  const res = await api(`/api/objects/${object.id}`, {
    method: 'PATCH',
    body: JSON.stringify({ seek: 42.4 }),
  });
  assert.equal(res.status, 200);
  const saved = (await json(res)).object;
  assert.equal(saved.seek.pos, 42.4, 'el segundo pedido es el que queda');
  assert.ok(saved.seek.at > 0 && Date.now() - saved.seek.at < 5000, 'y el reloj lo pone el servidor');

  // Lo ve la fuente de OBS, no solo el panel.
  const stage = await json(await api('/api/state'));
  assert.equal(stage.program.objects.find((o) => o.id === object.id).seek.pos, 42.4);

  // Es un instante y no una posicion fija: cada pantalla suma por su cuenta el
  // tiempo que ha pasado, asi que el clip sigue avanzando donde se le dejo.
  assert.equal(typeof saved.seek.at, 'number', 'el reloj del servidor es un numero');
  assert.ok(saved.seek.at <= Date.now() + 2000, 'y no esta en el futuro');

  // Lo que no es un numero no entra, y un salto sin posicion se guarda como nulo.
  const junk = await api(`/api/objects/${object.id}`, {
    method: 'PATCH',
    body: JSON.stringify({ seek: 'muy lejos' }),
  });
  assert.equal((await json(junk)).object.seek.pos, 42.4, 'una tonteria no mueve el clip');
  const gone = await api(`/api/objects/${object.id}`, {
    method: 'PATCH',
    body: JSON.stringify({ seek: null }),
  });
  assert.equal((await json(gone)).object.seek, null, 'volver a empezar borra el salto');
});

test('the OBS source says it is alive, and its last draw travels with it', async () => {
  const id = 'stage-viva-1';
  const socket = new WebSocket(`ws://127.0.0.1:${PORT}/stage?id=${id}&t=${TOKEN}`);
  const heard = [];
  socket.on('message', (raw) => heard.push(JSON.parse(raw.toString())));
  await once(socket, 'open');
  socket.send(JSON.stringify({ type: 'hello', name: 'Pantalla OBS', canvas: '1920x1080' }));

  const before = await json(await api('/api/state'));
  const agent = before.agents.find((a) => a.id === id);
  assert.ok(agent, 'la fuente aparece en la lista');
  assert.equal(agent.kind, 'stage');
  assert.ok(Number.isFinite(Date.parse(agent.seenAt)), 'dice cuando se la vio por ultima vez');

  // El latido lleva cuanto lleva sin dibujar, que es lo que distingue una fuente
  // congelada de una que solo tarda en responder.
  const ageOf = (agents) => {
    const at = Date.parse(agents.find((a) => a.id === id)?.renderedAt ?? '');
    return Number.isFinite(at) ? Date.now() - at : Infinity;
  };
  socket.send(JSON.stringify({ type: 'alive', rendered: 4200, canvas: '1920x1080' }));
  await waitFor(async () => {
    const now = await json(await api('/api/state'));
    return Math.abs(ageOf(now.agents) - 4200) < 1500;
  }, 3000, 'no llego el dibujo de la fuente');
  assert.ok(ageOf((await json(await api('/api/state'))).agents) >= 4000, 'el instante del dibujo viaja al panel');
  void heard;

  // Y el instante no se desliza solo: una fuente que hace rato que no dibuja
  // tiene que seguir pareciendo vieja, no ponerse al dia con cada lectura.
  const first = Date.parse((await json(await api('/api/state'))).agents.find((a) => a.id === id).renderedAt);
  await new Promise((r) => setTimeout(r, 1500));
  const second = Date.parse((await json(await api('/api/state'))).agents.find((a) => a.id === id).renderedAt);
  assert.equal(second, first, 'el instante del dibujo se queda donde estaba');

  socket.close();
});

test('a source on the poll keeps presence even with no socket', async () => {
  // Sin socket la fuente funciona igual (sondea cada cuatro segundos), asi que
  // el panel no puede dar por perdida una fuente que solo ha perdido el socket.
  const id = 'stage-poll-1';
  const state = await json(await api(`/api/state?id=${encodeURIComponent(id)}`));
  const agent = state.agents.find((a) => a.id === id);
  assert.ok(agent, 'sondear tambien cuenta como estar alli');
  assert.equal(agent.source, 'poll');
  assert.equal(agent.kind, 'stage');
});

test('OBS stage sees only the on-air scene, never the private upload queue', async () => {
  const res = await tokenOnly('/api/state');
  assert.equal(res.status, 200);
  const data = await json(res);
  assert.equal(data.uploads, undefined);
  assert.ok(data.program, 'la pantalla OBS sigue recibiendo la escena');
  assert.ok(data.program.objects.every((o) => o.y < data.cut), 'OBS no ve los archivos preparados en el banco');
});

test('OBS-only token cannot access the private control WebSocket', async () => {
  const socket = new WebSocket(`ws://127.0.0.1:${PORT}/events?t=${TOKEN}`);
  const [err] = await once(socket, 'error');
  assert.match(err.message, /401/, 'la clave de pantalla no autoriza el canal de administracion');
});

test('cross-site browser origins cannot send live commands or read sockets', async () => {
  const denied = await fetch(`${BASE}/api/hidden`, {
    method: 'POST',
    headers: { cookie: sessionCookie, origin: 'https://sitio-falso.example', 'content-type': 'application/json' },
    body: JSON.stringify({ hidden: true }),
  });
  assert.equal(denied.status, 403);
  assert.equal((await denied.json()).error, 'origin_not_allowed');
  const cross = new WebSocket(`ws://127.0.0.1:${PORT}/events`, {
    headers: { cookie: sessionCookie, origin: 'https://sitio-falso.example' },
  });
  const [err] = await once(cross, 'error');
  assert.match(err.message, /401/);
});

test('the control page websocket accepts a signed in user and nobody else', async () => {
  const anon = new WebSocket(`ws://127.0.0.1:${PORT}/events`);
  const [anonError] = await once(anon, 'error');
  assert.match(anonError.message, /401/, 'sin sesión el socket de la web se rechaza');

  // A signed in moderator has no stage token: the socket must still open, or the
  // control page sits forever on "sin servidor".
  const mod = await login(MOD.username, MOD.password);
  const ws = new WebSocket(`ws://127.0.0.1:${PORT}/events`, { headers: { cookie: mod.cookie } });
  const collected = [];
  ws.on('message', (raw) => collected.push(JSON.parse(raw.toString())));
  await once(ws, 'open');
  const first = await waitForMessage(collected, (m) => m.type === 'state', 5000, 'estado inicial');
  assert.ok(first.program, 'el socket de la web recibe el estado de emisión');
  assert.equal(first.cut, CUT, 'con el corte que decide que se emite');
  assert.equal(first.scenes, undefined, 'sin la vista de gestión por este canal');

  const workspace = await waitForMessage(collected, (m) => m.type === 'workspace', 5000, 'vista de gestión');
  assert.ok(workspace.scenes?.program, 'la gestión dibuja la misma pantalla, con sus dos mitades');
  assert.equal(workspace.scenes.desk, undefined, 'ya no hay un segundo frame');

  const object = (await placeUnique('bank', 'gif')).at(-1);
  const pushed = await waitForMessage(
    collected,
    (m) => m.type === 'workspace' && m.scenes?.program?.objects?.some((o) => o.id === object.id),
    5000,
    'la web recibe los objetos nuevos sin recargar',
  );
  assert.equal(objects(pushed).find((o) => o.id === object.id).id, object.id);
  ws.close();
  await new Promise((r) => setTimeout(r, 200));

  // Once the moderator's session is gone their socket is refused again. The
  // request carries that session's own cookie: reusing api() would log the
  // administrator out and take every later admin test with it.
  const out = await fetch(`${BASE}/api/auth/logout`, {
    method: 'POST',
    headers: { cookie: mod.cookie },
  });
  assert.equal(out.status, 200);
  const after = new WebSocket(`ws://127.0.0.1:${PORT}/events`, { headers: { cookie: mod.cookie } });
  const [afterError] = await once(after, 'error');
  assert.match(afterError.message, /401/, 'al cerrar sesión el socket se rechaza');

  assert.equal((await api('/api/auth/me')).status, 200, 'la sesión del admin sigue en pie');
});

test('objects carry the render hint the stage needs', async () => {
  const { uploads } = await upload('rojo-1280x720.png', 'clip.mp4', 'anim.gif', 'nota.txt');
  const byName = Object.fromEntries(uploads.map((u) => [u.name, u]));
  assert.equal(byName['rojo-1280x720.png'].render, 'image');
  assert.equal(byName['clip.mp4'].render, 'media');
  assert.equal(byName['anim.gif'].render, 'image', 'los gif se dibujan con <img>');
  assert.equal(byName['nota.txt'].render, 'text');

  await api('/api/scenes/program/place', {
    method: 'POST',
    body: JSON.stringify({ ids: uploads.map((u) => u.id) }),
  });
  const state = await json(await api('/api/state'));
  assert.ok(state.program.objects.every((o) => typeof o.render === 'string' && o.render.length > 0));
  assert.equal(state.config.canvas, '1920x1080');
});

test('objects saved before the stage existed get a render hint on load', async () => {
  // Simulate an old state.json: a jpeg object with no render field at all. The
  // server is stopped first, or its own debounced save would race the write.
  const stateFile = path.join(dataDir, 'state.json');
  await stopServer();
  const saved = JSON.parse(fs.readFileSync(stateFile, 'utf8'));
  const sample = saved.scenes.program.objects.at(-1);
  assert.ok(sample, 'there is an object to mutate');
  const old = {
    ...saved,
    scenes: {
      ...saved.scenes,
      program: { ...saved.scenes.program, objects: [{ ...sample, render: undefined, name: 'backflip.jpeg' }] },
    },
    layers: [],
  };
  fs.writeFileSync(stateFile, JSON.stringify(old));

  startServer();
  await waitForServer();

  const state = await json(await api('/api/state'));
  assert.equal(state.program.objects.length, 1, 'only the fake old object survived');
  assert.equal(state.desk, undefined, 'OBS never sees a second frame');
  const workspace = await json(await api('/api/workspace'));
  assert.equal(objects(workspace).length, 1);
  assert.equal(
    objects(workspace)[0].render,
    'image',
    'un jpeg no se dibuja como texto',
  );
});

test('an old desk scene slides down into the bank on load', async () => {
  // A state.json from the two screen era: the emission half keeps its numbers
  // and the bank half moves down by the cut, so nothing appears to jump.
  const [liveSeed, bankSeed] = [
    (await placeUnique('air', 'png')).at(-1),
    (await placeUnique('bank', 'gif')).at(-1),
  ];
  const stateFile = path.join(dataDir, 'state.json');
  await stopServer();
  const saved = JSON.parse(fs.readFileSync(stateFile, 'utf8'));
  const byId = (id) => saved.scenes.program.objects.find((o) => o.id === id);
  // Both halves shared the 0..1080 range back then, so that is what is written.
  const live = { ...byId(liveSeed.id), y: 240 };
  const banked = { ...byId(bankSeed.id), y: 300 };
  assert.ok(live && banked, 'there are two objects to migrate');
  const old = {
    ...saved,
    scenes: {
      program: { ...saved.scenes.program, height: CUT, objects: [live] },
      desk: { ...saved.scenes.program, id: 'desk', height: CUT, objects: [banked] },
    },
    layers: [],
  };
  fs.writeFileSync(stateFile, JSON.stringify(old));

  startServer();
  await waitForServer();

  const workspace = await json(await api('/api/workspace'));
  const movedLive = objects(workspace).find((o) => o.id === liveSeed.id);
  const movedBank = objects(workspace).find((o) => o.id === bankSeed.id);
  assert.ok(movedLive && movedBank, 'los dos objetos siguen en la pantalla');
  assert.equal(movedLive.y, live.y, 'lo que estaba en directo no se mueve');
  assert.equal(movedLive.scene, 'program');
  assert.equal(movedBank.y, banked.y + CUT, 'lo del banco baja exactamente un corte');
  assert.equal(movedBank.scene, 'program', 'todo vive ya en la pantalla larga');
  assert.ok(movedBank.y + movedBank.h <= CUT * 2, 'y no se sale por abajo');

  const onDisk = JSON.parse(fs.readFileSync(stateFile, 'utf8'));
  assert.deepEqual(Object.keys(onDisk.scenes), ['program'], 'el archivo guardado ya es de una pantalla');
  assert.equal(onDisk.scenes.program.objects.length, 2);
  assert.equal(
    onDisk.scenes.program.objects.find((o) => o.id === bankSeed.id).y,
    banked.y + CUT,
    'con el banco ya abajo, no se volvería a mover en el siguiente arranque',
  );
});

test('the screen survives a restart and orphan files are collected', async () => {
  const before = await json(await api('/api/workspace'));
  const orphan = path.join(mediaDir, 'basura-999.png');
  fs.writeFileSync(orphan, 'x');

  await stopServer();
  startServer();
  await waitForServer();

  const afterRestart = await json(await api('/api/workspace'));
  assert.equal(afterRestart.cut, CUT, 'el corte sigue en su sitio');
  assert.deepEqual(
    objects(afterRestart).map((o) => o.id),
    objects(before).map((o) => o.id),
    'la pantalla sigue igual, mitad por mitad',
  );
  assert.equal(fs.existsSync(orphan), false, 'orphans are removed on boot');
  assert.equal(fs.readFileSync(path.join(dataDir, 'token.txt'), 'utf8').trim(), TOKEN);
});

test('media still downloads when the data dir has a dot in the path', async () => {
  // ~/.local/share, ~/.config/… : express refuses absolute paths that cross a
  // dot segment, so the media route has to send the basename with a root.
  const dottedRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'd2o-dotted-'));
  const dottedDir = path.join(dottedRoot, '.local', 'share', 'luckyobs');
  fs.mkdirSync(dottedDir, { recursive: true });
  const port = PORT + 1;
  const proc = spawn(process.execPath, [path.join(root, 'server', 'index.js')], {
    env: {
      ...process.env,
      D2O_PORT: String(port),
      D2O_HOST: '127.0.0.1',
      D2O_DATA_DIR: dottedDir,
      D2O_TOKEN: TOKEN,
      D2O_LOG_REQUESTS: 'false',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  proc.stdout.resume();
  proc.stderr.resume();
  const base = `http://127.0.0.1:${port}`;
  const call = (pathname, options = {}) =>
    fetch(`${base}${pathname}`, {
      ...options,
      headers: { authorization: `Bearer ${TOKEN}`, ...(options.headers ?? {}) },
    });

  try {
    const deadline = Date.now() + 15000;
    for (;;) {
      try {
        if ((await fetch(`${base}/healthz`)).ok) break;
      } catch {
        /* not up yet */
      }
      if (Date.now() > deadline) throw new Error('server did not start');
      await new Promise((r) => setTimeout(r, 100));
    }

    const form = new FormData();
    form.append('files', new Blob([fs.readFileSync(path.join(assets, 'rojo-1280x720.png'))]), 'punto.png');
    const uploaded = await json(await call('/api/upload', { method: 'POST', body: form }));
    assert.equal(uploaded.uploads.length, 1);

    const placed = await json(
      await call('/api/scenes/program/place', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ ids: [uploaded.uploads[0].id] }),
      }),
    );
    const url = placed.objects.at(-1).url.replace(base, '');
    const res = await call(url);
    assert.equal(res.status, 200, `media under a dotted data dir must download: ${url}`);
    assert.equal(Number(res.headers.get('content-length')), fs.statSync(path.join(assets, 'rojo-1280x720.png')).size);
  } finally {
    proc.kill('SIGTERM');
    await once(proc, 'exit');
    fs.rmSync(dottedRoot, { recursive: true, force: true });
  }
});

/* ------------------------------ authentication ----------------------------- */

test('a wrong password is refused without saying which account exists', async () => {
  const bad = await login(ADMIN.username, 'no-es-la-clave');
  assert.equal(bad.res.status, 401);
  assert.equal(bad.body.error, 'bad_credentials');

  const ghost = await login('no-existe', 'no-es-la-clave');
  assert.equal(ghost.res.status, 401);
  assert.deepEqual(ghost.body, bad.body, 'mismo error para cuentas inexistentes');
  assert.equal(ghost.cookie, '');
});

test('usernames ignore case and accents', async () => {
  const res = await login('ANA', ADMIN.password);
  assert.equal(res.res.status, 200);
  assert.equal(res.body.user.username, ADMIN.username);
  assert.equal(res.body.user.role, 'admin');
  assert.equal(res.body.authenticated, true);
  assert.ok(res.cookie.startsWith('d2o_user='), 'cookie de usuario separada de la del stage');
  assert.match(res.setCookie, /HttpOnly/);
  assert.match(res.setCookie, /SameSite=Lax/);
  assert.match(res.setCookie, /Max-Age=2592000/);

  const me = await json(
    await fetch(`${BASE}/api/auth/me`, { headers: { cookie: res.cookie } }),
  );
  assert.equal(me.user.username, ADMIN.username);
  assert.equal(me.tokenFallback, false, 'ya hay cuentas: el token no basta');
});

test('an unknown path, weak passwords and duplicates are rejected', async () => {
  const weak = await json(
    await api('/api/auth/users', {
      method: 'POST',
      body: JSON.stringify({ username: 'corto', password: 'corta' }),
    }),
  );
  assert.equal(weak.error, 'weak_password');

  const bad = await json(
    await api('/api/auth/users', {
      method: 'POST',
      body: JSON.stringify({ username: 'con espacios', password: 'clave-larguita-1' }),
    }),
  );
  assert.equal(bad.error, 'invalid_username');

  const dup = await json(
    await api('/api/auth/users', {
      method: 'POST',
      body: JSON.stringify({ username: ADMIN.username, password: 'otra-clave-larga' }),
    }),
  );
  assert.equal(dup.error, 'username_taken');
});

test('the link to hand over is the public one, not the one you are browsing from', async () => {
  // El moderador puede estar en el portatil, en casa, y el enlace que le copian a
  // quien retransmite tiene que servir igual: lo decide el servidor, no desde
  // donde se ha abierto la ventana.
  const share = await json(await api('/api/share'));
  assert.ok(share.publicUrl, 'el servidor dice cual es su direccion');
  assert.equal(share.stageUrl, `${share.publicUrl}/stage?t=${share.token}`);
  assert.match(share.controlUrl, new RegExp(`^${share.publicUrl}/api/control/hidden\\?key=`));
  // Con D2O_PUBLIC_URL puesto es esa la que sale, y no por donde se entro; sin
  // el, el servidor recurre a la direccion de la peticion, que es lo unico que
  // puede saber. En cualquier caso los dos enlaces counted from the same one.
  assert.equal(share.controlUrl.startsWith(share.publicUrl), true);
});

test('the OBS link is for administrators only', async () => {
  // El enlace lleva dentro el token de la pantalla, que es de solo lectura pero
  // perpetuo: no tiene por que verlo cualquiera que pueda entrar.
  const mod = await login(MOD.username, MOD.password);
  const denied = await fetch(`${BASE}/api/share`, { headers: { cookie: mod.cookie } });
  assert.equal(denied.status, 403, 'un moderador no pide el enlace');
  assert.equal((await json(denied)).error, 'admin_required');

  // El token de la pantalla tampoco lo pide: solo sirve para mirar, y con
  // cuentas ya creadas ni siquiera administra.
  const token = await fetch(`${BASE}/api/share?t=${TOKEN}`);
  assert.equal(token.status, 403, 'el token de la pantalla no llega al enlace');
  assert.equal((await json(token)).token, undefined, 'y no se le escapa el token');

  const allowed = await fetch(`${BASE}/api/share`, { headers: { cookie: sessionCookie } });
  assert.equal(allowed.status, 200, 'un administrador si lo pide');
  const body = await json(allowed);
  assert.equal(body.token, TOKEN, 'y recibe el token real');
  assert.equal(body.stagePath, '/stage');
});

test('the cli counts accounts and protects the last administrator', () => {
  // El instalador usa 'count' para no volver a crear un administrador que el
  // dueno haya borrado a proposito: antes llamaba a 'ensure' en cada
  // despliegue y la cuenta volvia sola.
  const cli = path.join(root, 'server', 'cli-users.js');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'd2o-install-'));
  const run = (args) => spawnSync(process.execPath, [cli, ...args], {
    env: { ...process.env, D2O_DATA_DIR: dir },
    encoding: 'utf8',
  });

  assert.equal(run(['count']).stdout.trim(), '0', 'una instalacion nueva no tiene cuentas');
  assert.equal(run(['add', 'ana', '--admin', '--password', 'clave-ana-123456']).status, 0);
  assert.equal(run(['add', 'bea', '--role', 'mod', '--password', 'clave-bea-123456']).status, 0);
  assert.equal(run(['count']).stdout.trim(), '2', 'el instalador ve que ya hay cuentas y no crea nada');

  // Un ensure sobre una cuenta que ya existe no la toca: es lo que hacia que una
  // cuenta borrada volviese en el despliegue siguiente.
  const ensured = run(['ensure', 'ana', '--admin']);
  assert.equal(ensured.status, 0);
  assert.match(ensured.stdout, /ya existe/, 'avisa de que no ha hecho nada');
  assert.equal(run(['count']).stdout.trim(), '2');

  // La proteccion del ultimo administrador sigue en pie.
  const refused = run(['remove', 'ana']);
  assert.notEqual(refused.status, 0, 'no se puede quedar sin administrador');
  assert.match(refused.stdout + refused.stderr, /único administrador|ultimo administrador/i);
  assert.equal(run(['count']).stdout.trim(), '2');
  assert.equal(run(['remove', 'bea']).status, 0, 'una moderadora sí se puede quitar');
  assert.equal(run(['count']).stdout.trim(), '1');
});

test('a moderator cannot manage accounts but an admin can', async () => {
  const mod = await login(MOD.username, MOD.password);
  assert.equal(mod.res.status, 200);
  assert.equal(mod.body.user.role, 'mod');

  const denied = await mod.res.status === 200 && (await api('/api/auth/users', { headers: { cookie: mod.cookie } }));
  assert.equal(denied.status, 403, 'un moderador no lista cuentas');
  assert.equal((await json(denied)).error, 'admin_required');

  const asMod = await json(
    await fetch(`${BASE}/api/auth/users`, {
      method: 'POST',
      headers: { cookie: mod.cookie, 'content-type': 'application/json' },
      body: JSON.stringify({ username: 'carla', password: 'clave-carla-123' }),
    }),
  );
  assert.equal(asMod.error, 'admin_required');

  const list = await json(await api('/api/auth/users'));
  assert.equal(list.bootstrap, false);
  assert.ok(list.users.some((u) => u.username === ADMIN.username));
  assert.ok(list.users.every((u) => !('passwordHash' in u)), 'nunca se envían hashes');
});

test('a moderator can put something on air but the stage token cannot', async () => {
  const mod = await login(MOD.username, MOD.password);
  const { uploads } = await json(
    await (async () => {
      const form = new FormData();
      form.append('files', new Blob([fs.readFileSync(path.join(assets, 'nota.txt'))]), 'nota.txt');
      return fetch(`${BASE}/api/upload`, {
        method: 'POST',
        headers: { cookie: mod.cookie },
        body: form,
      });
    })(),
  );
  assert.equal(uploads.length, 1);

  const placed = await json(
    await fetch(`${BASE}/api/scenes/program/place`, {
      method: 'POST',
      headers: { cookie: mod.cookie, 'content-type': 'application/json' },
      body: JSON.stringify({ ids: [uploads[0].id] }),
    }),
  );
  assert.equal(placed.objects.length, 1, 'un moderador puede emitir');

  const denied = await tokenOnly('/api/scenes/program/place', {
    method: 'POST',
    body: JSON.stringify({ ids: [uploads[0].id] }),
  });
  assert.equal(denied.status, 401, 'el token de la pantalla no puede emitir');
});

test('an admin can change a password, disable, promote and delete accounts', async () => {
  const created = await json(
    await api('/api/auth/users', {
      method: 'POST',
      body: JSON.stringify({ username: 'dani', password: 'clave-dani-1234', role: 'mod' }),
    }),
  );
  assert.equal(created.user.username, 'dani');
  assert.equal(created.user.mustChangePassword, true);

  const dani = await login('dani', 'clave-dani-1234');
  assert.equal(dani.res.status, 200);
  assert.equal(dani.body.user.mustChangePassword, true, ' Obliga a cambiar la clave al entrar');

  const disabled = await json(
    await api(`/api/auth/users/${created.user.id}`, {
      method: 'PATCH',
      body: JSON.stringify({ disabled: true }),
    }),
  );
  assert.equal(disabled.user.disabled, true);

  const blocked = await login('dani', 'clave-dani-1234');
  assert.equal(blocked.res.status, 401, 'una cuenta desactivada no se distingue de una clave mala');
  assert.equal(blocked.body.error, 'bad_credentials');

  const alive = await json(
    await api(`/api/auth/users/${created.user.id}`, {
      method: 'PATCH',
      body: JSON.stringify({ disabled: false, role: 'admin', mustChangePassword: false }),
    }),
  );
  assert.equal(alive.user.role, 'admin');
  assert.equal(alive.user.mustChangePassword, false);

  const back = await login('dani', 'clave-dani-1234');
  assert.equal(back.res.status, 200);
  const kicked = await json(await fetch(`${BASE}/api/auth/me`, { headers: { cookie: back.cookie } }));
  assert.equal(kicked.authenticated, true, 'volver a habilitar conserva la sesión');

  const rotated = await json(
    await api(`/api/auth/users/${created.user.id}`, {
      method: 'PATCH',
      body: JSON.stringify({ password: 'clave-dani-nueva-9' }),
    }),
  );
  assert.equal(rotated.user.username, 'dani');
  const stale = await json(await fetch(`${BASE}/api/auth/me`, { headers: { cookie: back.cookie } }));
  assert.equal(stale.authenticated, false, 'cambiar la clave cierra las sesiones abiertas');

  assert.equal(
    (await api(`/api/auth/users/${created.user.id}`, { method: 'DELETE' })).status,
    200,
  );
  const gone = await json(await fetch(`${BASE}/api/auth/me`, { headers: { cookie: back.cookie } }));
  assert.equal(gone.authenticated, false, 'la cuenta borrada deja de tener sesión');
});

test('the last administrator is protected', async () => {
  const list = await json(await api('/api/auth/users'));
  const me = list.users.find((u) => u.username === ADMIN.username);
  assert.equal(me.role, 'admin', 'esta prueba se hace con la sesión de ana');

  const other = await json(
    await api('/api/auth/users', {
      method: 'POST',
      body: JSON.stringify({ username: 'eva', password: 'clave-eva-12345', role: 'admin' }),
    }),
  );
  assert.equal(other.user.role, 'admin');

  const demote = await json(
    await api(`/api/auth/users/${other.user.id}`, {
      method: 'PATCH',
      body: JSON.stringify({ role: 'mod' }),
    }),
  );
  assert.equal(demote.user.role, 'mod', 'con dos administradores se puede rebajar a uno');

  const selfOff = await json(
    await api(`/api/auth/users/${me.id}`, { method: 'PATCH', body: JSON.stringify({ disabled: true }) }),
  );
  assert.equal(selfOff.error, 'self_disable', 'uno no se desactiva a sí mismo');

  const selfDelete = await json(await api(`/api/auth/users/${me.id}`, { method: 'DELETE' }));
  assert.equal(selfDelete.error, 'self_delete', 'uno no se borra a sí mismo');

  // the cli has no actor, so it hits the last-admin guard directly
  const cli = (...args) =>
    spawnSync(process.execPath, [path.join(root, 'server', 'cli-users.js'), ...args], {
      env: { ...process.env, D2O_DATA_DIR: dataDir },
      encoding: 'utf8',
    });
  const orphan = cli('remove', ADMIN.username);
  assert.equal(orphan.status, 1, 'el cli tampoco deja la instalación sin admin');
  assert.match(orphan.stderr, /administrador/i);
  assert.equal(cli('role', ADMIN.username, 'mod').status, 1);

  // with a second admin around the guards step aside
  const back = await json(
    await api(`/api/auth/users/${other.user.id}`, {
      method: 'PATCH',
      body: JSON.stringify({ role: 'admin' }),
    }),
  );
  assert.equal(back.user.role, 'admin');
  assert.equal((await api(`/api/auth/users/${other.user.id}`, { method: 'DELETE' })).status, 200);
});

test('changing your own password needs the current one and ends the session', async () => {
  const mod = await login(MOD.username, MOD.password);
  const wrongRes = await fetch(`${BASE}/api/auth/password`, {
    method: 'POST',
    headers: { cookie: mod.cookie, 'content-type': 'application/json' },
    body: JSON.stringify({ current: 'incorrecta', next: 'clave-mod-nueva-1' }),
  });
  const wrong = await json(wrongRes);
  assert.equal(wrong.error, 'wrong_password');
  // A bad current password is a bad request, never an expired session: a 401
  // here makes the browser throw the person back to the login page.
  assert.equal(wrongRes.status, 400);
  assert.equal((await api('/api/auth/me', { cookie: mod.cookie })).status, 200);

  const short = await json(
    await fetch(`${BASE}/api/auth/password`, {
      method: 'POST',
      headers: { cookie: mod.cookie, 'content-type': 'application/json' },
      body: JSON.stringify({ current: MOD.password, next: 'corta' }),
    }),
  );
  assert.equal(short.error, 'weak_password');

  const done = await json(
    await fetch(`${BASE}/api/auth/password`, {
      method: 'POST',
      headers: { cookie: mod.cookie, 'content-type': 'application/json' },
      body: JSON.stringify({ current: MOD.password, next: 'clave-mod-nueva-1' }),
    }),
  );
  assert.equal(done.ok, true);

  const ended = await json(await fetch(`${BASE}/api/auth/me`, { headers: { cookie: mod.cookie } }));
  assert.equal(ended.authenticated, false, 'hay que volver a entrar');

  const withNew = await login(MOD.username, 'clave-mod-nueva-1');
  assert.equal(withNew.res.status, 200);
  sessionCookie = withNew.cookie;
});

test('logout ends the session and the cookie is cleared', async () => {
  const session = await login(MOD.username, 'clave-mod-nueva-1');
  const out = await fetch(`${BASE}/api/auth/logout`, { method: 'POST', headers: { cookie: session.cookie } });
  assert.equal(out.status, 200);
  assert.match(out.headers.get('set-cookie') ?? '', /d2o_user=;/);

  const after = await json(await fetch(`${BASE}/api/auth/me`, { headers: { cookie: session.cookie } }));
  assert.equal(after.authenticated, false);
});

test('repeated failures are throttled', async () => {
  for (let i = 0; i < 6; i += 1) {
    const res = await login('dani', `intento-${i}-mal`);
    if (res.res.status === 429) {
      assert.equal(res.body.error, 'too_many_attempts');
      const blocked = await login('dani', 'clave-dani-nueva-9');
      assert.equal(blocked.res.status, 429, 'también bloquea la contraseña correcta');
      return;
    }
    assert.equal(res.res.status, 401, `intento ${i}: ${JSON.stringify(res.body)}`);
  }
  assert.fail('el límite de intentos no se aplicó');
});

test('with no accounts the token runs the show, and creating one ends that', async () => {
  const emptyDir = fs.mkdtempSync(path.join(os.tmpdir(), 'd2o-bootstrap-'));
  const port = PORT + 2;
  const proc = spawn(process.execPath, [path.join(root, 'server', 'index.js')], {
    env: {
      ...process.env,
      D2O_PORT: String(port),
      D2O_HOST: '127.0.0.1',
      D2O_DATA_DIR: emptyDir,
      D2O_TOKEN: TOKEN,
      D2O_LOG_REQUESTS: 'false',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  proc.stdout.resume();
  proc.stderr.resume();
  const base = `http://127.0.0.1:${port}`;

  try {
    const deadline = Date.now() + 15000;
    for (;;) {
      try {
        if ((await fetch(`${base}/healthz`)).ok) break;
      } catch {
        /* not up yet */
      }
      if (Date.now() > deadline) throw new Error('server did not start');
      await new Promise((r) => setTimeout(r, 100));
    }

    const auth = { authorization: `Bearer ${TOKEN}` };
    const me = await json(await fetch(`${base}/api/auth/me`));
    assert.equal(me.tokenFallback, true, 'sin cuentas se avisa de que manda el token');

    const page = await fetch(`${base}/`, { headers: { ...auth, accept: 'text/html' } });
    assert.equal(page.status, 200, 'el token entra en la gestión mientras no haya cuentas');
    const markup = await page.text();
    assert.match(markup, /id="frameProgram"/, 'la página trae la pantalla larga');
    assert.match(markup, /id="airList"/, 'y la lista de lo que hay en ella');
    assert.equal(/id="frameDesk"/.test(markup), false, 'sin segundo frame');

    const upgraded = await fetch(`${base}/?t=${TOKEN}`, {
      headers: { accept: 'text/html' },
      redirect: 'manual',
    });
    const stage = (upgraded.headers.get('set-cookie') ?? '').split(';')[0];
    assert.ok(stage.startsWith('d2o_session='));

    const created = await json(
      await fetch(`${base}/api/auth/users`, {
        method: 'POST',
        headers: { ...auth, 'content-type': 'application/json' },
        body: JSON.stringify({ username: 'owner', password: 'clave-owner-123', role: 'admin' }),
      }),
    );
    assert.equal(created.user.role, 'admin');

    const after = await fetch(`${base}/`, { headers: { ...auth, accept: 'text/html' }, redirect: 'manual' });
    assert.equal(after.status, 302);
    assert.equal(
      after.headers.get('location'),
      '/login?next=%2F',
      'en cuanto hay una cuenta el token ya no gestiona',
    );

    const write = await fetch(`${base}/api/scenes/program/place`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ ids: [] }),
    });
    assert.equal(write.status, 401);

    // a file from before the latch existed must not reopen it
    fs.writeFileSync(
      path.join(emptyDir, 'auth.json'),
      JSON.stringify({
        users: [{ id: 'x', username: 'legacy', role: 'admin', passwordHash: 'scrypt$x' }],
        sessions: [],
      }),
    );
    await waitFor(async () => {
      const check = await json(await fetch(`${base}/api/auth/me`, { headers: { ...auth } }));
      return check.tokenFallback === false;
    }, 5000, 'el latch se reabre con un auth.json antiguo');
  } finally {
    proc.kill('SIGTERM');
    await once(proc, 'exit').catch(() => {});
    fs.rmSync(emptyDir, { recursive: true, force: true });
  }
});

test('the cli creates accounts and the live server picks the change up', async () => {
  const cli = (...args) =>
    spawnSync(process.execPath, [path.join(root, 'server', 'cli-users.js'), ...args], {
      env: { ...process.env, D2O_DATA_DIR: dataDir },
      encoding: 'utf8',
    });

  const added = cli('add', 'fede', '--role', 'mod', '--password', 'clave-fede-123');
  assert.equal(added.status, 0, added.stderr);
  assert.match(added.stdout, /fede/);

  const listed = cli('list');
  assert.match(listed.stdout, /fede/);
  assert.match(listed.stdout, /ana/);

  const dup = cli('add', 'fede', '--password', 'clave-fede-123');
  assert.equal(dup.status, 1, 'no se duplican cuentas');
  assert.match(dup.stderr, /ya existe/);

  // the running server has to see it without a restart
  const fresh = await login('fede', 'clave-fede-123');
  assert.equal(fresh.res.status, 200, 'el servidor no vio la cuenta nueva');

  /** Waits for the running server to pick a cli change up. */
  const waitForLogin = async (username, password) => {
    const deadline = Date.now() + 5000;
    for (;;) {
      const res = await login(username, password);
      if (res.res.status === 200) return res;
      if (Date.now() > deadline) {
        assert.fail(`el servidor no vio el cambio del cli: ${JSON.stringify(res.body)}`);
      }
      await new Promise((r) => setTimeout(r, 100));
    }
  };

  const changed = cli('pass', ADMIN.username, '--password', 'clave-ana-rotada-1');
  assert.equal(changed.status, 0, changed.stderr);
  const rotated = await waitForLogin(ADMIN.username, 'clave-ana-rotada-1');
  assert.equal(rotated.body.user.username, ADMIN.username);

  // put the original password back for the rest of the suite
  const restore = cli('pass', ADMIN.username, '--password', ADMIN.password);
  assert.equal(restore.status, 0, restore.stderr);
  const back = await waitForLogin(ADMIN.username, ADMIN.password);
  assert.equal(back.body.user.username, ADMIN.username, 'la vuelta atrás también se ve sin reiniciar');
  // rotating the password closed every session, including the suite's
  sessionCookie = back.cookie;

  // a removal has to disappear from the running server too, not come back
  assert.equal(cli('remove', 'fede').status, 0);
  const goneBy = Date.now() + 5000;
  for (;;) {
    const gone = await login('fede', 'clave-fede-123');
    if (gone.res.status === 401) break;
    if (Date.now() > goneBy) {
      assert.fail(`el servidor sigue viendo una cuenta borrada: ${JSON.stringify(gone.body)}`);
    }
    await new Promise((r) => setTimeout(r, 100));
  }
  const after = await json(await api('/api/auth/users'));
  assert.ok(Array.isArray(after.users), `respuesta inesperada: ${JSON.stringify(after)}`);
  assert.ok(
    !after.users.some((u) => u.username === 'fede'),
    'la cuenta borrada por el cli no puede reaparecer',
  );
});
