/*
 * Tests for the long screen model: one panel that is the emitted canvas with the
 * bank underneath it, uploading onto it, dragging an object across the cut, the
 * transform endpoints and what the OBS payload is allowed to see.
 */
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import test, { after, before } from 'node:test';
import { WebSocket } from 'ws';

import {
  REACH,
  boundsOf,
  centerObject,
  clampInside,
  collectSnap,
  isInteractive,
  moveObject,
  resizeObject,
} from '../public/geometry.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const assets = path.join(here, 'assets');
const PORT = 9200 + (process.pid % 300);
const BASE = `http://127.0.0.1:${PORT}`;
const TOKEN = 'scene-token-1234567890ab';
const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'd2o-scene-'));
const mediaDir = path.join(dataDir, 'media');
const CANVAS = { width: 1920, height: 1080 };
// The cut sits in the middle of the long screen: above it is emitted, below it is
// the bank that waits.
const CUT = CANVAS.height;
const SCREEN = { width: CANVAS.width, height: CANVAS.height * 2 };

const ADMIN = { username: 'ana', password: 'clave-admin-123', role: 'admin' };

let child = null;
let cookie = '';

function png() {
  // 1x1 transparent png
  return Buffer.from(
    'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==',
    'base64',
  );
}

async function api(pathname, options = {}) {
  const res = await fetch(`${BASE}${pathname}`, {
    redirect: 'manual',
    ...options,
    headers: {
      ...(options.body && !(options.body instanceof FormData)
        ? { 'content-type': 'application/json' }
        : {}),
      ...(options.cookie === false ? {} : { cookie }),
      ...(options.headers ?? {}),
    },
  });
  const setCookie = res.headers.getSetCookie?.() ?? [];
  for (const raw of setCookie) {
    const [pair] = raw.split(';');
    if (pair.startsWith('d2o_user=')) cookie = pair;
  }
  const text = await res.text();
  const data = text ? JSON.parse(text) : {};
  return { status: res.status, data, headers: res.headers };
}

async function upload(name = 'nota.png', bytes = png()) {
  const body = new FormData();
  body.append('files', new Blob([bytes], { type: 'image/png' }), name);
  const res = await api('/api/upload', { method: 'POST', body });
  assert.equal(res.status, 200, JSON.stringify(res.data));
  return res.data.uploads[0];
}

/**
 * Waits for one frame of a given type, ignoring the keepalive pings. The stage
 * mixes state, transforms and pings on the same socket, so waiting on "the next
 * message" would race with the heartbeat.
 */
function waitFor(socket, type, ms = 8000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      socket.off('message', onMessage);
      reject(new Error(`no "${type}" frame within ${ms}ms`));
    }, ms);
    function onMessage(raw) {
      let frame;
      try {
        frame = JSON.parse(String(raw));
      } catch {
        return;
      }
      if (frame.type !== type) return;
      clearTimeout(timer);
      socket.off('message', onMessage);
      resolve(frame);
    }
    socket.on('message', onMessage);
  });
}

before(async () => {
  child = spawn(process.execPath, [path.join(root, 'server', 'cli-users.js'), 'add', ADMIN.username,
    '--role', ADMIN.role, '--password', ADMIN.password], {
    env: { ...process.env, D2O_DATA_DIR: dataDir },
    stdio: 'ignore',
  });
  await once(child, 'exit');

  child = spawn(process.execPath, [path.join(root, 'server', 'index.js')], {
    env: {
      ...process.env,
      D2O_PORT: String(PORT),
      D2O_HOST: '127.0.0.1',
      D2O_DATA_DIR: dataDir,
      D2O_TOKEN: TOKEN,
      D2O_LOG_REQUESTS: 'false',
      D2O_CANVAS: '1920x1080',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  const logs = [];
  child.stdout.on('data', (chunk) => logs.push(String(chunk)));
  child.stderr.on('data', (chunk) => logs.push(String(chunk)));

  const deadline = Date.now() + 15000;
  for (;;) {
    try {
      const res = await fetch(`${BASE}/healthz`);
      if (res.ok) break;
    } catch {
      /* not up yet */
    }
    if (Date.now() > deadline) throw new Error(`server never came up:\n${logs.join('')}`);
    await new Promise((r) => setTimeout(r, 150));
  }

  const login = await api('/api/auth/login', {
    method: 'POST',
    cookie: false,
    body: JSON.stringify({ username: ADMIN.username, password: ADMIN.password }),
  });
  assert.equal(login.status, 200, JSON.stringify(login.data));
});

after(() => {
  child?.kill('SIGKILL');
  fs.rmSync(dataDir, { recursive: true, force: true });
});

/* ------------------------------- geometry ------------------------------- */

test('bounds of a rotated object grow with the angle', () => {
  const flat = boundsOf({ x: 100, y: 100, w: 200, h: 100, rot: 0 });
  assert.deepEqual([flat.w, flat.h], [200, 100]);
  const turned = boundsOf({ x: 0, y: 0, w: 200, h: 100, rot: 90 });
  assert.ok(Math.abs(turned.w - 100) < 0.01);
  assert.ok(Math.abs(turned.h - 200) < 0.01);
});

test('a dragged object snaps to the centre of the canvas', () => {
  const canvas = CANVAS;
  const object = { x: 100, y: 100, w: 200, h: 200, rot: 0 };
  const guides = {};
  const near = { x: canvas.width / 2 - 200 / 2 - 4, y: canvas.height / 2 - 200 / 2 + 3 };
  const moved = moveObject(object, {
    dx: near.x - object.x,
    dy: near.y - object.y,
    others: [],
    canvas,
    guides,
  });
  assert.equal(moved.x + 100, canvas.width / 2);
  assert.equal(guides.x, canvas.width / 2);
});

test('a move can skip the snapping', () => {
  const canvas = CANVAS;
  const object = { x: 856, y: 10, w: 100, h: 100 };
  const snapped = moveObject(object, { dx: 0, dy: 0, canvas });
  assert.equal(snapped.x, 860, 'by default the edge lines up with the centre');

  const free = moveObject(object, { dx: 0, dy: 0, canvas, snap: false });
  assert.equal(free.x, 856, 'with the modifier the object stays where it is put');
  assert.equal(free.y, 10);
});

test('snapping prefers the closest line', () => {
  const canvas = CANVAS;
  const found = collectSnap({ x: 497, y: 10, w: 100, h: 100 }, [], canvas, 10);
  // left edge at 497 is 3px from the centre at 960? no: check the real candidate
  const nearCentre = collectSnap({ x: 856, y: 10, w: 100, h: 100 }, [], canvas, 10);
  assert.equal(nearCentre.dx, 4); // 960 - (856 + 50)
  assert.equal(found.dx, 0);
});

test('resizing from a corner honours the aspect ratio when asked', () => {
  const start = { x: 0, y: 0, w: 400, h: 200 };
  const resized = resizeObject({ ...start }, 'se', { x: 800, y: 400 }, start, { aspect: true });
  assert.equal(resized.w, 800);
  assert.equal(resized.h, 400);
});

test('resizing keeps the shape on every handle unless told otherwise', () => {
  // Almost everything on air is a photo or a video, so a resize holds the shape
  // by default: a 16:9 clip stays 16:9 instead of quietly going square.
  const start = { x: 100, y: 100, w: 400, h: 225 };
  for (const handle of ['nw', 'n', 'ne', 'e', 'se', 's', 'sw', 'w']) {
    const resized = resizeObject({ ...start }, handle, { x: 500, y: 300 }, start, {});
    const ratio = resized.w / resized.h;
    assert.ok(
      Math.abs(ratio - 16 / 9) < 0.01,
      `${handle} dejó la proporción en ${ratio.toFixed(3)}`,
    );
  }
});

test('the modifier lets the box follow the pointer instead', () => {
  const start = { x: 0, y: 0, w: 400, h: 225 };
  const free = resizeObject({ ...start }, 'se', { x: 800, y: 800 }, start, { aspect: false });
  assert.equal(free.w, 800);
  assert.equal(free.h, 800);
});

test('a corner follows whichever axis the pointer pushed further', () => {
  const start = { x: 0, y: 0, w: 400, h: 225 };
  // The pointer goes much further down than across, so the height leads and the
  // width comes from the ratio, and the corner stays under the pointer.
  const tall = resizeObject({ ...start }, 'se', { x: 500, y: 800 }, start, {});
  assert.equal(tall.h, 800);
  assert.ok(Math.abs(tall.w - 1422.22) < 0.01, `ancho ${tall.w}`);
  assert.ok(Math.abs(tall.w + tall.x - tall.w) < 0.01, 'la esquina oeste se queda en el sitio');
  assert.equal(tall.y + tall.h, 800, 'la esquina sur sigue al puntero');
});

test('resizing from an edge anchors the opposite side', () => {
  const start = { x: 100, y: 100, w: 400, h: 225 };
  const resized = resizeObject({ ...start }, 'e', { x: 700, y: 100 }, start, {});
  assert.equal(resized.x, 100, 'the west edge stays put');
  assert.equal(resized.w, 600, 'the dragged edge follows the pointer');
  assert.equal(resized.h, 337.5, 'the height comes from the ratio');
  assert.equal(resized.y, 100);
});

test('resizing from the centre mirrors the box', () => {
  const start = { x: 100, y: 100, w: 200, h: 200 };
  const resized = resizeObject({ ...start }, 'e', { x: 400, y: 200 }, start, { fromCenter: true });
  assert.equal(resized.w, 400);
  assert.equal(resized.x, 0);
});

test('a centred resize still holds the shape', () => {
  const start = { x: 100, y: 100, w: 400, h: 200 };
  const resized = resizeObject({ ...start }, 'se', { x: 500, y: 400 }, start, { fromCenter: true });
  assert.equal(Math.abs(resized.w / resized.h - 2) < 0.01, true, '2:1 se mantiene');
  assert.equal(resized.h, 400);
  assert.equal(resized.x + resized.w / 2, 300, 'el centro no se mueve');
  assert.equal(resized.y + resized.h / 2, 200);
});

/* --------------------------------- api ---------------------------------- */

test('a signed out visitor cannot see the workspace', async () => {
  const res = await api('/api/workspace', { cookie: false });
  assert.equal(res.status, 401);
});

test('the OBS payload carries the screen and the cut, never the workspace', async () => {
  const res = await api('/api/state');
  assert.equal(res.status, 200);
  assert.ok(res.data.program, 'the screen is exposed');
  assert.equal(res.data.cut, CUT, 'with the line the source crops at');
  assert.equal(res.data.scenes, undefined, 'the management view is not in the OBS payload');
  assert.equal(res.data.layers, undefined, 'the old flat list is gone');
  assert.equal(res.data.program.height, SCREEN.height, 'the whole screen travels, not just the air');
});

test('dropping a file puts it on the screen at the drop point', async () => {
  const up = await upload();
  const res = await api('/api/scenes/program/place', {
    method: 'POST',
    body: JSON.stringify({ ids: [up.id], x: 300, y: 240 }),
  });
  assert.equal(res.status, 200, JSON.stringify(res.data));
  const object = res.data.objects[0];
  assert.equal(object.scene, 'program', 'there is one screen now');
  assert.equal(object.x, 300);
  assert.equal(object.y, 240);
  assert.ok(object.y < CUT, '240 is above the cut, so it goes out');
  assert.ok(object.w > 0 && object.h > 0);
});

test('an unknown scene is refused', async () => {
  const up = await upload('otra.png');
  const res = await api('/api/scenes/galeria/place', {
    method: 'POST',
    body: JSON.stringify({ ids: [up.id] }),
  });
  assert.equal(res.status, 400);
  assert.equal(res.data.error, 'unknown_scene');
});

test('an object dragged across the cut is the same object, just moved', async () => {
  const up = await upload('banco.png');
  const placed = await api('/api/scenes/program/place', {
    method: 'POST',
    body: JSON.stringify({ ids: [up.id], x: 300, y: CUT + 200 }),
  });
  const bankObject = placed.data.objects[0];
  assert.ok(bankObject.y >= CUT, 'it starts in the bank');

  const res = await api(`/api/objects/${bankObject.id}`, {
    method: 'PATCH',
    body: JSON.stringify({ x: 960, y: 540 }),
  });
  assert.equal(res.status, 200, JSON.stringify(res.data));
  assert.equal(res.data.object.id, bankObject.id, 'the same object, not a copy');
  assert.equal(res.data.object.y, 540);

  const after = await api('/api/workspace');
  const found = after.data.scenes.program.objects.filter((o) => o.id === bankObject.id);
  assert.equal(found.length, 1, 'it exists once, on the one screen');
  assert.ok(found[0].y < CUT, 'and now it is above the cut, so it is live');
});

test('the transform endpoint takes a partial body', async () => {
  const workspace = await api('/api/workspace');
  const object = workspace.data.scenes.program.objects[0];
  const res = await api(`/api/objects/${object.id}`, {
    method: 'PATCH',
    body: JSON.stringify({ rot: 15 }),
  });
  assert.equal(res.status, 200);
  assert.equal(res.data.object.rot, 15);
  assert.equal(res.data.object.x, object.x, 'untouched fields keep their value');
});

test('a transform cannot inject unknown keys into the saved state', async () => {
  const workspace = await api('/api/workspace');
  const object = workspace.data.scenes.program.objects[0];
  const res = await api(`/api/objects/${object.id}`, {
    method: 'PATCH',
    body: JSON.stringify({ scene: 'program', archivo: '/etc/passwd', url: 'http://evil' }),
  });
  assert.equal(res.status, 200);
  assert.equal(res.data.object.url.includes('evil'), false);
  assert.equal(res.data.object.archivo, undefined);
});

test('order changes renumber z from the bottom up', async () => {
  const up = await upload('orden.png');
  const placed = await api('/api/scenes/program/place', {
    method: 'POST',
    body: JSON.stringify({ ids: [up.id] }),
  });
  const object = placed.data.objects[0];
  const res = await api(`/api/objects/${object.id}/order`, {
    method: 'POST',
    body: JSON.stringify({ direction: 'front' }),
  });
  assert.equal(res.status, 200);
  const zs = res.data.objects.map((o) => o.z);
  assert.deepEqual(zs, [...zs].sort((a, b) => a - b));
  assert.equal(zs.at(-1), Math.max(...zs));
});

test('a bad order direction is refused', async () => {
  const workspace = await api('/api/workspace');
  const object = workspace.data.scenes.program.objects[0];
  const res = await api(`/api/objects/${object.id}/order`, {
    method: 'POST',
    body: JSON.stringify({ direction: 'sideways' }),
  });
  assert.equal(res.status, 400);
});

test('duplicating leaves the original alone', async () => {
  const workspace = await api('/api/workspace');
  const object = workspace.data.scenes.program.objects[0];
  const res = await api(`/api/objects/${object.id}/duplicate`, { method: 'POST' });
  assert.equal(res.status, 201);
  assert.notEqual(res.data.object.id, object.id);
  assert.equal(res.data.object.x, object.x + 24);

  const after = await api('/api/workspace');
  assert.ok(after.data.scenes.program.objects.some((o) => o.id === object.id));
});

test('deleting an object takes it off its screen only', async () => {
  const workspace = await api('/api/workspace');
  const target = workspace.data.scenes.program.objects[0];
  const res = await api(`/api/objects/${target.id}`, { method: 'DELETE' });
  assert.equal(res.status, 200);
  const after = await api('/api/workspace');
  assert.ok(!after.data.scenes.program.objects.some((o) => o.id === target.id));
});

test('clearing the bank leaves what is on air alone', async () => {
  // One object above the cut and one below it, sharing nothing, so the clearing
  // can only be judged on the live one surviving.
  const live = await upload('directo.png');
  const banked = await upload('banco.png');
  const placedLive = await api('/api/scenes/program/place', {
    method: 'POST',
    body: JSON.stringify({ ids: [live.id], x: 200, y: 200 }),
  });
  await api('/api/scenes/program/place', {
    method: 'POST',
    body: JSON.stringify({ ids: [banked.id], x: 200, y: CUT + 200 }),
  });
  const liveId = placedLive.data.objects[0].id;
  assert.ok(liveId);

  const res = await api('/api/bank?files=0', { method: 'DELETE' });
  assert.equal(res.status, 200);
  assert.ok(res.data.removed > 0, 'something left the bank');
  const after = await api('/api/workspace');
  const kept = after.data.scenes.program.objects;
  assert.ok(kept.some((o) => o.id === liveId), 'what was on air is still there');
  assert.equal(kept.filter((o) => o.y >= CUT).length, 0, 'the bank is empty');
});

test('clearing the whole screen takes the live half too', async () => {
  const up = await upload('todo.png');
  await api('/api/scenes/program/place', {
    method: 'POST',
    body: JSON.stringify({ ids: [up.id], x: 200, y: 200 }),
  });
  await api('/api/scenes/program/place', {
    method: 'POST',
    body: JSON.stringify({ ids: [(await upload('mas.png')).id], x: 200, y: CUT + 200 }),
  });

  const res = await api('/api/scenes/program?files=0', { method: 'DELETE' });
  assert.equal(res.status, 200);
  const after = await api('/api/workspace');
  assert.equal(after.data.scenes.program.objects.length, 0, 'sacar todo de directo deja la pantalla vacia');
});

/* ------------------------------ persistence ----------------------------- */

test('the screen survives a restart with both halves intact', async () => {
  const up = await upload('persiste.png');
  const placed = await api('/api/scenes/program/place', {
    method: 'POST',
    body: JSON.stringify({ ids: [up.id], x: 111, y: 222 }),
  });
  const object = placed.data.objects[0];

  child.kill('SIGTERM');
  await once(child, 'exit').catch(() => {});
  child = spawn(process.execPath, [path.join(root, 'server', 'index.js')], {
    env: {
      ...process.env,
      D2O_PORT: String(PORT),
      D2O_HOST: '127.0.0.1',
      D2O_DATA_DIR: dataDir,
      D2O_TOKEN: TOKEN,
      D2O_LOG_REQUESTS: 'false',
      D2O_CANVAS: '1920x1080',
    },
    stdio: 'ignore',
  });
  const deadline = Date.now() + 15000;
  for (;;) {
    try {
      if ((await fetch(`${BASE}/healthz`)).ok) break;
    } catch {
      /* not up yet */
    }
    if (Date.now() > deadline) throw new Error('server did not come back');
    await new Promise((r) => setTimeout(r, 150));
  }

  const after = await api('/api/workspace');
  assert.equal(after.data.cut, CUT, 'the cut survives the restart too');
  const found = after.data.scenes.program.objects.find((o) => o.id === object.id);
  assert.ok(found, 'the object is still on the screen');
  assert.equal(found.x, 111);
  assert.equal(found.y, 222);
});

/* -------------------------------- realtime ------------------------------ */

test('a transform frame reaches the stage without being saved', async () => {
  const workspace = await api('/api/workspace');
  const object = workspace.data.scenes.program.objects[0];
  const scene = object.scene;

  const stage = new WebSocket(`${BASE.replace('http', 'ws')}/stage?id=probe-1&t=${TOKEN}`);
  // The listener goes on before the handshake finishes, otherwise the opening
  // state frame lands before anybody is watching for it.
  const openingState = waitFor(stage, 'state');
  await once(stage, 'open');
  // El socket de gestión necesita la sesión de un usuario, no la clave de OBS.
  const control = new WebSocket(`${BASE.replace('http', 'ws')}/events`, { headers: { cookie } });
  await once(control, 'open');
  const state = await openingState;
  assert.ok(state.program, 'the stage is handed the program scene on connect');
  assert.equal(state.scenes, undefined, 'and never the desk');

  control.send(JSON.stringify({ type: 'transform', id: object.id, x: 640, y: 360, w: 500, h: 500 }));
  const frame = await waitFor(stage, 'transform');
  assert.equal(frame.object.id, object.id);
  assert.equal(frame.object.x, 640);
  assert.equal(frame.object.y, 360);
  assert.equal(frame.object.scene, scene);

  // The live frame is a preview: the saved transform is untouched.
  const after = await api('/api/workspace');
  const stored = after.data.scenes[scene].objects.find((o) => o.id === object.id);
  assert.notEqual(stored.x, 640, 'a preview does not overwrite the saved value');

  stage.close();
  control.close();
});

test('the transform endpoint answers and reaches the stage', async () => {
  const up = await upload('preview.png');
  const placed = await api('/api/scenes/program/place', {
    method: 'POST',
    body: JSON.stringify({ ids: [up.id], x: 10, y: 20 }),
  });
  assert.equal(placed.status, 200, JSON.stringify(placed.data));
  const object = placed.data.objects[0];
  const stage = new WebSocket(`${BASE.replace('http', 'ws')}/stage?id=probe-http&t=${TOKEN}`);
  const openingState = waitFor(stage, 'state');
  await once(stage, 'open');
  await openingState;

  // The listener has to be waiting before the request goes out, or the frame
  // can land before anybody is watching for it.
  const frame = waitFor(stage, 'transform');
  const res = await api(`/api/objects/${object.id}/transform`, {
    method: 'PATCH',
    body: JSON.stringify({ x: 111, y: 222 }),
  });
  assert.equal(res.status, 200, JSON.stringify(res.data));
  assert.equal(res.data.object.x, 111);

  const sent = await frame;
  assert.equal(sent.object.id, object.id);
  assert.equal(sent.object.x, 111);
  assert.equal(sent.object.y, 222);

  // Still only a preview on disk.
  const after = await api('/api/workspace');
  const stored = after.data.scenes.program.objects.find((o) => o.id === object.id);
  assert.notEqual(stored.x, 111, 'the http preview does not save either');

  stage.close();
  await api(`/api/objects/${object.id}`, { method: 'DELETE' });
});

test('the transform endpoint needs a user', async () => {
  const up = await upload('preview-anon.png');
  const placed = await api('/api/scenes/program/place', {
    method: 'POST',
    body: JSON.stringify({ ids: [up.id], x: 30, y: 40 }),
  });
  const res = await api(`/api/objects/${placed.data.objects[0].id}/transform`, {
    method: 'PATCH',
    cookie: false,
    body: JSON.stringify({ x: 0 }),
  });
  assert.equal(res.status, 401);
});

test('a half finished drag is never committed by somebody else', async () => {
  const up = await upload('a-medias.png');
  const placed = await api('/api/scenes/program/place', {
    method: 'POST',
    body: JSON.stringify({ ids: [up.id], x: 100, y: 100 }),
  });
  const object = placed.data.objects[0];

  // Somebody is mid drag...
  await api(`/api/objects/${object.id}/transform`, {
    method: 'PATCH',
    body: JSON.stringify({ x: 1500 }),
  });

  // ...and meanwhile another mod uploads, which forces a save to disk.
  const other = await upload('de-otro.png');
  await api('/api/scenes/program/place', { method: 'POST', body: JSON.stringify({ ids: [other.id] }) });
  await new Promise((r) => setTimeout(r, 1200));

  // The dropped position is what got saved, not the in flight frame.
  child.kill('SIGTERM');
  await once(child, 'exit').catch(() => {});
  child = spawn(process.execPath, [path.join(root, 'server', 'index.js')], {
    env: {
      ...process.env,
      D2O_PORT: String(PORT),
      D2O_HOST: '127.0.0.1',
      D2O_DATA_DIR: dataDir,
      D2O_TOKEN: TOKEN,
      D2O_LOG_REQUESTS: 'false',
      D2O_CANVAS: '1920x1080',
    },
    stdio: 'ignore',
  });
  const deadline = Date.now() + 15000;
  for (;;) {
    try {
      if ((await fetch(`${BASE}/healthz`)).ok) break;
    } catch {
      /* not up yet */
    }
    if (Date.now() > deadline) throw new Error('server did not come back');
    await new Promise((r) => setTimeout(r, 150));
  }

  const after = await api('/api/workspace');
  const stored = after.data.scenes.program.objects.find((o) => o.id === object.id);
  assert.ok(stored, 'the object is still on the screen');
  assert.equal(stored.x, 100, 'the saved position is the one before the drag');
});

test('an anonymous socket cannot watch the stream', async () => {
  const socket = new WebSocket(`${BASE.replace('http', 'ws')}/stage?id=probe-2`);
  const [error] = await once(socket, 'error');
  assert.ok(error, 'the handshake is refused');
});

/* ------------------------------ geometry -------------------------------- */

test('only an embedded page is interactive', () => {
  // An embedded page is drawn as an iframe, so the editor can hand the pointer to
  // it and let a click land on the item under the cursor inside the page.
  assert.equal(isInteractive({ render: 'html' }), true);
  assert.equal(isInteractive({ render: 'image' }), false);
  assert.equal(isInteractive({ render: 'video' }), false);
  assert.equal(isInteractive({ render: 'text' }), false);
  assert.equal(isInteractive({}), false);
  assert.equal(isInteractive(undefined), false, 'un objeto que no existe no es interactivo');
  assert.equal(isInteractive(null), false);
});

test('an object is centred inside the half it already belongs to', () => {
  const canvas = SCREEN;
  const live = { w: 400, h: 300, y: 100 };
  const bank = { w: 400, h: 300, y: CUT + 100 };
  const centeredLive = centerObject(live, canvas, CUT);
  const centeredBank = centerObject(bank, canvas, CUT);
  assert.equal(centeredLive.y, (CUT - 300) / 2, 'centrado en la emisión, sin cruzar el corte');
  assert.ok(centeredLive.y + 300 <= CUT);
  assert.ok(centeredBank.y >= CUT, 'centrado en el banco, sin cruzar el corte');
  assert.equal(centeredLive.y, centeredBank.y - CUT, 'las dos mitades quedan a la misma altura');
  assert.equal(centeredLive.x, (CANVAS.width - 400) / 2);
});

test('an object with no place yet is centred in the bank', () => {
  const centered = centerObject({ w: 400, h: 300 }, SCREEN, CUT);
  assert.ok(centered.y >= CUT, 'nunca aparece en directo por sorpresa');
});

test('an object can never be pushed out of reach', () => {
  // What matters is that a strip of it stays on the panel: past that it cannot be
  // clicked, so it could not be picked up again to bring it back, and it would be
  // gone for good while still listed as content.
  const box = { w: 400, h: 300 };
  const canvas = SCREEN;
  const far = clampInside({ ...box, x: 9000, y: 9000 }, canvas);
  assert.equal(far.x + REACH, canvas.width, 'asomando por la derecha, no más');
  assert.equal(far.y + REACH, canvas.height, 'ni por abajo');
  const out = clampInside({ ...box, x: -9000, y: -9000 }, canvas);
  assert.equal(out.x + box.w, REACH, 'asomando por la izquierda, no más');
  assert.equal(out.y + box.h, REACH, 'ni por arriba');

  // Un objeto dentro de la pantalla no se toca: el clamp solo actsua en el borde.
  assert.deepEqual(clampInside({ ...box, x: 600, y: 1300 }, canvas), { x: 600, y: 1300 });

  const dragged = moveObject({ ...box, x: 1800, y: 2000 }, { dx: 400, dy: 400, snap: false, canvas });
  assert.equal(dragged.x + REACH, canvas.width, 'un arrastre tampoco se sale');
  assert.equal(dragged.y + REACH, canvas.height);
});

test('an object bigger than the screen is centred instead of squeezed', () => {
  const huge = { w: 3000, h: 2600 };
  assert.deepEqual(clampInside({ ...huge, x: -500, y: -500 }, SCREEN), { x: 0, y: 0 });
});
