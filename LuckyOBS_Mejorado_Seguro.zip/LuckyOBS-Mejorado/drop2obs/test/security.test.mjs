import assert from 'node:assert/strict';
import test from 'node:test';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { browserOriginAllowed } from '../server/browser-origin.js';

const request = (origin, host = 'luckyobs.w4rfin.com') => ({ headers: { origin, host } });
test('requests from the same public origin are accepted', () => {
  assert.equal(browserOriginAllowed(request('https://luckyobs.w4rfin.com'), 'https://luckyobs.w4rfin.com'), true);
});
test('requests from a different browser origin are rejected', () => {
  assert.equal(browserOriginAllowed(request('https://malicioso.example'), 'https://luckyobs.w4rfin.com'), false);
  assert.equal(browserOriginAllowed(request('null'), 'https://luckyobs.w4rfin.com'), false);
  assert.equal(browserOriginAllowed(request('https://luckyobs.w4rfin.com.evil.example'), 'https://luckyobs.w4rfin.com'), false);
});
test('scripts without Origin can use explicit credentials', () => {
  assert.equal(browserOriginAllowed({ headers: { host: 'localhost:8787' } }), true);
});
test('public domain can work behind a localhost reverse proxy', () => {
  assert.equal(browserOriginAllowed(request('https://luckyobs.w4rfin.com', '127.0.0.1:8787'), 'https://luckyobs.w4rfin.com'), true);
});

test('uploaded HTML iframes cannot inherit administrator origin', () => {
  const sceneFile = fileURLToPath(new URL('../public/scene.js', import.meta.url));
  const scene = readFileSync(sceneFile, 'utf8');
  assert.match(scene, /setAttribute\('sandbox', 'allow-scripts'\)/);
  assert.doesNotMatch(scene, /allow-scripts allow-same-origin/);
});
