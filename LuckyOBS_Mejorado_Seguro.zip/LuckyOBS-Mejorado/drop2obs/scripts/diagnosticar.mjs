#!/usr/bin/env node
/** Diagnóstico de acceso, ejecutable desde Windows, Linux o macOS. */
import { lookup } from 'node:dns/promises';

const raw = process.argv[2] || process.env.D2O_PUBLIC_URL || 'https://luckyobs.w4rfin.com';
let target;
try {
  target = new URL(raw);
  if (!['http:', 'https:'].includes(target.protocol)) throw new Error('protocolo');
  target.pathname = '/';
  target.search = '';
  target.hash = '';
} catch {
  console.error('Usa una URL HTTP(S): npm run diagnostico -- https://luckyobs.w4rfin.com');
  process.exitCode = 2;
  process.exit();
}

console.log(`\nLuckyOBS · Diagnóstico de acceso`);
console.log(`Destino: ${target.origin}`);
let problems = 0;
try {
  const ip = await lookup(target.hostname);
  console.log(`[OK] DNS: ${target.hostname} resuelve a ${ip.address}`);
} catch (err) {
  console.log(`[FALLO] DNS: no se puede resolver el dominio (${err.code || err.message})`);
  problems += 1;
}

async function check(path, description, expected) {
  const url = new URL(path, target);
  try {
    const res = await fetch(url, { redirect: 'manual', signal: AbortSignal.timeout(8000) });
    const good = expected.includes(res.status);
    console.log(`[${good ? 'OK' : 'FALLO'}] ${description}: HTTP ${res.status}`);
    if (!good) problems += 1;
    return res;
  } catch (err) {
    console.log(`[FALLO] ${description}: ${err.cause?.code || err.message}`);
    problems += 1;
    return null;
  }
}
const health = await check('/healthz', 'Servidor Node.js', [200]);
if (health?.ok) {
  const body = await health.json().catch(() => null);
  if (body?.ok === true) console.log(`       Aplicación iniciada; tiempo activo: ${body.uptime ?? '?'} s`);
}
await check('/login', 'Página pública de acceso', [200]);
await check('/login.js', 'JavaScript de acceso', [200]);
await check('/api/state', 'Área privada (debe estar protegida)', [401, 403]);
console.log('\n' + (problems ? `${problems} comprobación(es) necesitan revisión.` : 'Comprobaciones HTTP correctas.'));
console.log('Nota: este diagnóstico no verifica la conexión real de OBS, las cuentas ni la subida de archivos.');
console.log('Para comprobar OBS: inicia sesión como administrador y revisa el indicador de conexión.\n');
if (problems) process.exitCode = 1;
