#!/usr/bin/env bash
# LuckyOBS · desplegar el programa en la maquina de Oracle y comprobarlo.
#
#   ./desplegar-nube.sh <IP-O-USUARIO@HOST> [dominio]
#
# Que hace, en corto:
#   1. sube el fuente a la maquina (sin datos, sin node_modules)
#   2. ejecuta install.sh ahi, que reinstala y reinicia el servicio
#   3. comprueba que la web responde de verdad, no solo que no da error
#
# Es la operacion que se repite cada vez que cambio algo, asi que esta
# idempotente: sube solo lo que ha cambiado y comprueba al final.
#
# Opciones de SSH: usa las de tu ~/.ssh/config. Si la maquina se llama de otra
# forma, pasa el usuario delante:  ubuntu@1.2.3.4

set -euo pipefail
umask 077

TARGET="${1:-}"
DOMAIN="${2:-}"
# D2O_SSH_KEY apunta a la clave si no esta en el ~/.ssh/config ni en el
# ~/.ssh con un nombre que ssh sepa encontrar. En Oracle la clave se llama
# ssh-key-YYYY-MM-DD-NNN.pem y vive en el directorio del usuario.
KEY="${D2O_SSH_KEY:-}"
SSH_OPTS=(-o BatchMode=yes -o ConnectTimeout=10)
[ -n "$KEY" ] && SSH_OPTS+=(-i "$KEY")
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
STAGE="${STAGE_DIR:-$HOME/luckyobs-fuente}"
DATA_DIR="${D2O_DATA_DIR:-$HOME/.local/share/luckyobs-data}"

info() { printf '\033[36m▸\033[0m %s\n' "$*"; }
ok() { printf '\033[32m✔\033[0m %s\n' "$*"; }
die() { printf '\033[31m✘\033[0m %s\n' "$*" >&2; exit 1; }

[ -n "$TARGET" ] || die "Falta la maquina:  ./desplegar-nube.sh ubuntu@1.2.3.4"
[ -f "$HERE/install.sh" ] || die "Esto tiene que estar dentro de la carpeta del proyecto (no se encuentra install.sh en $HERE)"
command -v rsync >/dev/null || die "Falta rsync"

# ------------------------------------------------------------- 1. subir --
info "Comprobando el acceso a $TARGET"
if ! ssh "${SSH_OPTS[@]}" "$TARGET" true 2>/dev/null; then
  die "No puedo entrar en $TARGET sin contrasena. Con una clave que no este en
  el ~/.ssh/config, indicarla:
  D2O_SSH_KEY=~/.ssh/mi-clave.pem ./desplegar-nube.sh $TARGET"
fi
ok "Acceso correcto"

info "Subiendo el fuente"
# Los datos nunca viajan: viven en la maquina. Subir el estado de tu PC
# borraria el contenido que hay ahora mismo en directo.
# rsync no lee nada de ssh, asi que la clave hay que pasarsela explicitamente.
RSYNC_SSH=(ssh -o BatchMode=yes -o ConnectTimeout=10)
[ -n "$KEY" ] && RSYNC_SSH+=(-i "$KEY")

rsync -az --delete -e "${RSYNC_SSH[*]}" \
  --exclude node_modules --exclude test --exclude .git --exclude data \
  --exclude '*.log' --exclude '.env' --exclude '.env.*' \
  --exclude '*.pem' --exclude '*.key' \
  "$HERE"/ "$TARGET:$STAGE"/
ok "Fuente en $STAGE"

# --------------------------------------------------------- 2. instalar --
info "Instalando y reiniciando"
ssh "${SSH_OPTS[@]}" "$TARGET" "cd '$STAGE' && chmod +x install.sh && ./install.sh --port 8787 --data-dir '$DATA_DIR' --admin admin" \
  >/tmp/luckyobs-deploy.log 2>&1 || {
  tail -20 /tmp/luckyobs-deploy.log >&2
  die "install.sh fallo en la maquina (log en /tmp/luckyobs-deploy.log)"
}
ok "Servicio reiniciado"

# -------------------------------------------------------- 3. comprobar --
info "Comprobando"
sleep 3
# Primero en la propia maquina: si eso falla, el problema no es el proxy.
if ! ssh "${SSH_OPTS[@]}" "$TARGET" 'curl -fsS http://127.0.0.1:8787/healthz' >/dev/null 2>&1; then
  ssh "${SSH_OPTS[@]}" "$TARGET" 'journalctl --user -u luckyobs -n 20 --no-pager' >&2 || true
  die "La app no responde en la maquina"
fi
ok "La app responde en la maquina"

if [ -n "$DOMAIN" ]; then
  if curl -fsS "https://$DOMAIN/healthz" >/dev/null 2>&1; then
    ok "Y tambien por https://$DOMAIN"
  else
    printf '\033[33m!\033[0m La maquina va bien pero https://%s no responde.\n' "$DOMAIN"
    printf '  Comprueba el DNS (dig +short %s) y:\n' "$DOMAIN"
    printf '  ssh%s %s "sudo journalctl -u luckyobs-caddy -n 30 --no-pager"\n' "${KEY:+ -i $KEY}" "$TARGET"
  fi
fi

echo
ok "Desplegado"
if [ -n "$DOMAIN" ]; then
  printf '   OBS:  https://%s/stage?t=<token>\n' "$DOMAIN"
  printf '   Web:  https://%s/\n' "$DOMAIN"
fi
printf '   Logs: ssh%s %s "journalctl --user -u luckyobs -f"\n' "${KEY:+ -i $KEY}" "$TARGET"
echo