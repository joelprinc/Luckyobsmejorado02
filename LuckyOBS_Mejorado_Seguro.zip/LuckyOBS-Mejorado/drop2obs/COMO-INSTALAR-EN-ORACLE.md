# LuckyOBS en Oracle Cloud (gratis, 24/7)

Todo lo que hay que hacer, en orden. Lo que depende de Oracle lo haces tú en el
navegador (tarjeta y aceptacion de terminos); el resto lo hace un script.

## 1. Crear la cuenta y la maquina (en el navegador)

1. Entra en <https://cloud.oracle.com/free> y creala. Pide tarjeta, pero **no cobra**:
   deja una retencion de un céntimo o similar que se devuelve. Solo se acepta
   tarjeta de credito o debito **de un pais con Oracle disponible** (entre ellos Espana).
2. Cuando te pidan la **Home Region**, elige una y **no la podras cambiar nunca**:
   - `Madrid` (eu-madrid-1): lo mas cerca de tu amigo en Espana.
   - `Amsterdam` (eu-amsterdam-1): si Madrid da error de capacidad.
   Evita `US` si puedes: el stream va a Espana y a Latinoamerica.
3. Crea la maquina: **Compute > Instances > Create**. Elige **Always Free-eligible**.
   - Shape: `VM.Standard.A1.Flex` con **2 OCPU y 12 GB** (lo que queda gratis hoy).
   - Image: **Ubuntu 24.04**.
   - Networking: deja la VCN por defecto. La IP pública sale automática y es
     efímera; en el paso 2 se convierte en reservada, que es lo importante.
   - SSH: deja la clave por defecto.
4. Si te sale **"out of host capacity"**: no es un fallo tuyo, es que ese
   hardware gratis esta ocupado. Cambia de **Availability Domain** (abajo a la
   derecha al crear la maquina) o prueba otro dia. Si tras varios intentos no
   hay suerte, la region `eu-zurich-1` suele tener hueco.

Cuando termine, la maquina tiene una **IP pública**. Cópiala: la vas a necesitar.

### Reserva la IP (2 minutos, gratis, no te lo saltes)

Por defecto esa IP es **efímera**: si la maquina se para y vuelve a arrancar
(cosa que Oracle hace con las cuentas Always Free que no ve activas), le da otra
distinta. Tu dominio apuntaría a una IP vieja y el sitio se quedaría muerto sin
aviso.

Con la maquina creada:
**Red > Instancias de Red Virtual > IP Publicas > la que pone "efimera" >
botón derecho > Convertir en IP Publica Reservada**.

Hazlo ahora y compruebalo: en la lista, la IP debe decir **reservada** y tener un
nombre. Ese nombre es para que la reconozcas; la IP es la misma.

## 2. El dominio

El HTTPS automatico de Caddy (Let's Encrypt) **no emite certificados para una IP**,
asi que hace falta un nombre. Sirve cualquiera de estos dos casos:

### Si ya tienes un dominio (lo normal)

No compres nada. Anade un subdominio apuntando a la maquina, en el panel de
donde gestionas tus zonas DNS:

| Tipo | Nombre | Valor |
|---|---|---|
| `A` | `obs` (o el subdominio que quieras) | la IP de la maquina |

A partir de aqui el sitio vive en `https://obs.tudominio.com`. Recomendado un
subdominio antes que la raiz del dominio, para no tocar lo que ya tengas ahi.

**Si tu dominio esta en Cloudflare**, crea el registro en **solo DNS** (la nube
gris, no la naranja). Con la nube naranja el trafico pasa por Cloudflare, y para
una pagina que se actualiza en vivo con websockets es mejor no interponerlo: se
pueden meter cachés en medio y OBS se veria raro.

Espera a que propague (unos minutos; comprueba con `dig +short obs.tudominio.com`)
y debe dar la IP de la maquina.

### Si no tienes dominio

Dos caminos:

- **Tailscale Funnel** (gratis, sin comprar nada): da una direccion
  `https://algo.ts.net` con HTTPS incluido y deja la IP de la maquina oculta.
  Menos comodo de configurar, cero coste.
- Comprar uno (Namecheap, Porkbun, Cloudflare...) y apuntarlo a la IP, igual que
  el caso anterior.

## 3. Conectar y desplegar (aquello es un comando)

Desde tu PC:

```bash
ssh -i ~/.ssh/<tu-clave>.opc ubuntu@<IP-DE-LA-MAQUINA>
```

Y dentro, copia el programa y ejecuta el script:

```bash
mkdir -p ~/luckyobs-fuente
# (copia aqui la carpeta del proyecto, ver siguiente seccion)

chmod +x ~/luckyobs-fuente/install.sh
~/luckyobs-fuente/preparar-nube.sh tudominio.com tu@correo.com
```

El script instala Node, la app con su servicio, Caddy con el HTTPS automatico,
baja el limite de subida a 500 MB y comprueba que todo responde. Tarda unos
5 minutos.

## 4. Cerrar el puerto de la app

**En el panel de Oracle** (no en el servidor): red > la VCN > Security Lists >
la regla de origen `0.0.0.0/0` sobre el puerto **8787** -> **editarla y quitarla**.
Deja abiertos el 22 (SSH), el 80 y el 443. El 8787 solo lo usa Caddy, que esta en
la misma maquina.

## 5. La fuente en el OBS de tu amigo

1. En el OBS, `Fuentes > + > Navegador`.
2. URL: `https://obs.tudominio.com/stage?t=<token>`.
   El token lo sacas de la consola del servidor:
   ```bash
   cat ~/.local/share/luckyobs-data/token.txt
   ```
   O desde la propia web: `https://obs.tudominio.com/` → "Enlace de OBS".
3. Ancho `1920`, alto `1080`. CSS personalizado vacio.
4. **Control audio via OBS** activado (es lo que mete el sonido del stream en la
   mezcla; el fondo tambien suena si tu amigo quiere).

Los moderadores entran en `https://obs.tudominio.com/` con su cuenta.

## Cosas que conviene saber

- **Si Oracle para la maquina**: las Always Free las para si pasan 7 dias por debajo del 20% de CPU y de red. A ti te pasara. Te avisan por email y los datos
  siguen ahi: `Compute > Instances > Start`. Si te pasa mucho, el plan B es un
  VPS de pago (Hetzner CX22, ~3,80 EUR/mes) y ya no hay que vigilar.
- **Copia de seguridad**: los datos estan en `~/.local/share/luckyobs-data` (una
  carpeta con el estado y los medios). Bajar eso es tu backup. En Oracle se
  puede hacer snapshot del volumen, pero para una cosa tan pequena copia manual
  y listo.
- **Reiniciar la maquina**: el servicio arranca solo (linger activado). El
  certificado de Caddy tambien se renueva solo.