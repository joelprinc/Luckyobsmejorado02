# LuckyOBS

Arrastra una imagen, un GIF, un vídeo, un audio, una página web o un texto a una
página web y aparece **al instante en la pantalla de OBS** de tu amigo, como un
objeto que puedes mover, ocultar, mostrar o quitar cuando quieras.

La página de control tiene **una pantalla larga, como las de un programa de
televisión**: la mitad de arriba es la **emisión**, que es lo que ve tu amigo, y la
de abajo es el **banco**, donde dejas lo que todavía no quieres emitir. Una línea
las separa. Mueves, escalas y giras los objetos arrastrándolos, y mientras lo
haces tu amigo lo ve moverse en directo, sin esperas.

No hay que instalar nada en el OBS de tu amigo: solo una **fuente de navegador**
con el enlace que te da el servidor.

```
┌──────────────┐   HTTP + WebSocket   ┌──────────────┐   HTTPS/HTTP   ┌──────────────────┐
│  navegador   │ ───────────────────► │  LuckyOBS    │ ──────────────► │  fuente Navegador│
│  arrastrar   │ ◄─────────────────── │  (Node.js)   │  /stage (en    │  dentro de OBS   │
└──────────────┘   estado en vivo     └──────────────┘   vivo,         └──────────────────┘
                                                          transparente)
```

## Qué necesita cada uno

| | En tu equipo (servidor) | En el equipo de tu amigo (OBS) |
|---|---|---|
| Necesario | Node.js 18+ | OBS 28 o superior (fuente *Navegador*) |
| Nada más | `systemd` para el arranque automático | — |

---

## 1. Instalar el servidor (tu equipo)

```bash
cd luckyobs
./install.sh
```

El instalador copia el servidor a `~/.local/share/luckyobs`, instala las
dependencias, crea el servicio systemd de usuario y lo arranca.

La cuenta de administrador (`admin` por defecto) **solo se crea si no hay
ninguna cuenta**: si ya existen, el instalador no toca ninguna. Así una cuenta
que borres a propósito no vuelve en el siguiente despliegue. Para añadir cuentas
después, con el servidor en marcha:

```bash
npm run user -- add ana --admin
```

En una instalación nueva termina así (las credenciales solo se muestran esta vez):

```
▸ No hay ninguna cuenta: creo el administrador 'admin'
✔ Administrador listo. Guarda la clave, no se vuelve a mostrar:
   usuario: admin
   clave:   Kq7bRt2Wn9xLp4Zm
▸ En el OBS de tu amigo no hay que instalar nada:
   1. Fuentes ▸ + ▸ Navegador
   2. URL: http://192.168.1.28:8787/stage?t=<token>
   4. CSS personalizado: vacío
```


El enlace lleva el token dentro. Al abrirlo, el servidor lo cambia por una
cookie y redirige a `/stage`, así que el token no se queda en la barra de
direcciones de OBS.

Desinstalar:

```bash
./install.sh --uninstall      # para el servicio y borra la copia instalada
rm -rf ~/.local/share/luckyobs-data  # solo si también quieres borrar las escenas, los medios y el token
```

## 2. Montarlo en el OBS de tu amigo

1. **Fuentes ▸ + ▸ Navegador** (en OBS en español; *Browser* en inglés).
2. Pega el enlace del paso 1 en **URL**. Cópialo del diálogo **Enlace de OBS**
   del panel: sale con la dirección pública del servidor
   (`https://luckyobs.w4rfin.com/stage?t=...`), no con la IP de casa, porque
   el que lo usa está en otro sitio. Es un enlace de solo lectura y lleva la
   clave dentro.
3. **No toques ancho ni alto.** La fuente se ajusta sola al lienzo que tengas, y
   sin deformar: por eso aquí ya no hay ningún tamaño que anotar.
4. Deja **CSS personalizado** vacío y el chequeo *Shutting down OBS when
   browser becomes inactive* tal cual.
5. Nombre sugerido: `LuckyOBS`, y colócalo por encima de las fuentes de cámara.
   El fondo es transparente, así que se mezcla con lo que haya debajo.

A partir de ahí la fuente se actualiza sola: cada archivo que subas aparece
enseguida, y si tu amigo reinicia OBS o el router, vuelve a conectar sola.

El **sonido** también sale: un vídeo suena en la fuente de OBS y se calla en tu
página, así que se oye una sola vez y sin eco. Cada clip lleva **su propio volumen
(0-100)**, que se ajusta desde la barra del objeto y es el mismo que se oye en
OBS. Deja *Control audio via OBS*
activado en la fuente (viene activado por defecto), que es lo que mezcla el
sonido con el resto de la escena.

### Las tipografías

La fuente de OBS se dibuja en el ordenador de tu amigo, así que una letra
instalada solo aquí no serviría de nada: la etiqueta saldría con la fuente que
tenga por defecto ese equipo. Por eso el programa **lleva dos tipografías
servidas por sí mismo**:

| En el programa | Se usa | Cómo está resuelto |
|---|---|---|
| **Arial** | Arial, y si no hay, Liberation Sans | Va incrustada. Liberation Sans es métricamente igual que Arial, así que las líneas se parten en el mismo sitio. |
| **Comic Sans** | Comic Sans MS, y si no hay, Comic Neue | Va incrustada. Comic Sans MS viene con Microsoft Office, y no se puede redistribuir. |
| **Papyrus** | Papyrus, y si no hay, una serif | **No va incrustada:** es una tipografía registrada y las copias que circulan son de uso personal. Para tener la de verdad, instálala en el ordenador que tiene el OBS. |

También hay Impact, Georgia y una monoespaciada. Las dos incrustadas son libres
(SIL Open Font License) y su licencia está en `public/fuentes/`. Para
reconstruirlas: `~/[01] Digital Fingerprint/[99] Otros/Scripts/Opencode/luckyobs-fuentes.sh`.

### Ajustes opcionales del enlace

| Parámetro | Qué hace |
|---|---|
| `ui=1` | Muestra un HUD abajo a la izquierda (conexión, tamaño, nº de objetos) mientras la configuras. Quítalo antes de grabar. |
| `fit=0.9` | Fija el tamaño del contenido respecto al lienzo (`0.5`–`1`). Por defecto la fuente ajusta el lienzo entero a la fuente de navegador, sin deformarlo. |
| `fit=off` | Lo mismo que el valor por defecto: encajar. |
| `bg=1` | Fondo oscuro en vez de transparente, útil para probar la fuente fuera de OBS. |

Ejemplo para probar en un navegador normal: `.../stage?t=<token>&ui=1`.

## 3. Entrar y enviar cosas (tú)

Abre `https://luckyobs.w4rfin.com/` y entra con el usuario y la clave del
instalador. A partir de ahí la sesión dura 30 días.

El servidor está en tu equipo, pero se llega a él por el túnel de Cloudflare, así
que también funciona desde el móvil o desde el PC de tu amigo, y con https. En la
red de casa `http://<ip-local>:8787/` sigue funcionando igual.

### La página

Dos columnas: la **pantalla** a la izquierda (60%) y a la derecha todo lo demás
(40%). En una ventana estrecha se apilan, con la pantalla arriba.

Lo que se pone en pantalla son **objetos**: archivos que arrastras, y textos que
añades con el botón `T`. Cada uno se coloca donde lo sueltas y se va con el ratón
como cualquier otro. Para algo que vaya de fondo en el stream, un vídeo o una
imagen fija, lo más simple es una fuente aparte en OBS por detrás de esta.

| Tarjeta | Qué es |
|---|---|
| **Moderadores** | Quién tiene la página abierta ahora mismo, y debajo el resto con la hora de su última conexión. |
| **Historial** | Qué archivo se subió o se quitó, cuándo y quién. Se guarda entre reinicios; solo un administrador puede vaciarlo. |

### Ocultar todo (tu amigo, desde el Stream Deck)

Hay un interruptor que **se lleva el show entero de la pantalla de un golpe**: no
se dibuja ningún objeto y no se oye nada. **No borra ni mueve nada**, así que
volver a emitir devuelve el show tal y como estaba, en el mismo instante y con
el mismo vídeo en el segundo en que iba.

Tres formas de accionarlo, todas las mismo:

| Desde | Cómo |
|---|---|
| **Stream Deck** | Una acción *Send HTTP Request* (o similar) con esta dirección: `https://luckyobs.w4rfin.com/api/control/hidden?key=<CLAVE>`. Cada pulsación alterna: oculta, y la siguiente vuelve a emitir. |
| **La página web** | El botón **Ocultar todo** de la barra superior, o `Ctrl+Shift+H`. **Solo para administradores**: un moderador mueve cosas, pero cortar la emisión es del dueño (o del deck). El servidor tampoco se lo permite. |
| **La terminal** | `curl "http://127.0.0.1:8787/api/control/hidden?key=<CLAVE>"` |

La dirección exacta, con la clave ya puesta, está en **Enlace de OBS → Botón de
Stream Deck**, y el instalador también la imprime. La clave va en
`<data>/control.txt` y se crea sola la primera vez; se puede leer con
`cat ~/.local/share/luckyobs-data/control.txt`.

Detalles que importan:

- La clave de este botón **no** es la del enlace de OBS. La del OBS va pegada en
  el navegador de quien retransmite y es de solo lectura; esta solo abre y cierra
  el show, y por eso vive aparte.
- Un `GET` alterna. Un `POST` en la misma dirección con `{"hidden": true}` o
  `{"hidden": false}` fija el estado, que es lo que quieres si el botón tiene un
  pulsador de "oculto" y otro de "visible". También se puede mandar la clave en
  la cabecera `X-D2O-Control`.
- **Indicador en la web:** el botón solo se ve con una cuenta de administrador,
  igual que "Gestionar usuarios" y el enlace de OBS. Mientras está oculto, el
  indicador de la barra de arriba dice **"Pantalla no visible"** con la led en
  amarillo. Ese indicador, por lo demás, dice **OBS conectado** u **OBS
  desconectado** con la led en verde o en rojo. Todo el que tenga la página
  abierta lo ve al momento, y el OBS se apaga en el acto por el socket, sin
  recargar nada.
- **Si la fuente de OBS se queda colgada**, el indicador de la barra lo dice
  antes de que emitáis en negro. La fuente manda un latido cada 5 segundos y, con
  él, cuándo dibujó por última vez, así que el panel cuenta los segundos solo:

  | Qué pone | Qué significa |
  |---|---|
  | **OBS conectado · 1920×1080 · hace 3 s** | Todo bien. |
  | **OBS congelado · hace 40 s** | Responde pero **no dibuja**: la fuente del navegador está colgada. Recárgala en OBS. |
  | **OBS sin respuesta · hace 1 min** | La fuente ni siquiera contesta. Recárgala en OBS. |
  | **OBS desconectado** | Nadie tiene abierta la fuente de navegador. |
- **Escuchar desde la página** (botón "Escuchar", también de administrador): el
  panel dibuja los clips **mudos** a propósito, para no oír dos veces lo que ya
  suena por OBS. Con el botón pulsado esta página sí hace ruido, que es lo
  cómodo para preparar sin OBS abierto. Vuelve a silencio al pulsarlo otra vez y
  nunca empieza solo.
- En el HUD de depuración de la fuente (`ui=1`) sale "todo oculto" en vez de
  "en vivo".

### La pantalla larga

| | Qué es |
|---|---|
| **Emisión** (sobre la línea) | Lo que ve tu amigo. Lo que hay aquí está en directo. |
| **Banco** (bajo la línea) | Borrador. Lo que hay aquí no se ve todavía. |

Es **una sola pantalla de 1920 × 2160**: la emisión son sus 1080 píxeles de arriba
y el banco los 1080 de abajo. Las dos mitades comparten coordenadas, así que un
objeto que dejas en el banco aparece en el mismo sitio del escenario al llevarlo
a emisión. El OBS solo ve la mitad de arriba.

- **Arrastra un archivo** a la pantalla, o haz clic en el banco para buscarlo.
  Sin punto de soltado cae en el banco y queda preparado; suéltalo por encima de
  la línea y sale directamente.
- Para **llevar algo del banco a la emisión** no hay ningún botón: lo arrastras
  por encima de la línea. También se puede volver abajo.
- Al seleccionar un objeto aparece la **barra de objeto** con `x`, `y`, ancho,
  alto, rotación y opacidad, y una caja con tiradores para escalar o rotar.
- Si el objeto es un **vídeo o un audio**, en esa barra sale un **volumen de 0 a
  100** en vez de un interruptor de silencio: un clip a media voz es una cosa
  normal, y el 0 es simplemente el extremo más bajo del mando. Está también, en
  versión pequeña, en cada fila de la lista de "En la pantalla". El número va con
  el volador y **guarda cuando sueltas**, no mientras arrastras. En la fuente de
  OBS el mismo volumen es el que se oye.
- Un **vídeo o un audio** tiene, junto al volumen, una **barra de duración** para
  saltar a otro momento, como en un vídeo de YouTube. El salto no se queda en tu
  panel: la fuente de OBS va al mismo segundo, porque el servidor guarda el
  instante del salto y cada pantalla lo va sumando por su cuenta. Con bucle
  activado el momento da la vuelta al llegar al final; sin bucle, se para ahí.
  Volver a empezar se hace con **▶**, y el `0` de la barra lleva el clip a su
  principio.
- Un **audio** (mp3 y compañía) se dibuja como una tarjeta con su nombre y un
  ecualizador que se mueve mientras suena: un mp3 dentro de un `<video>` no tiene
  dibujo ninguno y en el stream parecería un objeto roto.
- Con **Añadir un texto** (el botón `T` de la pantalla) aparece una etiqueta en el
  banco, ya seleccionada para escribir. Los controles de su barra son las
  palabras, la tipografía, el tamaño y el color; se guardan cuando sueltas el
  ratón o el teclado. Por defecto sale en **Arial, a 96 px y en blanco**, que es
  legible sobre cualquier cosa.
- El punto donde coges el objeto es el punto donde se queda: no salta al
  empezar a arrastrar, y cae justo donde sueltas.
- Al **redimensionar se mantiene la proporción**: un clip de 16:9 sigue siendo
  de 16:9 en vez de deformarse. **Un texto es la excepción:** su caja no es una
  imagen sino el sitio que tienen las palabras, así que se estira en ancho y alto
  por separado, y con Ctrl (o **⌘**) sí se bloquea la proporción. La esquina sigue al puntero por el eje que más
  tires y el lado contrario se queda quieto. Manteniendo **Ctrl** (o **⌘**) el
  objeto sí se estira a tu gusto, y con **Alt** creces desde el centro en vez de
  desde la esquina. Los números de la barra siempre son exactos: si escribes un
  ancho y un alto, mandas esos.
- Se **encajan** los bordes y los centros con los de los demás objetos y con el
  del lienzo, con guías rojas mientras dura el ajuste. Manteniendo **Ctrl** (o
  **⌘**) el objeto se mueve sin ajustarse, para cuando necesitas un píxel
  exacto.
- **🔒** bloquea el objeto para que no se mueva por accidente, **👁** lo oculta o
  muestra al instante, **⊕** lo centra, **⤢** lo ajusta al ancho, **🖱** usa la
  página (solo si el objeto es una página web), **⧉** lo duplica y **✕** lo
  quita. Atajos: `Ctrl`+`D` duplica, `Supr` borra y `Esc` deselecciona.
- Un objeto nunca se sale de la pantalla: siempre asoma lo suficiente para poder
  cogerlo, porque fuera del panel no se podría ni mover ni borrar.
- **Doble clic** en un objeto lo centra. Si el objeto es una **página web**, el
  doble clic en vez de eso le pasa el ratón: a partir de ahí se hace clic dentro
  con normalidad, y con `Esc` (también desde dentro de la página), con otro doble
  clic o con un clic fuera, el objeto vuelve a editarse.
- **Vaciar banco** borra solo lo que hay bajo la línea. **Vaciar emisión** saca
  todo de directo y deja la pantalla limpia. Un objeto que cruza la línea se va
  con el banco: dejarlo a medias dejaría un trozo en directo sin forma de
  quitarlo.

Mientras arrastras, tu amigo ve el objeto moverse en su pantalla a la vez. Al
soltar se guarda; si el navegador se cierra a mitad de un arrastre, la posición
final es la anterior, no una posición a medias.

- La cabecera indica si la pantalla de tu amigo está conectada y a qué tamaño.
- Arriba a la derecha está tu usuario: **Cambiar mi contraseña**,
  **Gestionar usuarios** y **Salir**.
- Si eres administrador, el botón **Gestionar usuarios** abre el panel para
  crear, cambiar el rol, desactivar, cambiar la clave o borrar cuentas.

### Usuarios y roles

Cada persona con cuenta entra por su propio nombre. Hay dos roles:

| Rol | Puede |
|---|---|
| `mod` | Preparar cosas en el banco, llevarlas a la emisión, colocar, mover, ocultar y vaciar. |
| `admin` | Lo mismo, y además gestionar las cuentas. |

El enlace de OBS es de **solo lectura** aunque lleve el token dentro, así que
nadie puede tocar el directo desde la fuente del receptor.

### Desde la terminal

```bash
npm run user -- list                      # ver cuentas
npm run user -- add bea --role mod        # moderadora (clave generada)
npm run user -- add ana --admin           # administradora
npm run user -- pass bea                  # clave nueva
npm run user -- role bea admin            # cambiar rol
npm run user -- disable bea               # cortar el acceso sin borrar
npm run user -- remove bea                # borrar la cuenta
```

Funciona con el servicio arrancado: el servidor recarga `auth.json` solo.

### Formatos

Se admite casi cualquier formato: imágenes (png, jpg, webp, avif, svg…),
GIF, vídeo (mp4, webm, mkv, mov…), audio, html, txt, md, json, csv, xml, pdf.
Un `.html` se muestra en un iframe aislado; un `.txt` se pinta como texto.

## 4. Configuración

Todo se puede cambiar por variables de entorno o argumentos
(`server/config.js`):

| Opción | Por defecto | Para qué |
|---|---|---|
| `--port` / `D2O_PORT` | `8787` | Puerto del servidor |
| `--host` / `D2O_HOST` | `0.0.0.0` | Interfaz de escucha |
| `--token` / `D2O_TOKEN` | aleatorio, en `data/token.txt` | Clave de acceso |
| `--data` / `D2O_DATA_DIR` | `~/.local/share/luckyobs-data` | Escenas, medios y token |
| `--canvas` / `D2O_CANVAS` | `1920x1080` | Tamaño de la emisión, con el que se dibuja la escena. La pantalla es el doble de alto, con el banco justo debajo |
| `--history` / `D2O_HISTORY` | `200` | Cuántos pasos se recuerdan para deshacer |
| `--max-upload-mb` / `D2O_MAX_UPLOAD_MB` | `2048` | Tamaño máximo por archivo |
| `--upload-ttl-hours` / `D2O_UPLOAD_TTL_HOURS` | `24` | Cuándo se limpia la cola |
| `--public-url` / `D2O_PUBLIC_URL` | — | URL pública si usas proxy o túnel |
| `--trust-proxy` / `D2O_TRUST_PROXY` | `false` | Aceptar `X-Forwarded-*` |
| `--log-requests` / `D2O_LOG_REQUESTS` | `true` | Log de peticiones |
| `--login-max-per-user` / `D2O_LOGIN_MAX_PER_USER` | `5` | Fallos de clave antes de bloquear 15 min |
| `--login-max-per-ip` / `D2O_LOGIN_MAX_PER_IP` | `30` | Fallos por IP antes de bloquear 15 min |

## 5. Desarrollo

```bash
npm install
npm start                 # servidor en primer plano
npm test                  # 60 tests de API, usuarios, auth, escenas, stage y medios
npm run dev               # con recarga automática
```

## 6. Si algo va mal

```bash
systemctl --user status luckyobs
journalctl --user -u luckyobs -f
```

| Síntoma | Causa habitual |
|---|---|
| En OBS sale negro o un error rojo | La fuente está en la posición equivocada de la lista, o falta el ancho/alto. Prueba con `bg=1` para verlo. |
| El contenido sale cortado | `fit` demasiado alto: usa `fit=0.85`. |
| Sale "sin conexión" en la web pero la fuente funciona | La fuente de OBS sigue viva con la última imagen: el estado solo refleja el websocket actual. |
| Dice "sin servidor" y no se mueve nada | El panel no ha podido conectar con el servidor. Recarga la página; si sigue igual, mira el log del servicio. |
| En OBS va con retraso en vez de en directo | La fuente está entrando por la consulta de emergencia de 4 segundos en lugar del websocket. Comprueba que la fuente tiene la cookie: vuelve a abrir el enlace con `?t=<token>` del panel. |
| La web pide entrar otra vez | La sesión caducó (30 días) o se borró el perfil: entra con usuario y clave. |
| Dice «demasiados intentos» | Cinco claves seguidas fallaron: espera 15 minutos. |
| Se ha olvidado la clave del administrador | `npm run user -- pass admin` genera una nueva sin parar el servicio. |
| Alguien se ha quedado sin acceso | `npm run user -- enable <usuario>` |
| El amigo no puede abrir el enlace | Estáis en redes distintas: hace falta túnel/proxy (`--public-url`) o abrir el puerto en el router. |

## 7. Seguridad

- La gestión va detrás de **usuario y contraseña**; las contraseñas se guardan
  con `scrypt` y sal por cuenta, y las sesiones duran 30 días.
- El enlace de OBS lleva el token y da **solo lectura**: no puede subir, enviar
  ni borrar nada, ni crear cuentas. Los medios van firmados con HMAC.
- Si no hay ninguna cuenta, el token puede gestionarlo todo (para que la
  instalación no quede sin dueño); en cuanto creas la primera, deja de poder.
- Nunca se puede quedar la instalación sin un administrador activo: el sistema
  se niega a degradar, desactivar o borrar al último.
- Cambiar una contraseña, desactivar una cuenta o borrarla cierra al instante
  las sesiones que tuvieran abiertas.
- Los intentos de acceso se limitan por usuario y por IP.
- Para exponerlo a internet, ponlo detrás de HTTPS (Caddy, nginx, Tailscale…)
  y activa `--trust-proxy`.
