#!/usr/bin/env bash
# LuckyOBS · instalador del servidor.
#
#   ./install.sh                instala, arranca y crea la cuenta de administrador
#   ./install.sh --port 9000    cambia el puerto
#   ./install.sh --admin ana    nombre del administrador (por defecto: "admin")
#   ./install.sh --uninstall    para el servicio y borra la copia instalada
#
# Instala el servidor como servicio systemd de usuario (no necesita sudo salvo
# para activar "linger", que es opcional y solo se pide si falta).

set -euo pipefail
umask 077

SERVICE="luckyobs"
PORT="${D2O_PORT:-8787}"
ADMIN_USER="${D2O_ADMIN_USER:-admin}"
SRC_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PREFIX="${D2O_PREFIX:-$HOME/.local/share/$SERVICE}"
DATA_DIR="${D2O_DATA_DIR:-$HOME/.local/share/$SERVICE-data}"
UNIT_DIR="$HOME/.config/systemd/user"
UNIT_FILE="$UNIT_DIR/$SERVICE.service"

info() { printf '\033[36m▸\033[0m %s\n' "$*"; }
ok() { printf '\033[32m✔\033[0m %s\n' "$*"; }
die() { printf '\033[31m✘\033[0m %s\n' "$*" >&2; exit 1; }

usage() {
  sed -n '2,10p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'
  exit 0
}

do_uninstall() {
  info "Parando el servicio…"
  systemctl --user disable --now "$SERVICE.service" 2>/dev/null || true
  rm -f "$UNIT_FILE"
  systemctl --user daemon-reload 2>/dev/null || true
  rm -rf "$PREFIX"
  ok "Servicio parado y copia eliminada ($PREFIX)"
  info "Los datos siguen en $DATA_DIR (bórralos a mano si ya no los quieres)"
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --port) PORT="${2:?falta el puerto}"; shift 2 ;;
    --admin) ADMIN_USER="${2:?falta el usuario}"; shift 2 ;;
    --admin-password) ADMIN_PASSWORD="${2:?falta la contraseña}"; shift 2 ;;
    --prefix) PREFIX="${2:?falta la ruta}"; shift 2 ;;
    --data-dir) DATA_DIR="${2:?falta la ruta}"; shift 2 ;;
    --uninstall) do_uninstall; exit 0 ;;
    -h|--help) usage ;;
    *) die "Opción desconocida: $1 (usa --help)" ;;
  esac
done

command -v node >/dev/null 2>&1 || die "Falta node.js (Node 18 o superior)"
command -v npm >/dev/null 2>&1 || die "Falta npm"
command -v systemctl >/dev/null 2>&1 || die "Falta systemctl (este instalador es para sistemas con systemd)"

NODE_BIN="$(command -v node)"
NODE_MAJOR="$("$NODE_BIN" -p 'process.versions.node.split(".")[0]')"
if (( NODE_MAJOR < 18 )); then
  die "Node $NODE_MAJOR es demasiado antiguo; hace falta 18 o superior"
fi

# El nombre cambio de drop2obs a luckyobs. Los datos no se pierden: se copian
# al directorio nuevo y el viejo se deja a mano por si algo va mal.
LEGACY_SERVICE="drop2obs"
LEGACY_DATA="$HOME/.local/share/$LEGACY_SERVICE-data"
if [ "$SERVICE" != "$LEGACY_SERVICE" ] && [ -d "$LEGACY_DATA" ] && [ ! -d "$DATA_DIR" ]; then
  info "Traigo los datos de $LEGACY_DATA (servicio anterior: $LEGACY_SERVICE)"
  cp -a "$LEGACY_DATA" "$DATA_DIR"
  ok "Datos conservados: cuentas, token, medios e historial"
  info "El servicio viejo sigue instalado; cuando compruebes que todo va bien:"
  info "  systemctl --user disable --now $LEGACY_SERVICE.service"
  info "  rm -rf $LEGACY_DATA"
fi

info "Copiando el servidor a $PREFIX"
mkdir -p "$PREFIX"
if command -v rsync >/dev/null 2>&1; then
  rsync -a --delete \
    --exclude 'node_modules' --exclude 'test' --exclude '.git' --exclude 'data' \
    --exclude '.env*' --exclude '*.pem' --exclude '*.key' \
    "$SRC_DIR/" "$PREFIX/"
else
  rm -rf "$PREFIX"
  mkdir -p "$PREFIX"
  ( cd "$SRC_DIR" && tar --exclude=node_modules --exclude=test \
      --exclude=.git --exclude=data --exclude='.env*' --exclude='*.pem' --exclude='*.key' -cf - . ) | tar -xf - -C "$PREFIX"
fi

info "Instalando dependencias"
( cd "$PREFIX" && npm install --omit=dev --no-audit --no-fund --loglevel=error )

info "Preparando los datos en $DATA_DIR"
mkdir -p "$DATA_DIR"

# La cuenta se crea con el mismo cli que se puede usar después, así que si el
# servicio está corriendo no hace falta pararlo: el servidor recarga el archivo.
# El cli tiene que tocar el mismo directorio de datos que el servicio.
export D2O_DATA_DIR="$DATA_DIR"

# El administrador solo se crea en una instalacion de verdad, cuando no hay
# ninguna cuenta. Antes se llamaba 'ensure' siempre y eso devolvia la cuenta
# 'admin' en cada despliegue, incluso cuando el dueno la habia borrado a
# proposito: instalar el programa no debe tocar las cuentas que ya existen.
EXISTING="$("$NODE_BIN" "$PREFIX/server/cli-users.js" count 2>/dev/null || echo 0)"
NEW_PASSWORD=""
if [[ "${EXISTING:-0}" -eq 0 ]]; then
  info "No hay ninguna cuenta: creo el administrador '$ADMIN_USER'"
  ADMIN_OUT="$("$NODE_BIN" "$PREFIX/server/cli-users.js" ensure "$ADMIN_USER" --admin 2>&1)" \
    || die "No se pudo crear el administrador: $ADMIN_OUT"
  NEW_PASSWORD="$(printf '%s\n' "$ADMIN_OUT" | sed -n 's/^CLAVE=//p')"
  if [[ -n "${ADMIN_PASSWORD:-}" ]]; then
    "$NODE_BIN" "$PREFIX/server/cli-users.js" pass "$ADMIN_USER" --password "$ADMIN_PASSWORD" >/dev/null \
      || die "No se pudo fijar la contraseña del administrador"
    NEW_PASSWORD="$ADMIN_PASSWORD"
  fi
else
  # ADMIN_PASSWORD en un despliegue con cuentas ya no se aplica: no se toca la
  # clave de nadie. Para cambiar una, esta el comando 'pass' del cli.
  info "Ya hay $EXISTING cuenta(s): no se crea ninguna ni se toca ninguna clave"
  if [[ -n "${ADMIN_PASSWORD:-}" ]]; then
    info "(--admin-password se ha ignorado: con cuentas existentes no se cambian)"
  fi
fi

info "Escribiendo $UNIT_FILE"
mkdir -p "$UNIT_DIR"
sed -e "s|@NODE@|$NODE_BIN|g" \
    -e "s|@APPDIR@|$PREFIX|g" \
    -e "s|@DATADIR@|$DATA_DIR|g" \
    -e "s|@PORT@|$PORT|g" \
    "$SRC_DIR/systemd/$SERVICE.service.in" > "$UNIT_FILE"

info "Arrancando el servicio"
systemctl --user daemon-reload
systemctl --user enable "$SERVICE.service"
systemctl --user restart "$SERVICE.service"

# El servicio de usuario solo arranca con una sesión iniciada: sin linger, un
# reinicio deja la web apagada hasta que entres al escritorio. En un servidor sin
# sesión grafica, como una maquina en la nube, USER no esta definido.
TARGET_USER="${USER:-$(id -un)}"

if ! loginctl show-user "$TARGET_USER" -p Linger --value 2>/dev/null | grep -q '^yes$'; then
  info "Activando linger para que arranque al encender el equipo (pide sudo)"
  if command -v loginctl >/dev/null 2>&1; then
    sudo -n loginctl enable-linger "$TARGET_USER" 2>/dev/null \
      && ok "Linger activado" \
      || info "No se pudo activar el linger; ejecuta tú: sudo loginctl enable-linger $TARGET_USER"
  fi
fi

for _ in $(seq 1 40); do
  if curl -fsS "http://127.0.0.1:$PORT/healthz" >/dev/null 2>&1; then break; fi
  sleep 0.25
done

TOKEN="$(cat "$DATA_DIR/token.txt" 2>/dev/null || true)"
if [[ -z "$TOKEN" ]]; then
  die "El servicio arrancó pero no hay token en $DATA_DIR/token.txt (mira: journalctl --user -u $SERVICE)"
fi
IP="$(ip -4 -o route get 1.1.1.1 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="src") print $(i+1)}' | head -1)"
IP="${IP:-127.0.0.1}"

STAGE_PATH="/stage"
CANVAS="1920x1080"
# El servidor manda: si alguien cambió la ruta o el lienzo por configuración,
# el enlace que imprimimos tiene que ser el de verdad.
SHARE_JSON="$(curl -fsS "http://127.0.0.1:$PORT/api/share?t=$TOKEN" 2>/dev/null || true)"
if [[ -n "$SHARE_JSON" ]]; then
  read -r SHARED_PATH SHARED_CANVAS <<<"$(printf '%s' "$SHARE_JSON" | "$NODE_BIN" -e '
    let raw = "";
    process.stdin.on("data", (chunk) => { raw += chunk; });
    process.stdin.on("end", () => {
      const data = JSON.parse(raw || "{}");
      process.stdout.write(`${data.stagePath || "/stage"} ${data.canvas || "1920x1080"}`);
    });
  ')"
  STAGE_PATH="${SHARED_PATH:-$STAGE_PATH}"
  CANVAS="${SHARED_CANVAS:-$CANVAS}"
fi
STAGE_URL="http://$IP:$PORT$STAGE_PATH?t=$TOKEN"

MANAGE_URL="http://$IP:$PORT/"

echo
ok "LuckyOBS instalado y funcionando"
printf '   Gestión:      %s\n' "$MANAGE_URL"
printf '   Para el OBS:  %s\n' "$STAGE_URL"
echo
if [[ -n "$NEW_PASSWORD" ]]; then
  info "Administrador listo. Guarda la clave, no se vuelve a mostrar:"
  printf '   usuario: %s\n   clave:   %s\n' "$ADMIN_USER" "$NEW_PASSWORD"
  echo
else
  info "El administrador '$ADMIN_USER' ya existía: su clave no se ha cambiado."
  echo
fi
info "En el OBS de tu amigo no hay que instalar nada:"
printf '   1. Fuentes ▸ + ▸ Navegador\n'
printf '   2. URL: %s\n' "$STAGE_URL"
printf '   3. CSS personalizado: vacío\n'
printf '   4. Ancho y alto: da igual, la fuente se ajusta sola\n'
echo
info "El enlace de OBS lleva el token dentro: es de solo lectura."

CONTROL_KEY="$(cat "$DATA_DIR/control.txt" 2>/dev/null || true)"
if [ -n "$CONTROL_KEY" ]; then
  echo
  info "Boton de Stream Deck (oculta todo lo que hay en pantalla y lo mutea):"
  printf '   Metodo:  GET\n'
  printf '   URL:     http://%s:%s/api/control/hidden?key=%s\n' "$IP" "$PORT" "$CONTROL_KEY"
  echo
  info "La misma direccion, con la cabecera X-D2O-Control: $CONTROL_KEY"
  info "Un POST en esa ruta con {\"hidden\": true|false} fija el estado en vez de alternarlo."
  echo
fi
info "Los usuarios entran en $MANAGE_URL con usuario y contraseña."
info "Para crear más cuentas: $PREFIX/server/cli-users.js add <usuario>"
info 'O desde la web, con la cuenta de administrador (botón "Gestionar usuarios").'
printf '   Servicio:  systemctl --user {status,restart,stop} %s\n' "$SERVICE"
printf '   Logs:     journalctl --user -u %s -f\n' "$SERVICE"
printf '   Datos:    %s\n' "$DATA_DIR"
echo
