# LuckyOBS — versión mejorada

**Este es el archivo que debes leer antes de instalar o subir el proyecto a GitHub.**

## ¿Qué cambia?

- **Acceso desde distintos dispositivos.** Los navegadores de Windows, Linux, macOS, Android e iPhone pueden entrar por el mismo dominio HTTPS. *La aplicación Node.js debe continuar ejecutándose en un servidor*: subir estos archivos a GitHub Pages **no** ejecuta el servidor.
- **Parte pública:** `/login` permite que los invitados vean la pantalla de acceso, sin ver la escena ni los controles.
- **Parte privada:** usuarios con cuenta entran en `/` y pueden usar la gestión según su rol (`admin` o `mod`).
- **OBS:** la fuente usa `/stage?t=...`, con token de **solo lectura**. No compartirlo públicamente. Un token de OBS ya no puede suscribirse al canal privado `/events`.
- **Seguridad:** el HTML/SVG subido se aísla para no heredar permisos de la sesión (puede afectar a HTML que dependa de acceder al mismo origen); las solicitudes de navegadores de otros sitios no pueden operar el directo; las sesiones cerradas dejan de poder utilizar su conexión de control; la cola privada de subidas no se expone a OBS.
- **Conexión:** se conservan los mecanismos existentes de reconexión WebSocket y consulta de respaldo al servidor.
- **Diagnóstico:** añadimos un comando para comprobar DNS, servidor, inicio de sesión y privacidad desde cualquier PC con Node.js.
- **Privacidad del repositorio:** el ZIP nuevo NO contiene `data/` (cuentas, archivos y tokens) ni `node_modules/`. Incluye `.gitignore` para prevenir subidas accidentales.

## 1. Comprobar el enlace actual

En cualquier ordenador con Node.js 18+ (recomendado 22 LTS):

```bash
npm install
npm run diagnostico -- https://luckyobs.w4rfin.com
```

Si aparece `FALLO DNS`, revisar el registro A/CNAME del subdominio **luckyobs** en el panel DNS y los posibles registros AAAA incorrectos. Si el DNS funciona pero `/healthz` falla, revisar si el servidor y el proxy web están ejecutándose. Si `/healthz` funciona y el login no, revisar los logs de la aplicación y del proxy. **Esta prueba no comprueba una transmisión de OBS en vivo**.

En Windows, ejecuta lo mismo desde PowerShell, dentro de la carpeta `drop2obs`.

## 2. Preparar el servidor sin perder datos

La carpeta `data/` antigua contiene la configuración privada y puede contener tus cuentas y medios. **Guárdala en privado; NO la publiques ni sustituyas la que está en el servidor.** Haz una copia de seguridad de la carpeta de datos real ANTES de desplegar, preferiblemente con el servicio detenido. En instalaciones habituales la ruta es:

```bash
~/.local/share/luckyobs-data
```

La ruta puede ser distinta si se usa `D2O_DATA_DIR`. La versión nueva conserva el formato existente del estado y de los usuarios.

Para instalar sobre un servidor Linux con systemd que ya tenga el código descomprimido:

```bash
cd drop2obs
chmod +x install.sh
./install.sh
```

En una instalación NUEVA puedes crear la cuenta de administrador con el instalador. En una existente no se restablecerá la contraseña ni se eliminarán cuentas. Para ver el servicio:

```bash
systemctl --user status luckyobs
journalctl --user -u luckyobs -n 70 --no-pager
curl -fsS http://127.0.0.1:8787/healthz
```

### Servidor en Oracle Cloud con Caddy

El proyecto ya incluye `preparar-nube.sh` para configurar HTTPS + proxy y `desplegar-nube.sh` para futuras versiones. La versión mejorada configura:

```ini
D2O_PUBLIC_URL=https://luckyobs.w4rfin.com
D2O_HOST=127.0.0.1
D2O_TRUST_PROXY=true
```

`D2O_HOST=127.0.0.1` es para un **servidor con Caddy en la misma máquina**: el público entra por HTTPS al puerto 443, no directamente al 8787. Si usas un Cloudflare Tunnel hacia otra máquina, las opciones concretas del túnel se configuran aparte; **no combines procedimientos sin revisar la infraestructura que ya existe**.

Para desplegar desde una máquina Linux/macOS con SSH y rsync, usando la instalación actual:

```bash
./desplegar-nube.sh usuario@IP_DE_TU_SERVIDOR luckyobs.w4rfin.com
```

**No ejecutes estos scripts a ciegas:** comprueba primero que ese es tu servidor, que tienes acceso SSH, respaldos y que el dominio apunta a esa máquina. El instalador de Caddy toca configuración del sistema. Si ya tienes un proxy HTTPS funcionando, conserva su configuración.

> Nota de firewall: el preparador añade reglas 80 y 443 pero ya no activa UFW automáticamente. Debes conservar abierto TU puerto de SSH antes de modificar reglas.

## 3. Entrar desde distintos dispositivos

**Administrador o moderador** (Windows, Linux, Mac o celular):

1. Abre `https://luckyobs.w4rfin.com/login`.
2. Introduce tu usuario y contraseña.
3. La aplicación abre el panel y se conecta por `wss://luckyobs.w4rfin.com/events`.
4. Si el panel se queda en «sin servidor», comprueba el registro de red de WebSockets (F12 en PC) y el proxy. No necesitas Linux en el equipo cliente.

**El streamer en OBS:**

1. Inicia sesión como admin en el panel y copia el enlace de «Enlace de OBS».
2. En OBS: **Fuentes → + → Navegador**; pega exactamente el enlace `/stage?t=...`.
3. Deja el CSS personalizado vacío.
4. Verifica que el panel detecta «Pantalla OBS» conectada.
5. Si cambiaste el token, actualiza el enlace de OBS en un momento sin emisión en curso.

El token de OBS es secreto aunque sea de solo lectura: permite ver lo que se está mostrando. Nunca lo coloques en GitHub, capturas públicas o mensajes abiertos.

## 4. ¿Quién puede ver qué?

| Persona | Puede abrir el login | Puede gestionar el panel | Puede ver la escena de OBS |
|---|---|---|---|
| Visitante sin cuenta | Sí | No | No, necesita token |
| Moderador (`mod`) | Sí | Sí, herramientas de moderación | Sí, si recibe un enlace o entra autenticado |
| Administrador (`admin`) | Sí | Sí, incluidas cuentas y claves de OBS | Sí |
| OBS con token de escenario | Sí | **No** | Sí, solo escena |

No es una web de transmisión de vídeo público tipo Twitch: la aplicación envía elementos visuales hacia una fuente de OBS, y los controles de edición se protegen con cuentas.

## 5. Subir el código a GitHub de forma segura

GitHub puede almacenar el repositorio **público o privado**, pero no aloja tu aplicación Node.js con sus WebSockets como servidor ejecutándose 24/7. El servicio real debe permanecer encendido en Oracle, otro VPS o una máquina propia accesible por HTTPS.

```bash
git init
git add .gitignore .env.example EMPEZAR-AQUI.md package.json package-lock.json \
  README.md COMO-INSTALAR-EN-ORACLE.md public server scripts systemd test \
  install.sh preparar-nube.sh desplegar-nube.sh
git status
git commit -m "LuckyOBS: seguridad y acceso HTTPS"
git branch -M main
git remote add origin https://github.com/TU-USUARIO/TU-REPOSITORIO.git
git push -u origin main
```

**Antes del `git push`** revisa `git status` y comprueba que NO figuran `data/auth.json`, `data/token.txt`, `data/control.txt`, `.env`, archivos `.pem` ni contraseñas. Si alguna credencial ya fue compartida o subida, cámbiala; borrar el archivo de la última versión no la elimina del historial de Git.

## 6. Lista de comprobación después del despliegue

- [ ] `https://luckyobs.w4rfin.com/healthz` responde con `"ok": true`.
- [ ] Desde otro PC y desde un móvil en datos móviles abre `/login`.
- [ ] Una cuenta de moderador entra y puede subir archivos.
- [ ] Un visitante sin cuenta no puede abrir `/` ni `/api/state`.
- [ ] Una cuenta admin puede abrir «Enlace de OBS».
- [ ] La fuente de navegador de OBS aparece conectada en el panel.
- [ ] Después de desconectar internet momentáneamente en un dispositivo de prueba, vuelve a conectar cuando recupera la red.
- [ ] Los archivos subidos antes del despliegue siguen en el servidor.
- [ ] El puerto 8787 no queda publicado directamente a internet en un servidor con Caddy.

## 7. Comandos útiles si alguien no puede entrar

En el servidor:

```bash
systemctl --user status luckyobs
journalctl --user -u luckyobs -n 80 --no-pager
curl -i http://127.0.0.1:8787/healthz
sudo systemctl status luckyobs-caddy
sudo journalctl -u luckyobs-caddy -n 80 --no-pager
```

Si desde el servidor responde localmente, pero desde afuera no, revisa DNS, certificado HTTPS, firewall, Caddy/túnel y los registros A/AAAA. Si solo fallan ciertos usuarios, revisa cuentas, contraseñas, cookies y si el navegador permite WebSockets. Si abre en Windows pero no en móvil, revisa el certificado TLS, datos móviles y compatibilidad del navegador.

## 8. Lo que no se puede verificar solo con el código fuente

Que `luckyobs.w4rfin.com` esté realmente apuntando al servidor correcto, que esté funcionando 24/7, que el firewall permita el tráfico, el estado real del SSL/TLS y que OBS esté recibiendo la fuente. **Eso requiere comprobar el despliegue en la máquina real**, no solo modificar el ZIP.
