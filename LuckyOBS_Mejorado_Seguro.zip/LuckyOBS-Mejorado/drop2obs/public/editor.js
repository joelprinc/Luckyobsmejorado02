/*
 * The editor: selection, dragging, resizing and rotating on the long screen,
 * with the guides and the cursor behaviour OBS has.
 *
 * It talks to the server through two channels on purpose:
 *   - a WebSocket "transform" frame while the pointer is down, so the stream
 *     follows the cursor live;
 *   - a PATCH when the gesture ends, which is what actually gets saved.
 */
import {
  boundsOf,
  centerObject,
  collectSnap,
  fitWidth,
  isInteractive,
  moveObject,
  resizeObject,
} from './geometry.js';

const DRAG_THRESHOLD = 3;
const HISTORY_LIMIT = 60;

export class Editor {
  constructor({ views, canvas, cut, api, live, onChange, onSelect, onHistory }) {
    this.views = views;
    // Mutated in place when the server canvas arrives, never replaced.
    this.canvas = canvas;
    // Where the emission ends, so the helpers can centre in the right half.
    this.cut = cut ?? canvas.height / 2;
    this.api = api;
    this.live = live ?? (() => {});
    this.onChange = onChange ?? (() => {});
    this.onSelect = onSelect ?? (() => {});
    this.onHistory = onHistory ?? (() => {});
    this.selected = [];
    /** The object whose embedded page is currently taking the pointer. */
    this.interactive = null;
    this.gesture = null;
    this.history = [];
    this.future = [];
    this.dragFiles = null;
  }

  /* ----------------------------- selection ----------------------------- */

  objectsOf(sceneId) {
    return this.views[sceneId]?.scene.objects ?? [];
  }

  isSelected(id) {
    return this.selected.includes(id);
  }

  select(id, { additive = false } = {}) {
    if (!id) {
      this.selected = [];
      // Nothing selected means nothing to interact with, so a page left in use
      // goes back to being a picture of a page.
      this.interactive = null;
    } else if (additive) {
      this.selected = this.isSelected(id)
        ? this.selected.filter((x) => x !== id)
        : [...this.selected, id];
    } else {
      this.selected = [id];
    }
    this.paintSelection();
    this.onSelect(this.selectionDetails());
  }

  toggleSelect(id) {
    this.select(id, { additive: true });
  }

  clearSelection() {
    this.select(null);
  }

  selectionDetails() {
    const list = this.selected
      .map((id) => this.find(id))
      .filter(Boolean);
    const first = list[0];
    return {
      count: list.length,
      ids: [...this.selected],
      object: first ?? null,
      mixed: list.length > 1,
    };
  }

  find(id) {
    for (const sceneId of Object.keys(this.views)) {
      const found = (this.views[sceneId].scene.objects ?? []).find((o) => o.id === id);
      if (found) return found;
    }
    return null;
  }

  sceneOf(id) {
    for (const sceneId of Object.keys(this.views)) {
      if ((this.views[sceneId].scene.objects ?? []).some((o) => o.id === id)) return sceneId;
    }
    return null;
  }

  paintSelection() {
    for (const sceneId of Object.keys(this.views)) {
      const view = this.views[sceneId];
      for (const node of view.nodes.values()) {
        node.classList.toggle('selected', this.isSelected(node.dataset.id));
      }
    }
    this.paintInteractive();
  }

  paintInteractive() {
    for (const sceneId of Object.keys(this.views)) {
      for (const node of this.views[sceneId].nodes.values()) {
        node.classList.toggle('interactive', node.dataset.id === this.interactive);
      }
    }
  }

  /**
   * Hands the pointer to an embedded page, or takes it back when the same object
   * asks again. The object stays selected on purpose, so the toolbar keeps
   * working on it while its page is the one being clicked.
   */
  toggleInteractive(id) {
    const object = this.find(id);
    if (!object || !isInteractive(object)) return false;
    this.interactive = this.interactive === id ? null : id;
    this.paintInteractive();
    this.onSelect(this.selectionDetails());
    return true;
  }

  isInteractive(id) {
    return this.interactive === id;
  }

  /* ------------------------------ history ------------------------------ */

  /** Records the state of one object before a gesture so Ctrl+Z can restore it. */
  remember(object) {
    if (!object) return;
    const snapshot = {
      id: object.id,
      x: object.x, y: object.y, w: object.w, h: object.h,
      rot: object.rot, opacity: object.opacity, z: object.z,
      visible: object.visible, locked: object.locked, scene: object.scene,
    };
    const last = this.history[this.history.length - 1];
    if (last && last.id === snapshot.id && JSON.stringify(last) === JSON.stringify(snapshot)) return;
    this.history.push(snapshot);
    if (this.history.length > HISTORY_LIMIT) this.history.shift();
    this.future.length = 0;
    this.onHistory(this.canUndo());
  }

  canUndo() {
    return this.history.length > 0;
  }

  async undo() {
    const last = this.history.pop();
    if (!last) return;
    const current = this.find(last.id);
    if (current) {
      this.future.push({
        id: current.id,
        x: current.x, y: current.y, w: current.w, h: current.h,
        rot: current.rot, opacity: current.opacity, z: current.z,
        visible: current.visible, locked: current.locked, scene: current.scene,
      });
    }
    await this.commit(last);
    this.onHistory(this.canUndo());
  }

  async redo() {
    const next = this.future.pop();
    if (!next) return;
    const current = this.find(next.id);
    if (current) this.history.push({ ...next });
    await this.commit(next);
    this.onHistory(this.canUndo());
  }

  /** Sends a partial change and lets the server answer with the truth. */
  async commit(patch) {
    const body = { ...patch };
    delete body.id;
    const res = await this.api(`/api/objects/${patch.id}`, {
      method: 'PATCH',
      body,
    });
    return res?.object ?? null;
  }

  /* ------------------------------ gestures ----------------------------- */

  /**
   * Starts a gesture. `mode` is move, a handle name, or rotate. Nothing is sent
   * to the server yet: the pointer may still turn out to be a plain click.
   */
  begin(sceneId, objectId, mode, event) {
    const view = this.views[sceneId];
    const object = this.find(objectId);
    if (!view || !object) return null;
    if (object.locked && mode !== 'select') return null;
    // Grabbing the object takes it back from its page: moving it and clicking
    // inside it cannot both be true at once.
    if (this.interactive === objectId) {
      this.interactive = null;
      this.paintInteractive();
    }
    const start = boundsOf(object);
    this.gesture = {
      sceneId,
      mode,
      objectId,
      startObject: { ...object },
      start,
      origin: view.toScene(event.clientX, event.clientY),
      moved: false,
      pointerId: event.pointerId,
    };
    if (mode === 'move') this.remember(object);
    return this.gesture;
  }

  /** Called on every pointer move while a gesture is live. */
  drag(event) {
    const gesture = this.gesture;
    if (!gesture) return null;
    const view = this.views[gesture.sceneId];
    const point = view.toScene(event.clientX, event.clientY);
    const dx = point.x - gesture.origin.x;
    const dy = point.y - gesture.origin.y;
    if (!gesture.moved && Math.hypot(dx, dy) < DRAG_THRESHOLD) return null;
    gesture.moved = true;

    const object = this.find(gesture.objectId);
    if (!object) return null;
    const others = this.objectsOf(gesture.sceneId).filter((o) => o.id !== object.id);
    const guides = { x: null, y: null };
    let next = { ...object };

    if (gesture.mode === 'move') {
      // The offset grabbed on pointer down is what has to survive: the target
      // is the position the object had when the gesture started, plus how far
      // the pointer has travelled since. Measuring against the live object
      // instead would re-anchor the object by its corner, and comparing the two
      // for equality to decide that is unreliable, because the server rounds
      // the committed position and the local model keeps the decimals.
      const moved = moveObject(object, {
        dx: gesture.startObject.x + dx - object.x,
        dy: gesture.startObject.y + dy - object.y,
        others,
        canvas: this.canvas,
        // Holding the modifier drops the object exactly where the pointer is,
        // for the times when a precise pixel matters more than a tidy edge.
        snap: !(event.ctrlKey || event.metaKey),
        guides,
      });
      next.x = moved.x;
      next.y = moved.y;
    } else if (gesture.mode === 'rotate') {
      const cx = gesture.start.x + gesture.start.w / 2;
      const cy = gesture.start.y + gesture.start.h / 2;
      let angle = (Math.atan2(point.y - cy, point.x - cx) * 180) / Math.PI + 90;
      if (event.shiftKey) angle = Math.round(angle / 15) * 15;
      next.rot = Math.round(angle * 100) / 100;
    } else {
      // A photo or a video keeps its shape while it is resized, because a 16:9
      // clip that goes square looks like a mistake. A text does the opposite: its
      // box is not a picture, it is how much room the words have, and making a
      // caption taller without touching its width is the whole point. So for a
      // label the ratio is free by default and the modifier locks it, which is
      // the other way round from a picture on purpose.
      const modifier = event.ctrlKey || event.metaKey;
      const resized = resizeObject(object, gesture.mode, point, gesture.start, {
        aspect: (object.render || object.kind) === 'text' ? modifier : !modifier,
        fromCenter: event.altKey,
        canvas: this.canvas,
      });
      const snapped = collectSnap(
        { x: resized.x, y: resized.y, w: resized.w, h: resized.h },
        others,
        this.canvas,
      );
      next = {
        ...next,
        x: resized.x + snapped.dx,
        y: resized.y + snapped.dy,
        w: resized.w,
        h: resized.h,
      };
      guides.x = snapped.guideX;
      guides.y = snapped.guideY;
    }

    this.paintGuides(gesture.sceneId, guides);
    // Optimistic local paint, then the same numbers go to the stream.
    Object.assign(object, next);
    view.patch(object);
    this.live(object);
    this.onChange(object, { live: true });
    return object;
  }

  paintGuides(sceneId, guides) {
    const layer = this.views[sceneId]?.options.guides;
    if (!layer) return;
    const lines = [];
    if (guides.x !== null && guides.x !== undefined) {
      lines.push({ axis: 'x', at: guides.x });
    }
    if (guides.y !== null && guides.y !== undefined) {
      lines.push({ axis: 'y', at: guides.y });
    }
    layer.textContent = '';
    for (const line of lines) {
      const el = document.createElement('span');
      el.className = `guide guide-${line.axis}`;
      if (line.axis === 'x') el.style.left = `${line.at}px`;
      else el.style.top = `${line.at}px`;
      layer.appendChild(el);
    }
    layer.hidden = lines.length === 0;
  }

  clearGuides(sceneId) {
    const layer = this.views[sceneId]?.options.guides;
    if (!layer) return;
    layer.hidden = true;
    layer.textContent = '';
  }

  /**
   * Ends a gesture. Moving an object across the cut is just a matter of its y,
   * so there is nothing extra to do here: what it lands on decides whether it
   * goes out or stays in the bank.
   */
  async end() {
    const gesture = this.gesture;
    this.gesture = null;
    if (!gesture) return null;
    this.clearGuides(gesture.sceneId);
    const object = this.find(gesture.objectId);
    if (!object) return null;

    const saved = await this.commit(object);
    if (saved) {
      Object.assign(object, saved);
      this.views[object.scene].patch(object);
    }
    this.onChange(object, { live: false, moved: gesture.moved, from: gesture.sceneId });
    return object;
  }

  cancel() {
    const gesture = this.gesture;
    this.gesture = null;
    if (!gesture) return;
    this.clearGuides(gesture.sceneId);
    const object = this.find(gesture.objectId);
    if (!object) return;
    Object.assign(object, gesture.startObject);
    this.views[object.scene].patch(object);
    this.onChange(object, { live: false });
  }

  /* ------------------------------- actions ----------------------------- */

  async patchSelected(patch) {
    const done = [];
    for (const id of this.selected) {
      const object = this.find(id);
      if (!object) continue;
      this.remember(object);
      // Only the keys the caller touched go on the wire, and the server merges
      // them. Sending the whole object meant a second toolbar edit, typed before
      // the first answer came back, carried a stale copy of the field the user
      // had just changed and quietly undid it.
      const saved = await this.commit({ ...patch, id });
      if (saved) {
        Object.assign(object, saved);
        this.views[object.scene].patch(object);
        done.push(object);
      }
    }
    if (done.length) this.onChange(done[done.length - 1], { live: false });
    return done;
  }

  async reorder(direction) {
    for (const id of [...this.selected]) {
      const object = this.find(id);
      if (!object) continue;
      this.remember(object);
      const res = await this.api(`/api/objects/${id}/order`, {
        method: 'POST',
        body: { direction },
      });
      if (res?.objects) {
        for (const updated of res.objects) {
          const local = this.find(updated.id);
          if (local) Object.assign(local, updated);
        }
        this.onChange(null, { live: false, reorder: object.scene, objects: res.objects });
      }
    }
  }

  async duplicate() {
    const made = [];
    for (const id of [...this.selected]) {
      const res = await this.api(`/api/objects/${id}/duplicate`, { method: 'POST' });
      if (res?.object) {
        made.push(res.object);
        this.onChange(res.object, { live: false, added: true });
      }
    }
    if (made.length) this.select(made[made.length - 1].id);
    return made;
  }

  async remove() {
    const gone = [];
    for (const id of [...this.selected]) {
      const object = this.find(id);
      const res = await this.api(`/api/objects/${id}`, { method: 'DELETE' });
      if (res?.ok) {
        gone.push(id);
        this.onChange(object, { live: false, removed: true });
      }
    }
    this.selected = this.selected.filter((id) => !gone.includes(id));
    this.paintSelection();
    this.onSelect(this.selectionDetails());
    return gone;
  }

  async toggleLock() {
    const object = this.find(this.selected[0]);
    if (!object) return;
    await this.patchSelected({ locked: !object.locked });
  }

  async toggleVisible() {
    const object = this.find(this.selected[0]);
    if (!object) return;
    await this.patchSelected({ visible: object.visible === false });
  }

  async center() {
    const object = this.find(this.selected[0]);
    if (!object) return;
    await this.patchSelected(centerObject(object, this.canvas, this.cut));
  }

  async fit() {
    const object = this.find(this.selected[0]);
    if (!object) return;
    const size = fitWidth(object, this.canvas);
    await this.patchSelected({
      ...size,
      ...centerObject({ w: size.w, h: size.h, y: object.y, h: size.h }, this.canvas, this.cut),
    });
  }

  /** Arrow keys nudge, the way every canvas tool does. */
  async nudge(dx, dy) {
    const list = this.selected
      .map((id) => this.find(id))
      .filter((o) => o && !o.locked);
    if (!list.length) return;
    for (const object of list) this.remember(object);
    const moved = [];
    for (const object of list) {
      const saved = await this.commit({ ...object, x: object.x + dx, y: object.y + dy });
      if (saved) {
        Object.assign(object, saved);
        this.views[object.scene].patch(object);
        moved.push(object);
      }
    }
    if (moved.length) this.onChange(moved[moved.length - 1], { live: false });
  }
}
