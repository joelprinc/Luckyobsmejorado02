/*
 * Control page for the long screen.
 *
 * One panel, twice the height of the stream: the emitted canvas on top and the
 * bank right underneath it at the same size. Where an object sits on that panel
 * is what decides whether it goes out, so a file dropped from the desktop lands
 * in the bank and is dragged up across the cut to go live.
 *
 * The panel is drawn by scene.js, the same renderer the OBS browser source uses,
 * so the stream can never disagree with what is on screen here.
 */
import { Editor } from './editor.js';

const el = (id) => document.getElementById(id);

const ui = {
  layout: document.querySelector('.layout'),
  blockProgram: el('blockProgram'),
  frameProgram: el('frameProgram'),
  sceneProgram: el('sceneProgram'),
  guidesProgram: el('guidesProgram'),
  airLine: document.querySelector('.air-line'),
  dropHint: el('dropHint'),
  fileInput: el('fileInput'),
  overlay: el('dragOverlay'),
  dragClose: el('dragClose'),
  objectBar: el('objectBar'),
  obName: el('obName'),
  addText: el('addText'),
  obTextRow: el('obTextRow'),
  obText: el('obText'),
  obTextFont: el('obTextFont'),
  obTextSize: el('obTextSize'),
  obTextColor: el('obTextColor'),
  obSeekRow: el('obSeekRow'),
  obSeek: el('obSeek'),
  obSeekTime: el('obSeekTime'),
  obSeekTotal: el('obSeekTotal'),
  obVolumeRow: el('obVolumeRow'),
  obVolume: el('obVolume'),
  obVolumeValue: el('obVolumeValue'),
  obLoop: el('obLoop'),
  obReplay: el('obReplay'),
  hideToggle: el('hideToggle'),
  hideToggleText: el('hideToggleText'),
  listenToggle: el('listenToggle'),
  listenToggleText: el('listenToggleText'),
  controlUrl: el('controlUrl'),
  objectCount: el('objectCount'),
  airList: el('airList'),
  airHint: el('airHint'),
  bankList: el('bankList'),
  bankHint: el('bankHint'),
  modList: el('modList'),
  modHint: el('modHint'),
  onlineCount: el('onlineCount'),
  historyList: el('historyList'),
  historyHint: el('historyHint'),
  clearHistory: el('clearHistory'),
  obDelete: el('obDelete'),
  openShare: el('openShare'),
  shareDialog: el('shareDialog'),
  stageSolid: el('stageSolid'),
  stageDot: el('stageDot'),
  stageText: el('stageText'),
  stageUrl: el('stageUrl'),
  copyStage: el('copyStage'),
  toasts: el('toasts'),
  userButton: el('userButton'),
  userName: el('userName'),
  userPanel: el('userPanel'),
  userFullName: el('userFullName'),
  userRole: el('userRole'),
  userSince: el('userSince'),
  changePassword: el('changePassword'),
  logout: el('logout'),
  passwordDialog: el('passwordDialog'),
  passwordForm: el('passwordForm'),
  passCurrent: el('passCurrent'),
  passNext: el('passNext'),
  passAgain: el('passAgain'),
  passError: el('passError'),
  usersDialog: el('usersDialog'),
  usersForm: el('usersForm'),
  usersList: el('usersList'),
  usersError: el('usersError'),
  openUsers: el('openUsers'),
  newUsername: el('newUsername'),
  newPassword: el('newPassword'),
  newRole: el('newRole'),
};

const state = {
  scenes: { program: { objects: [] } },
  // The long screen: emission on top, bank underneath. `cut` is the y where
  // the emission ends, which is the only thing that decides what goes out.
  canvas: { width: 1920, height: 2160 },
  cut: 1080,
  agents: [],
  moderators: [],
  history: [],
  share: null,
  me: null,
  users: [],
  tokenFallback: false,
  rev: -1,
  views: {},
  editor: null,
  uploading: 0,
  /** Whether the show is off the air right now. Mirrors the server switch. */
  hidden: false,
  /** The typefaces the server accepts, for the text picker. */
  fonts: [],
  /**
   * Whether this page makes noise. It is only ever true while somebody has
   * pressed the button, and it is never saved: a panel that starts making noise
   * on its own would be a nasty surprise in the middle of a stream.
   */
  listen: false,
};

function toast(message, kind = '') {
  const node = document.createElement('div');
  node.className = `toast ${kind}`.trim();
  node.textContent = message;
  ui.toasts.append(node);
  setTimeout(() => {
    node.style.opacity = '0';
    node.style.transition = 'opacity .25s';
    setTimeout(() => node.remove(), 300);
  }, 3600);
}

async function api(path, options = {}) {
  const isForm = options.body instanceof FormData;
  const init = { ...options };
  // A plain object has to be stringified here: fetch would otherwise send
  // "[object Object]" and the server would reject it as broken json.
  if (options.body && !isForm && typeof options.body !== 'string') {
    init.body = JSON.stringify(options.body);
  }
  const res = await fetch(path, {
    ...init,
    headers: {
      ...(options.body && !isForm ? { 'content-type': 'application/json' } : {}),
      ...(init.headers ?? {}),
    },
  });
  if (res.status === 401) {
    location.replace(`/login?next=${encodeURIComponent(location.pathname + location.search)}`);
    throw new Error('unauthorized');
  }
  if (res.status === 403) {
    const data = await res.clone().json().catch(() => ({}));
    toast(data.message ?? 'No tienes permiso para eso.', 'err');
    throw new Error(data.error ?? 'forbidden');
  }
  const text = await res.text();
  const data = text ? JSON.parse(text) : {};
  if (!res.ok) throw new Error(data.error ?? `HTTP ${res.status}`);
  return data;
}

/* ------------------------------- screens ------------------------------- */

function makeView(sceneId, frame, sceneRoot, guides) {
  const view = new SceneView(sceneRoot, { interactive: true, origin: location.origin });
  // The editor needs the frame to know which screen a pointer is over.
  view.frame = frame;
  view.options.guides = guides;
  return view;
}

/**
 * Puts the long screen in the frame at the right size. The frame keeps the
 * aspect ratio of the whole screen, so the cut line always lands halfway down
 * it no matter how the window is shaped, and the scene box is always the real
 * canvas: the frame only scales it, so the panel and the stream agree on every
 * coordinate.
 */
function fitScenes() {
  for (const [sceneId, view] of Object.entries(state.views)) {
    view.root.style.width = `${state.canvas.width}px`;
    view.root.style.height = `${state.canvas.height}px`;
    // The text and failed-media boxes are sized off the scene, so the panel and
    // the OBS source draw them identically. The value has to be a real style
    // property because calc() cannot read the inline width from a variable.
    view.root.style.setProperty('--scene-h', `${state.canvas.height}px`);
    view.frame.style.setProperty('--canvas-ratio', `${state.canvas.width} / ${state.canvas.height}`);
    const box = view.frame.getBoundingClientRect();
    const scale = box.width > 0 ? box.width / state.canvas.width : 1;
    view.root.style.transform = `scale(${scale})`;
    view.root.style.transformOrigin = '0 0';
    view.root.style.left = '0px';
    view.root.style.top = '0px';
    view.measure();
  }
}

function applyWorkspace(data, { keepEditor = false } = {}) {
  if (typeof data?.rev === 'number') state.rev = data.rev;
  if (data?.cut > 0) {
    state.cut = data.cut;
    // The editor centres objects inside a half, so it needs the same cut.
    if (state.editor) state.editor.cut = data.cut;
  }
  if (data?.config?.screen) {
    const [w, h] = String(data.config.screen).split('x').map(Number);
    // Mutated, not replaced: the editor keeps a reference to this object, so a
    // new literal here would leave it snapping to the old canvas for good.
    if (w > 0 && h > 0) {
      state.canvas.width = w;
      state.canvas.height = h;
    }
  } else if (data?.config?.canvas) {
    const [w, h] = String(data.config.canvas).split('x').map(Number);
    if (w > 0 && h > 0) {
      state.canvas.width = w;
      state.canvas.height = h * 2;
      state.cut = h;
    }
  }
  if (data?.scenes?.program) state.scenes.program = data.scenes.program;
  if (Array.isArray(data?.agents)) state.agents = data.agents;
  if (Array.isArray(data?.fonts)) {
    state.fonts = data.fonts;
    renderFontPicker();
  }
  if (typeof data?.hidden === 'boolean' && data.hidden !== state.hidden) {
    state.hidden = data.hidden;
    renderHidden();
  }
  fitScenes();
  for (const [sceneId, view] of Object.entries(state.views)) {
    view.render(state.scenes[sceneId]);
  }
  if (!keepEditor) state.editor?.paintSelection();
  renderStatus();
  renderBankHint();
  if (state.editor) renderObjectList();
  // Somebody else's clip control also shows up here, so the bar is never a step
  // behind what is on air.
  if (state.editor) renderToolbar(state.editor.selectionDetails());
}

/* ------------------------------ side column ----------------------------- */

function whenLabel(iso) {
  if (!iso) return 'nunca';
  const at = Date.parse(iso);
  if (!Number.isFinite(at)) return 'nunca';
  const secs = Math.max(0, Math.round((Date.now() - at) / 1000));
  if (secs < 45) return 'ahora';
  if (secs < 3600) return `hace ${Math.round(secs / 60)} min`;
  if (secs < 86400) return `hace ${Math.round(secs / 3600)} h`;
  return `hace ${Math.round(secs / 86400)} d`;
}

function renderMods() {
  const list = state.moderators ?? [];
  const online = list.filter((m) => m.connected);
  if (ui.onlineCount) ui.onlineCount.textContent = String(online.length);
  if (ui.modList) {
    ui.modList.textContent = '';
    for (const person of list) {
      const li = document.createElement('li');
      li.classList = person.connected ? 'on' : '';
      const dot = document.createElement('span');
      dot.className = 'dot';
      const who = document.createElement('span');
      who.className = 'who';
      who.textContent = person.username;
      const role = document.createElement('span');
      role.className = 'role';
      role.textContent = person.role === 'admin' ? 'admin' : 'mod';
      const when = document.createElement('span');
      when.className = 'when';
      when.textContent = person.connected ? 'en línea' : whenLabel(person.lastSeen);
      li.append(dot, who, role, when);
      ui.modList.append(li);
    }
  }
  if (ui.modHint) {
    // Solo aparece cuando la lista esta vacia de verdad: con moderadores pero
    // ninguno en linea, la lista ya lo dice cada uno con su ultima vez.
    ui.modHint.hidden = list.length > 0;
    ui.modHint.textContent = 'Nadie tiene una sesión abierta todavía.';
  }
}

/**
 * Los clips cuyo final hay que vigilar, para que aparezca el boton de
 * reproducir. Uno por objeto y con su elemento a mano: si la escena vuelve a
 * dibujar el clip, el vigilante se vuelve a enganchar al nuevo.
 */
const clipEndings = new Map();

function watchClipEndings() {
  const objects = state.scenes.program?.objects ?? [];
  for (const object of objects) {
    const video = state.views.program?.nodeFor(object.id)?.querySelector?.('video');
    if (!video) continue;
    const watched = clipEndings.get(object.id);
    if (watched?.video === video) continue;
    watched?.video.removeEventListener('ended', watched.onEnded);
    const onEnded = () => {
      renderToolbar(state.editor.selectionDetails());
      renderObjectList();
    };
    video.addEventListener('ended', onEnded);
    clipEndings.set(object.id, { video, onEnded });
  }
  // Un objeto borrado no necesita seguir vigilado.
  for (const [id, watched] of clipEndings) {
    if (objects.some((o) => o.id === id)) continue;
    watched.video.removeEventListener('ended', watched.onEnded);
    clipEndings.delete(id);
  }
}

/**
 * Lo que hay en la pantalla ahora mismo, con los mismos botones que la barra
 * del objeto: sonido, bucle, reproducir y borrar. Cada boton hace lo mismo que
 * el suyo, asi que no hay dos caminos para la misma cosa.
 */
let objectListKey = '';

function renderObjectList() {
  const all = state.scenes.program?.objects ?? [];
  const air = [];
  const bank = [];
  for (const object of all) {
    // Un objeto que cruza la linea tiene un trozo en directo: cuenta como
    // directo, que es lo que se ve.
    (object.y < state.cut ? air : bank).push(object);
  }

  /*
   * La barra de objeto se repinta en cada paso de un arrastre, y la lista solo
   * depende de el nombre, de los botones y de que mitad esta el objeto. Con esa
   * firma delante no se reconstruye el HTML mientras se mueve algo, que era
   * hacerlo sesenta veces por segundo y perder el raton de encima de un boton.
   */
  const view = state.views.program;
  const key = [
    ...air.map((o) => `a${o.id}:${o.name}:${volumePercent(o)}:${o.loop !== false}:${view?.clipEnded(o.id) ? 1 : 0}`),
    ...bank.map((o) => `b${o.id}:${o.name}:${volumePercent(o)}:${o.loop !== false}:${view?.clipEnded(o.id) ? 1 : 0}`),
    (state.editor?.selected ?? []).join(','),
  ].join('|');
  if (key === objectListKey) return;
  objectListKey = key;

  if (ui.objectCount) ui.objectCount.textContent = String(all.length);

  const clip = object => object.render === 'video' || object.render === 'media';

  /** Un boton de la fila. Sin classes vacias: classList las rechaza. */
  const make = (text, title, { on = false, kind = 'ghost' } = {}) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = `btn btn-${kind} btn-mini`;
    b.textContent = text;
    b.title = title;
    if (on) b.classList.add('on');
    return b;
  };

  const row = (object, live) => {
    const li = document.createElement('li');
    if (live) li.classList.add('on');
    if (state.editor?.isSelected(object.id)) li.classList.add('selected');

    const pick = document.createElement('button');
    pick.type = 'button';
    pick.className = 'pick';
    pick.textContent = object.name;
    pick.title = `${object.name} · x ${Math.round(object.x)} y ${Math.round(object.y)}`;
    pick.addEventListener('click', () => state.editor.select(object.id));
    li.appendChild(pick);

    if (clip(object)) {
      // The same slider as in the bar, small. It saves on release: one request
      // per row, not one per pixel of drag.
      const percent = volumePercent(object);
      const volume = document.createElement('input');
      volume.type = 'range';
      volume.className = 'mini-volume';
      volume.min = '0';
      volume.max = '100';
      volume.step = '1';
      volume.value = String(percent);
      volume.title = `Volumen en OBS: ${percent}%`;
      volume.setAttribute('aria-label', `Volumen de ${object.name}`);
      volume.addEventListener('change', () => {
        act(object, { volume: Number(volume.value) / 100 });
      });

      const looping = object.loop !== false;
      const loop = make(
        '🔁',
        looping ? 'Repitiendo en bucle' : 'Repetir en bucle',
        { on: looping },
      );
      loop.addEventListener('click', () => act(object, { loop: !looping }));

      // Un clip acabado no puede buclear: en su lugar, reproducirlo otra vez.
      if (view?.clipEnded(object.id)) {
        const replay = make('▶', 'Volver a reproducir desde el principio', { kind: 'primary' });
        replay.addEventListener('click', () => act(object, { replay: true }));
        li.appendChild(replay);
      } else {
        li.appendChild(loop);
      }
      li.appendChild(volume);
    }

    const del = make('✕', 'Borrar', { kind: 'danger' });
    del.addEventListener('click', () => {
      state.editor.select(object.id);
      state.editor.remove();
    });
    li.appendChild(del);
    return li;
  };

  for (const [list, items, hint, empty] of [
    [ui.airList, air, ui.airHint, 'No hay nada en directo.'],
    [ui.bankList, bank, ui.bankHint, 'El banco está vacío.'],
  ]) {
    if (!list) continue;
    list.textContent = '';
    for (const object of items) list.appendChild(row(object, list === ui.airList));
    if (hint) {
      hint.textContent = empty;
      hint.hidden = items.length > 0;
    }
  }
  watchClipEndings();
}

/** Aplica un cambio a un objeto concreto, sin pasar por la seleccion. */
async function act(object, patch) {
  state.editor.select(object.id);
  try {
    await state.editor.patchSelected(patch);
  } catch (err) {
    toast(err.message, 'err');
  }
  renderToolbar(state.editor.selectionDetails());
  renderObjectList();
}

const HISTORY_LABEL = {
  subido: 'subido',
  'en directo': 'en directo',
  'al banco': 'al banco',
  quitado: 'quitado',
  'banco vaciado': 'banco vacío',
  'pantalla vaciada': 'pantalla vacía',
};

function renderHistory() {
  const entries = state.history ?? [];
  if (ui.historyList) {
    ui.historyList.textContent = '';
    for (const entry of entries) {
      const li = document.createElement('li');
      li.className = entry.action === 'quitado' || entry.action.includes('vaciado') ? 'live' : 'bank';
      const what = document.createElement('span');
      what.className = 'what';
      what.textContent = HISTORY_LABEL[entry.action] ?? entry.action;
      const file = document.createElement('span');
      file.className = 'file';
      file.textContent = entry.name || entry.detail || '';
      const who = document.createElement('span');
      who.className = 'who';
      who.textContent = entry.who || '?';
      const when = document.createElement('span');
      when.className = 'when';
      when.title = entry.at;
      when.textContent = whenLabel(entry.at);
      li.append(what, file, who, when);
      li.title = `${entry.at} · ${entry.who || '?'}`;
      ui.historyList.append(li);
    }
  }
  if (ui.historyHint) {
    ui.historyHint.hidden = entries.length > 0;
    ui.historyHint.textContent = 'Todavía no ha pasado nada.';
  }
}

/** Emptying the trail is an administrator thing, not a moderator's. */
function renderHistoryAdmin() {
  if (!ui.clearHistory) return;
  ui.clearHistory.hidden = state.me?.role !== 'admin';
}

function bindHistory() {
  ui.clearHistory?.addEventListener('click', async () => {
    if (!confirm('¿Vaciar el historial? Se pierde lo que se ha subido y quitado.')) return;
    try {
      await api('/api/history', { method: 'DELETE' });
      state.history = [];
      renderHistory();
    } catch (err) {
      toast(err.message, 'err');
    }
  });
}

/** The drop hint only makes sense while the bank half is still empty. */
/**
 * The drop area never goes away: with something already in the bank it shrinks
 * to a single line, but it stays there and stays clickable, because a moderator
 * with a full bank still has to be able to add the next file. Before, the hint
 * disappeared and with it the only way to open the file picker without a mouse
 * drag.
 */
function renderBankHint() {
  if (!ui.dropHint) return;
  const full = bankObjects().length > 0;
  ui.dropHint.hidden = false;
  ui.dropHint.classList.toggle('compact', full);
  const [title, hint] = ui.dropHint.querySelectorAll('p');
  if (title && hint) {
    title.innerHTML = full
      ? '<b>Suelta aquí un archivo</b> o haz clic para elegir uno'
      : '<b>Suelta aquí un archivo</b> de tu ordenador y aparecerá en el banco.';
    hint.textContent = full
      ? 'Se suma a lo que ya hay en el banco.'
      : 'Arrástralo por encima de la línea para que salga en el stream.';
  }
}

/** Everything sitting in the lower half, which is what does not go out. */
function bankObjects() {
  const objects = state.scenes.program?.objects ?? [];
  return objects.filter((object) => object.y + object.h > state.cut);
}

function stageAgents() {
  return state.agents.filter((a) => a.online && (a.kind === 'stage' || !a.kind));
}

/*
 * How long ago the OBS source last said something, in seconds. The number is
 * counted here and not asked for, so it ticks on its own while the panel is
 * open: nobody has to move anything to find out that the source is stuck.
 */
const STAGE_STALE_S = 12;
const STAGE_GONE_S = 45;

/** Seconds since the newest of these moments, or null if nobody has one. */
function secondsSince(list, field) {
  const times = list
    .map((a) => Date.parse(a[field]))
    .filter((t) => Number.isFinite(t));
  if (!times.length) return null;
  return Math.max(0, Math.floor((Date.now() - Math.max(...times)) / 1000));
}

function stageSilenceSeconds() {
  return secondsSince(stageAgents(), 'seenAt');
}

function stageFrozenSeconds() {
  return secondsSince(stageAgents(), 'renderedAt');
}

const sayAge = (seconds) => `${seconds} s`;

function renderStatus() {
  // Off the air comes first: while the show is hidden there is nothing to see on
  // the screen whether or not anybody has it open, and saying "en directo" next to
  // a show that is not going out is exactly the mistake worth avoiding.
  if (state.hidden === true) {
    ui.stageDot.className = 'dot warn';
    ui.stageText.textContent = 'Pantalla no visible';
    ui.stageText.title = 'Todo está oculto: no se ve ni se oye nada en la fuente de OBS.';
    return;
  }
  const online = stageAgents();
  const size = online.map((a) => a.canvas).find(Boolean);
  const silence = stageSilenceSeconds();
  const frozen = stageFrozenSeconds();

  if (!online.length) {
    ui.stageDot.className = 'dot err';
    ui.stageText.textContent = 'OBS desconectado';
    ui.stageText.title = 'Nadie tiene abierta la fuente de navegador en OBS.';
    return;
  }
  if (silence !== null && silence >= STAGE_GONE_S) {
    ui.stageDot.className = 'dot err';
    ui.stageText.textContent = `OBS sin respuesta · hace ${sayAge(silence)}`;
    ui.stageText.title = `La fuente del navegador lleva ${sayAge(silence)} sin decir nada. Recárgala en OBS.`;
    return;
  }
  // It answers but it has not drawn anything: a frozen source, which is the one
  // that gets discovered halfway through a stream.
  if (frozen !== null && frozen >= STAGE_STALE_S) {
    ui.stageDot.className = 'dot warn';
    ui.stageText.textContent = `OBS congelado · hace ${sayAge(frozen)}`;
    ui.stageText.title = `La fuente responde pero no dibuja desde hace ${sayAge(frozen)}. Recárgala en OBS.`;
    return;
  }
  ui.stageDot.className = 'dot ok';
  const bits = ['OBS conectado'];
  if (size) bits.push(size);
  if (silence !== null) bits.push(`hace ${sayAge(silence)}`);
  ui.stageText.textContent = bits.join(' · ');
  ui.stageText.title = `${online.length} pantalla(s) abierta(s).`;
}

/* ------------------------------- toolbar ------------------------------- */

/** The page whose Esc is being listened for inside it, if any. */
let interactivePage = null;

/*
 * Once a page is in use the keyboard goes in with it: an Esc typed inside the
 * frame never reaches this document, and without a way back the moderator would
 * be stuck looking at a page instead of the panel. The frame is served by this
 * same server, so the key can be heard from out here; if it ever is not, the
 * toolbar button and clicking outside still let go of it.
 */
function watchInteractivePage(id) {
  if (interactivePage) {
    interactivePage.frame.removeEventListener('keydown', interactivePage.onKey, true);
    interactivePage = null;
  }
  if (!id) return;
  const node = state.views.program?.nodeFor(id);
  const frame = node?.querySelector('iframe');
  try {
    if (!frame?.contentWindow) return;
    const onKey = (event) => {
      if (event.key !== 'Escape') return;
      event.preventDefault();
      state.editor.toggleInteractive(id);
    };
    frame.contentWindow.addEventListener('keydown', onKey, true);
    interactivePage = { frame: frame.contentWindow, onKey };
  } catch {
    /* A frame from somewhere else: the toolbar button is the way out. */
  }
}

function renderToolbar(details) {
  watchInteractivePage(state.editor?.interactive ?? null);
  renderObjectList();
  const object = details?.object;
  ui.objectBar.hidden = !object;
  if (!object) return;
  ui.obName.textContent = details.count > 1 ? `${details.count} objetos` : object.name;
  renderClipButtons(object);
}

/**
 * The fonts the server is willing to draw. The list travels with the workspace
 * instead of being written here again, so adding a typeface is a one line change
 * on the server and the picker cannot offer something that would be refused.
 */
function renderFontPicker() {
  const select = ui.obTextFont;
  if (!select) return;
  const fonts = state.fonts ?? [];
  if (select.dataset.filled === String(fonts.length)) return;
  select.dataset.filled = String(fonts.length);
  select.textContent = '';
  for (const font of fonts) {
    const option = document.createElement('option');
    option.value = font.id;
    option.textContent = font.label;
    select.appendChild(option);
  }
}

const isText = object => (object?.render || '') === 'text';

const asClock = (seconds) => {
  const total = Math.max(0, Math.round(Number(seconds) || 0));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const pad = (n) => String(n).padStart(2, '0');
  return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
};

const isClip = object => object?.render === 'video' || object?.render === 'media';

/** How loud an object plays, 0 to 100. Zero is simply the quiet end of it. */
function volumePercent(object) {
  const value = Number(object?.volume);
  if (Number.isFinite(value)) return Math.round(Math.min(1, Math.max(0, value)) * 100);
  return object?.muted === true ? 0 : 100;
}

/**
 * The clip controls, and only those: a name and a way out are always there, so
 * these belong to a video. The volume is a slider because a clip at half is a
 * normal thing to want, and the replay only appears once the clip has run out,
 * which is the moment it is worth pressing.
 */
function renderClipButtons(object) {
  const clip = object.render === 'video' || object.render === 'media';
  const view = state.views.program;
  if (ui.obTextRow) ui.obTextRow.hidden = !isText(object);
  renderFontPicker();
  // The scrubber only makes sense for something with a length.
  if (ui.obSeekRow) ui.obSeekRow.hidden = !clip;
  if (clip) paintSeekBar();
  if (isText(object)) {
    if (ui.obText && document.activeElement !== ui.obText && ui.obText.dataset.dirty !== '1') {
      ui.obText.value = object.text ?? '';
    }
    if (ui.obTextFont) ui.obTextFont.value = object.textFont ?? 'arial';
    if (ui.obTextSize && document.activeElement !== ui.obTextSize) {
      ui.obTextSize.value = String(object.textSize ?? 96);
    }
    if (ui.obTextColor) ui.obTextColor.value = object.textColor ?? '#ffffff';
  }
  if (ui.obVolumeRow) ui.obVolumeRow.hidden = !clip;
  for (const button of [ui.obLoop, ui.obReplay]) {
    if (button) button.hidden = !clip;
  }
  if (!clip) return;

  const percent = volumePercent(object);
  if (ui.obVolume && document.activeElement !== ui.obVolume) ui.obVolume.value = String(percent);
  if (ui.obVolumeValue) ui.obVolumeValue.textContent = `${percent}%`;
  if (ui.obVolumeRow) {
    ui.obVolumeRow.classList.toggle('is-quiet', percent === 0);
    ui.obVolume?.setAttribute('aria-valuetext', `${percent}%`);
  }
  const looping = object.loop !== false;
  if (ui.obLoop) {
    ui.obLoop.classList.toggle('on', looping);
    ui.obLoop.title = looping ? 'Repitiendo en bucle' : 'Repetir en bucle';
  }
  // A clip that has ended is the only case where the loop button has nothing to
  // offer, and the replay takes its place.
  const ended = Boolean(view?.clipEnded(object.id));
  if (ui.obLoop) ui.obLoop.hidden = ended;
  if (ui.obReplay) ui.obReplay.hidden = !ended;
  watchClipEnd(object.id);
}

/**
 * Espera a que el clip se acabe para que salga el boton de reproducir, tanto en
 * la barra como en la lista. Ahora hay un solo vigilante para todos, asi que
 * esto solo tiene que repintar la barra del objeto seleccionado.
 */
function watchClipEnd() {
  renderObjectList();
}

/**
 * The bar only carries the clip controls and the way out, so this is small on
 * purpose: sound, loop and replay go through the object itself and land in the
 * OBS source with everything else.
 */
function bindToolbar() {
  const clip = (make) => async () => {
    const object = state.editor.selectionDetails().object;
    if (!object) return;
    try {
      await state.editor.patchSelected(make(object));
      // The button is repainted from what the server answered, so it shows the
      // state that was really saved and not the one that was pressed. Without
      // this the bar kept the old look until the object was selected again.
      renderToolbar(state.editor.selectionDetails());
    } catch (err) {
      toast(err.message, 'err');
    }
  };
  ui.obLoop?.addEventListener('click', clip((o) => ({ loop: o.loop === false })));
  ui.obReplay?.addEventListener('click', clip(() => ({ replay: true })));
  ui.obDelete?.addEventListener('click', () => state.editor.remove());
}

/**
 * Puts a text on the screen. It lands in the bank like a file that was dropped
 * without a point to drop it on, and it comes selected so the words can be typed
 * straight away.
 */
async function addText() {
  try {
    const res = await api('/api/objects', {
      method: 'POST',
      body: { scene: 'program', render: 'text', name: 'Texto', text: 'Hola' },
    });
    const object = res.object;
    if (!object) return;
    applyWorkspace(res, { keepEditor: true });
    // The server drops it in the bank, so there is nothing to move.
    state.editor.select(object.id);
    renderToolbar(state.editor.selectionDetails());
    ui.obText?.focus();
    ui.obText?.select();
    toast('Texto añadido al banco', 'ok');
  } catch (err) {
    toast(`No se pudo añadir el texto: ${err.message}`, 'err');
  }
}

/** The words and the look of a text, saved when the hand stops. */
let textTimer = null;
function queueTextPatch(patch) {
  if (textTimer) clearTimeout(textTimer);
  textTimer = setTimeout(async () => {
    textTimer = null;
    const object = state.editor.selectionDetails().object;
    if (!object || !isText(object)) return;
    try {
      await state.editor.patchSelected(patch);
      renderToolbar(state.editor.selectionDetails());
    } catch (err) {
      toast(err.message, 'err');
    }
  }, 250);
}

/*
 * The switch that takes the whole show off the air, and the sign that says it is
 * off. Hiding is not an edit: the objects stay where they are, so coming back is
 * the same show a moment later, which is what makes it safe to hit in the middle
 * of a stream.
 */
function renderHidden() {
  const off = state.hidden === true;
  if (ui.hideToggle) {
    ui.hideToggle.classList.toggle('is-on', off);
    ui.hideToggle.setAttribute('aria-pressed', off ? 'true' : 'false');
  }
  if (ui.hideToggleText) ui.hideToggleText.textContent = off ? 'Mostrar todo' : 'Ocultar todo';
  renderStatus();
}

async function setHidden(hidden) {
  try {
    const saved = await api('/api/hidden', { method: 'POST', body: { hidden: hidden === true } });
    if (typeof saved.hidden === 'boolean') state.hidden = saved.hidden;
    renderHidden();
    toast(state.hidden ? 'Todo oculto: no se ve ni se oye' : 'De vuelta en directo', 'ok');
  } catch (err) {
    toast(`No se pudo cambiar: ${err.message}`, 'err');
  }
}

async function toggleHidden() {
  await setHidden(!state.hidden);
}

/*
 * The button is only shown to an administrator, the same way the account manager
 * and the OBS link are: taking the whole show off the air is the owner's call, or
 * whoever is on the deck. renderMe() is what hides it from a moderator, and the
 * server turns them down anyway.
 */
/**
 * The sound of this page. The panel keeps every clip silent so a moderator does
 * not hear each thing twice, once here and once through OBS. This button turns
 * that off for whoever wants to hear what they are preparing, and it goes back
 * to silent as soon as it is pressed again.
 */
function renderListen() {
  const on = state.listen === true;
  if (ui.listenToggle) {
    ui.listenToggle.classList.toggle('is-on', on);
    ui.listenToggle.setAttribute('aria-pressed', on ? 'true' : 'false');
  }
  if (ui.listenToggleText) ui.listenToggleText.textContent = on ? 'Sonando' : 'Escuchar';
  // Only this page's own view: the OBS source is a different browser.
  state.views?.program?.setMuted(!on);
}

function bindListen() {
  ui.listenToggle?.addEventListener('click', () => {
    state.listen = !state.listen;
    renderListen();
    if (state.listen) toast('Esta página ya se oye: si el OBS también suena, lo oirás dos veces', 'warn');
  });
  renderListen();
}

function bindHidden() {
  ui.hideToggle?.addEventListener('click', toggleHidden);
  renderHidden();
}

function bindText() {
  ui.addText?.addEventListener('click', addText);
  ui.obText?.addEventListener('input', () => {
    ui.obText.dataset.dirty = '1';
    queueTextPatch({ text: ui.obText.value });
  });
  ui.obText?.addEventListener('blur', () => { ui.obText.dataset.dirty = '0'; });
  ui.obTextFont?.addEventListener('change', () => queueTextPatch({ textFont: ui.obTextFont.value }));
  ui.obTextSize?.addEventListener('input', () => queueTextPatch({ textSize: Number(ui.obTextSize.value) }));
  ui.obTextColor?.addEventListener('input', () => queueTextPatch({ textColor: ui.obTextColor.value }));
}

/*
 * The scrubber.
 *
 * The bar knows the length of the clip only once the browser has read the file,
 * so it fills in by itself when that happens and stays at zero until then. While
 * the hand is on it nothing else touches it: a bar that jumps under your finger
 * is worse than one that is a moment late, so the tick below skips it.
 */
function paintSeekBar() {
  const object = state.editor?.selectionDetails().object;
  if (!object || !isClip(object) || !ui.obSeek) return;
  const progress = state.views.program?.clipProgress(object.id);
  if (!progress || !progress.duration) {
    if (ui.obSeekTotal) ui.obSeekTotal.textContent = '0:00';
    return;
  }
  const dragging = ui.obSeek.dataset.dragging === '1';
  ui.obSeek.max = String(progress.duration);
  if (!dragging) {
    const at = Math.min(progress.duration, Math.max(0, progress.time));
    ui.obSeek.value = String(at);
    if (ui.obSeekTime) ui.obSeekTime.textContent = asClock(at);
  }
  if (ui.obSeekTotal) ui.obSeekTotal.textContent = asClock(progress.duration);
}

function seekSelected(seconds) {
  const object = state.editor?.selectionDetails().object;
  if (!object || !isClip(object)) return;
  state.editor.patchSelected({ seek: Math.max(0, Number(seconds) || 0) }).catch((err) => {
    toast(err.message, 'err');
  });
}

ui.obSeek?.addEventListener('input', () => {
  ui.obSeek.dataset.dragging = '1';
  ui.obSeekRow?.classList.add('is-seek');
  if (ui.obSeekTime) ui.obSeekTime.textContent = asClock(ui.obSeek.value);
});
ui.obSeek?.addEventListener('change', () => {
  delete ui.obSeek.dataset.dragging;
  ui.obSeekRow?.classList.remove('is-seek');
  seekSelected(Number(ui.obSeek.value));
});
// A click on the bar, without dragging it, is a jump to that point too.
ui.obSeek?.addEventListener('pointerup', () => {
  if (ui.obSeek?.dataset.dragging === '1') {
    delete ui.obSeek.dataset.dragging;
    ui.obSeekRow?.classList.remove('is-seek');
    seekSelected(Number(ui.obSeek.value));
  }
});

/**
 * The volume slider saves when the hand stops: a drag across the range would
 * otherwise be a hundred requests, and the OBS source only needs the value it
 * ends on. The number moves with the thumb straight away.
 */
let volumeTimer = null;
ui.obVolume?.addEventListener('input', () => {
  const percent = Number(ui.obVolume.value);
  if (ui.obVolumeValue) ui.obVolumeValue.textContent = `${percent}%`;
  ui.obVolumeRow?.classList.toggle('is-quiet', percent === 0);
  if (volumeTimer) clearTimeout(volumeTimer);
  volumeTimer = setTimeout(async () => {
    volumeTimer = null;
    const object = state.editor.selectionDetails().object;
    if (!object) return;
    try {
      await state.editor.patchSelected({ volume: percent / 100 });
      renderToolbar(state.editor.selectionDetails());
    } catch (err) {
      toast(err.message, 'err');
    }
  }, 250);
});

/* -------------------------------- upload ------------------------------- */

function setProgress(active, ratio, text) {
  state.uploading = active;
  let bar = el('uploadProgress');
  if (!bar) {
    bar = document.createElement('div');
    bar.id = 'uploadProgress';
    bar.className = 'progress';
    bar.innerHTML = '<div class="progress-bar"><div class="progress-fill"></div></div><span class="progress-text"></span>';
    document.body.append(bar);
  }
  bar.hidden = !active;
  bar.querySelector('.progress-fill').style.width = `${Math.max(0, Math.min(100, ratio * 100))}%`;
  bar.querySelector('.progress-text').textContent = text ?? '';
  if (!active) setTimeout(() => { bar.hidden = true; }, 900);
}

/**
 * Uploads the files a moderator dropped and puts each one on the screen it was
 * dropped on, at the spot it was dropped. That is the first half of the gesture:
 * the second half is dragging it up from the bank across the cut.
 */
async function uploadFiles(fileList, { at = null } = {}) {
  const files = [...fileList].filter((f) => f && f.size >= 0);
  if (!files.length) return;
  setProgress(true, 0, `subiendo ${files.length} archivo(s)…`);
  const body = new FormData();
  for (const file of files) body.append('files', file);
  try {
    const res = await fetch('/api/upload', { method: 'POST', body, credentials: 'same-origin' });
    if (res.status === 401) {
      location.replace(`/login?next=${encodeURIComponent(location.pathname + location.search)}`);
      return;
    }
    const data = await res.json();
    if (!res.ok) throw new Error(data.error ?? `HTTP ${res.status}`);
    const ids = (data.uploads ?? []).map((u) => u.id);
    if (!ids.length) return;
    // Stack them around the drop point so several files do not land on top of
    // each other in the exact same pixel.
    let offset = 0;
    for (const id of ids) {
      const place = await api('/api/scenes/program/place', {
        method: 'POST',
        body: {
          ids: [id],
          x: at ? at.x + offset : undefined,
          y: at ? at.y + offset : undefined,
        },
      });
      if (place?.workspace) applyWorkspace(place.workspace, { keepEditor: true });
      offset += 28;
    }
    // Say where it landed: dropping above the cut is going out live.
    toast(
      `${ids.length} archivo(s) en ${airText(at?.y)}`,
      'ok',
    );
  } catch (err) {
    toast(`No se pudo subir: ${err.message}`, 'err');
  } finally {
    setProgress(false, 1, '');
  }
}

/** Where a y lands on the long screen, in words: live or bank. */
function airText(y) {
  if (!Number.isFinite(y)) return 'el banco';
  return y < state.cut ? 'directo' : 'el banco';
}

/* ------------------------------ websocket ------------------------------ */

let ws = null;
let retry = 0;

/*
 * El estado del socket ya no se enseña en ningun sitio: si el moderador esta
 * viendo la pagina, esta funcionando. Aun asi se avisa por consola cuando algo
 * se rompe del todo, que es lo unico que no se puede deducir de mirar la
 * pantalla.
 */
function setWs(stateName, text) {
  if (stateName === 'err' || stateName === 'warn') console.warn(`[LuckyOBS] ${text}`);
}

/** While a gesture is running this streams the transform to the stream. */
function liveTransform(object) {
  if (!ws || ws.readyState !== 1) return;
  try {
    ws.send(JSON.stringify({
      type: 'transform',
      id: object.id,
      scene: object.scene,
      x: object.x, y: object.y, w: object.w, h: object.h, rot: object.rot,
    }));
  } catch {
    /* the commit on drop is the one that matters */
  }
}

function connectWs() {
  const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
  ws = new WebSocket(`${proto}//${location.host}/events`);

  ws.addEventListener('open', () => {
    retry = 0;
    setWs('ok', 'servidor conectado');
  });
  ws.addEventListener('message', (event) => {
    let msg;
    try {
      msg = JSON.parse(event.data);
    } catch {
      return;
    }
    if (msg.type === 'workspace') applyWorkspace(msg);
    else if (msg.type === 'state') {
      // The OBS payload: keep the program in sync even if a workspace frame
      // has not arrived yet.
      if (msg.program) {
        state.scenes.program = msg.program;
        fitScenes();
        state.views.program?.render(state.scenes.program);
        renderBankHint();
        renderObjectList();
      }
      if (Array.isArray(msg.agents)) {
        state.agents = msg.agents;
        renderStatus();
      }
    } else if (msg.type === 'transform') {
      // Somebody else is dragging: follow along without waiting for a save.
      const object = msg.object;
      if (object?.scene) state.views[object.scene]?.patch(object);
    } else if (msg.type === 'agents') {
      state.agents = msg.agents ?? [];
      renderStatus();
    } else if (typeof msg.hidden === 'boolean' && msg.hidden !== state.hidden) {
      // The deck or another moderator hit the switch: say so here too, so the
      // person managing the show is never the last to know.
      state.hidden = msg.hidden;
      renderHidden();
    } else if (msg.type === 'activity') {
      // Who is here and what has been done, in one frame.
      state.moderators = msg.moderators ?? [];
      state.history = msg.history ?? [];
      renderMods();
      renderHistory();
      renderHistoryAdmin();
    }
  });
  ws.addEventListener('close', () => {
    setWs('warn', 'reconectando…');
    retry += 1;
    setTimeout(connectWs, Math.min(8000, 500 * 2 ** Math.min(retry, 4)));
  });
  ws.addEventListener('error', () => setWs('err', 'error de socket'));
}

/* -------------------------------- events -------------------------------- */

let dragDepth = 0;
let dragFailsafe = 0;
let lastDragPoint = null;
/** After closing it by hand the overlay stays away a moment, so a drag stuck in
 *  the browser cannot reopen it on the very next dragenter. */
let dragCooldown = 0;

const carriesFiles = (event) => [...(event.dataTransfer?.types ?? [])].includes('Files');
const showDragOverlay = () => {
  dragDepth = 0;
  lastDragPoint = null;
  ui.overlay.hidden = false;
};
/** Always safe to call: the overlay must never survive a drag that ended. */
const hideDragOverlay = () => {
  clearTimeout(dragFailsafe);
  dragDepth = 0;
  lastDragPoint = null;
  ui.overlay.hidden = true;
};
/** Same, but the overlay ignores the next dragents: for the button and the
 *  stuck drag case. */
const dismissDragOverlay = () => {
  dragCooldown = Date.now() + 1500;
  hideDragOverlay();
};
/**
 * A drag in flight keeps firing dragover, so rearming on every one of them holds
 * the overlay up. If those events stop (dropped on another window, cancelled with
 * Esc, tab in the background) it closes itself instead of blurring the app for
 * good, which is what a stuck overlay feels like.
 *
 * Some setups keep sending dragover for a drag that is already dead (a window
 * left in a half dragging state, for example). The pointer not moving any more
 * gives that away: nobody holds a drag still for ten seconds.
 */
const keepDragOverlayAlive = (event) => {
  clearTimeout(dragFailsafe);
  const point = event && Number.isFinite(event.clientX) ? `${event.clientX},${event.clientY}` : null;
  if (point && point === lastDragPoint) {
    dragFailsafe = setTimeout(hideDragOverlay, 10000);
    return;
  }
  lastDragPoint = point;
  dragFailsafe = setTimeout(hideDragOverlay, 4000);
};

/*
 * Nothing is dragged out of the page. A browser lets you pick an image or a
 * frame and drag it into another tab, the way a page of images does, and here
 * that has no place: an object is moved with the pointer inside the panel, and
 * the file never leaves the show. Dropping a file *into* the page is untouched,
 * since that gesture never starts here.
 */
document.addEventListener('dragstart', (event) => {
  if (event.target.closest?.('.scene-object')) event.preventDefault();
});

window.addEventListener('dragenter', (event) => {
  if (!carriesFiles(event)) return;
  event.preventDefault();
  if (Date.now() < dragCooldown) return; // a dead drag must not bring it back
  dragDepth += 1;
  showDragOverlay();
  keepDragOverlayAlive(event);
});
window.addEventListener('dragover', (event) => {
  if (!carriesFiles(event)) return;
  event.preventDefault();
  event.dataTransfer.dropEffect = 'copy';
  keepDragOverlayAlive(event);
});
window.addEventListener('dragleave', (event) => {
  if (!carriesFiles(event)) return;
  dragDepth = Math.max(0, dragDepth - 1);
  if (dragDepth === 0) ui.overlay.hidden = true;
});
/*
 * A file arriving from the desktop lands on the long screen at the point it was
 * let go. There is one screen, so where it lands on it is what decides whether
 * it goes out or waits in the bank.
 */
window.addEventListener('drop', async (event) => {
  event.preventDefault();
  dragDepth = 0;
  dismissDragOverlay();
  const files = event.dataTransfer?.files;
  if (!files?.length) return;
  const view = state.views.program;
  const box = view?.frame?.getBoundingClientRect?.();
  if (!box || event.clientX < box.left || event.clientX > box.right
    || event.clientY < box.top || event.clientY > box.bottom) return;
  await uploadFiles(files, { at: view.toScene(event.clientX, event.clientY) });
});
/*
 * Ctrl+V with something on the clipboard is the same gesture as a drop, minus
 * the aim: there is no pointer to decide where it lands, so the file goes to
 * the bank, waiting to be dragged up across the cut like anything else.
 *
 * Only files are taken. A text paste is left to the browser, so the fields that
 * take text (the name of an object) keep working, and pasting plain text into
 * the page does nothing at all.
 */
function filesInClipboard(event) {
  const data = event.clipboardData;
  if (!data) return [];
  const fromFiles = [...(data.files ?? [])].filter(Boolean);
  if (fromFiles.length) return fromFiles;
  // A copied picture often arrives only as a kind:"file" item, next to the text
  // representation of the same thing, which is why the types have to be checked.
  return [...(data.items ?? [])]
    .filter((item) => item.kind === 'file' && item.type)
    .map((item) => item.getAsFile())
    .filter(Boolean);
}

window.addEventListener('paste', async (event) => {
  const target = event.target;
  if (target?.closest?.('input, textarea, [contenteditable=""], [contenteditable="true"]')) return;
  const files = filesInClipboard(event);
  if (!files.length) return;
  event.preventDefault();
  hideDragOverlay();
  await uploadFiles(files);
});
// Esc, or letting go of the file over another window: no drop, no leave.
window.addEventListener('dragend', hideDragOverlay);
window.addEventListener('blur', hideDragOverlay);
window.addEventListener('pointerdown', hideDragOverlay);
window.addEventListener('keydown', hideDragOverlay);
window.addEventListener('wheel', hideDragOverlay, { passive: true });
document.addEventListener('visibilitychange', () => {
  if (document.hidden) hideDragOverlay();
});
// Last resort: the overlay does not catch the pointer, so without this button a
// dead drag would leave no way out at all. The markup handler covers the case
// where this script never got to run.
ui.dragClose?.addEventListener('click', dismissDragOverlay);

/* --------------------------- pointer gestures --------------------------- */

function handleFrom(target) {
  const node = target.closest?.('[data-handle]');
  return node?.dataset.handle ?? null;
}

function bindScreenGestures(sceneId, frame) {
  const view = state.views[sceneId];
  let active = null;

  frame.addEventListener('pointerdown', (event) => {
    if (event.button !== 0) return;
    const handle = handleFrom(event.target);
    const node = event.target.closest?.('.scene-object');
    const objectId = node?.dataset.id;
    if (!objectId && !handle) {
      state.editor.clearSelection();
      return;
    }
    if (handle) {
      if (!state.editor.selected.length) return;
      state.editor.begin(sceneId, state.editor.selected[0], handle, event);
      active = { kind: 'gesture' };
    } else if (objectId) {
      if (!state.editor.isSelected(objectId)) {
        state.editor.select(objectId, { additive: event.shiftKey || event.ctrlKey || event.metaKey });
      } else if (event.shiftKey) {
        state.editor.toggleSelect(objectId);
      }
      state.editor.begin(sceneId, objectId, 'move', event);
      active = { kind: 'gesture' };
    } else {
      active = { kind: 'maybe' };
    }
    if (active.kind === 'gesture') frame.setPointerCapture?.(event.pointerId);
  });

  frame.addEventListener('pointermove', (event) => {
    if (!active) return;
    if (active.kind === 'gesture') state.editor.drag(event);
  });

  const finish = async (event) => {
    if (!active) return;
    const kind = active.kind;
    active = null;
    if (kind === 'gesture') await state.editor.end(event);
  };
  frame.addEventListener('pointerup', finish);
  frame.addEventListener('pointercancel', () => {
    if (active?.kind === 'gesture') state.editor.cancel();
    active = null;
  });

  /*
   * A double click belongs to what is under the cursor, not to the panel. On an
   * embedded page it hands the pointer over, so a click inside reaches the item
   * that is there; anywhere else it is left alone, the same as in a browser,
   * because picking the object up is what a single click is for. A second double
   * click, Esc, a click outside or dragging it takes the page back.
   */
  frame.addEventListener('dblclick', (event) => {
    /*
     * The object is found by position, not by walking up from event.target: the
     * drag captured the pointer on this frame, and a captured pointer rewrites
     * the target of the mouse events that follow, so the click would always look
     * like it had landed on the frame itself.
     */
    const view = state.views.program;
    const point = view.toScene(event.clientX, event.clientY);
    const object = view.objectAt(point.x, point.y);
    if (!object) return;
    state.editor.select(object.id);
    state.editor.toggleInteractive(object.id);
  });

  /*
   * A page that is in use swallows every click, so the editor has to be able to
   * take it back from outside the object too: a second click anywhere on the
   * panel, or the background, releases it.
   */
  frame.addEventListener('pointerdown', (event) => {
    if (!state.editor.interactive) return;
    if (event.target.closest?.('.scene-object')) return;
    state.editor.toggleInteractive(state.editor.interactive);
  }, true);
}

function bindKeyboard() {
  window.addEventListener('keydown', (event) => {
    if (event.target.matches('input, textarea, select')) return;
    const meta = event.ctrlKey || event.metaKey;
    if (meta && event.key.toLowerCase() === 'z') {
      event.preventDefault();
      if (event.shiftKey) state.editor.redo();
      else state.editor.undo();
      return;
    }
    if (meta && event.key.toLowerCase() === 'd') {
      event.preventDefault();
      state.editor.duplicate();
      return;
    }
    if (event.key === 'Delete' || event.key === 'Backspace') {
      if (!state.editor.selected.length) return;
      event.preventDefault();
      state.editor.remove();
      return;
    }
    if (event.key === 'Escape') {
      // An embedded page in use is let go of first, so a stray Esc never throws
      // away a selection that is still being worked on.
      if (state.editor.interactive) state.editor.toggleInteractive(state.editor.interactive);
      else state.editor.clearSelection();
      return;
    }
    if (meta && event.shiftKey && event.key.toLowerCase() === 'h') {
      // The same rule as the button: the switch is the owner's, or the deck's.
      if (!state.tokenFallback && state.me?.role !== 'admin') return;
      event.preventDefault();
      toggleHidden();
      return;
    }
    const step = event.shiftKey ? 10 : 1;
    const nudges = {
      ArrowLeft: [-step, 0],
      ArrowRight: [step, 0],
      ArrowUp: [0, -step],
      ArrowDown: [0, step],
    };
    const nudge = nudges[event.key];
    if (nudge && state.editor.selected.length) {
      event.preventDefault();
      state.editor.nudge(nudge[0], nudge[1]);
    }
  });
}

function bindShare() {
  ui.openShare?.addEventListener('click', () => ui.shareDialog.showModal());

  ui.copyStage?.addEventListener('click', async () => {
    const link = ui.stageUrl.value;
    if (!link) return;
    try {
      await navigator.clipboard.writeText(link);
      toast('Enlace copiado', 'ok');
    } catch {
      ui.stageUrl?.select();
      toast('Copia el enlace a mano', 'warn');
    }
  });
  ui.stageSolid?.addEventListener('change', () => {
    const url = new URL(ui.stageUrl.value, location.origin);
    if (ui.stageSolid.checked) url.searchParams.set('bg', '1');
    else url.searchParams.delete('bg');
    if (ui.stageUrl) ui.stageUrl.value = url.toString();
  });
  ui.stageUrl?.addEventListener('focus', () => ui.stageUrl.select());

  ui.controlUrl?.addEventListener('focus', () => ui.controlUrl.select());
}

async function loadShare() {
  try {
    const share = await api('/api/share');
    state.share = share;
    // The address to hand over is the one the server says it has, never the one
    // this window was opened with: from a laptop inside the house that would be
    // a private address, and it would not work in anybody else's OBS.
    const base = share.publicUrl || location.origin;
    const url = new URL(share.stagePath, base);
    url.searchParams.set('t', share.token);
    if (ui.stageSolid.checked) url.searchParams.set('bg', '1');
    if (ui.stageUrl) ui.stageUrl.value = url.toString();
    if (ui.controlUrl && share.controlUrl) {
      ui.controlUrl.value = new URL(share.controlUrl, base).toString();
    }
  } catch {
    /* the screens work without the link */
  }
}

/* --------------------------------- boot --------------------------------- */

function start() {
  state.views = {
    program: makeView('program', ui.frameProgram, ui.sceneProgram, ui.guidesProgram),
  };
  state.editor = new Editor({
    views: state.views,
    canvas: state.canvas,
    cut: state.cut,
    api,
    live: liveTransform,
    onChange: (object, info = {}) => {
      if (object && info.live) {
        // Keep the local model in step so the next gesture starts from the truth.
        const local = state.editor.find(object.id);
        if (local) Object.assign(local, object);
        renderToolbar(state.editor.selectionDetails());
        return;
      }
      refreshWorkspace().catch(() => {});
    },
    onSelect: renderToolbar,
  });
  bindToolbar();
  bindHidden();
  bindListen();
  bindText();
  bindHistory();
  bindScreenGestures('program', ui.frameProgram);
  bindKeyboard();
  bindShare();
  ui.fileInput?.addEventListener('change', async (event) => {
    await uploadFiles(event.target.files);
    event.target.value = '';
  });
  ui.dropHint?.addEventListener('click', () => ui.fileInput?.click());

  /*
   * The very first measurement can land before the window has its final size,
   * which leaves the long screen at full width with the bank a scroll away. Any
   * later change to the room re-fits it, so it only has to be measured right,
   * not measured first.
   */
  let fitQueued = false;
  const scheduleFit = () => {
    if (fitQueued) return;
    fitQueued = true;
    requestAnimationFrame(() => {
      fitQueued = false;
      fitScenes();
    });
  };
  if (ui.layout && typeof ResizeObserver === 'function') {
    new ResizeObserver(scheduleFit).observe(ui.layout);
  }
  window.addEventListener('resize', scheduleFit);
  fitScenes();
  scheduleFit();
  window.addEventListener('load', scheduleFit);
  // A handle on the model, for the browser checks and for debugging from the
  // console. Read only in practice: everything goes through the editor.
  window.__state = state;
}

async function refreshWorkspace() {
  const data = await api('/api/workspace');
  applyWorkspace(data);
}

async function boot() {
  // A swallowed failure here used to leave the panel stuck on "sin servidor"
  // with no clue why, so the reason is logged even though boot carries on.
  const me = await loadMe().catch((err) => {
    console.error('no se pudo leer la sesion', err);
    return null;
  });
  if (!me && !state.tokenFallback) {
    setWs('err', 'sin servidor');
    setTimeout(boot, 2500);
    return;
  }
  if (me && (new URLSearchParams(location.search).get('cambiar') === '1' || me.mustChangePassword)) {
    showPasswordDialog(true);
  }
  loadShare();
  try {
    await refreshWorkspace();
    connectWs();
  } catch (bootErr) {
    console.error('no se pudo cargar el espacio de trabajo', bootErr);
    setWs('err', 'sin servidor');
    setTimeout(boot, 2500);
  }
}

start();
renderToolbar(null);
renderHidden();
renderObjectList();
renderMods();
renderHistory();
renderHistoryAdmin();
setWs('warn', 'conectando…');
boot();
// The age of the OBS source is counted here, so it has to be looked at often
// enough for the seconds to move at something like real time.
setInterval(renderStatus, 2000);
// The scrubber counts on its own while a clip is selected, so the thumb walks
// with the clip instead of standing where it was left.
setInterval(paintSeekBar, 500);

/* ----------------------------- auth island ------------------------------ */
/* The account handling below is unchanged from the version that shipped: the
   sign in, password and moderator flows keep behaving exactly as they did. */
/* --------------------------------- auth -------------------------------- */

function fmtDate(value) {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return date.toLocaleDateString('es-ES', { day: 'numeric', month: 'long', year: 'numeric' });
}

function renderMe() {
  const me = state.me;
  if (state.tokenFallback) {
    // No accounts yet: the server token is running the show until the owner
    // creates the first administrator.
    ui.userName.textContent = 'modo token';
    ui.userFullName.textContent = 'Todavía no hay cuentas';
    ui.userRole.textContent = 'instalación';
    ui.userRole.className = 'badge warn';
    // El primer administrador se crea desde el instalador o por linea de
    // comandos, no desde aqui: el menu es para quien ya esta dentro.
    ui.userSince.textContent = 'Crea el primer administrador con el instalador o por linea de comandos.';
    if (ui.changePassword) ui.changePassword.hidden = true;
    if (ui.logout) ui.logout.hidden = true;
    if (ui.openUsers) ui.openUsers.hidden = true;
    if (ui.hideToggle) ui.hideToggle.hidden = false;
    if (ui.listenToggle) ui.listenToggle.hidden = false;
    // Sin cuentas todavia, quien entra con el token es el dueno: le sirve.
    if (ui.openShare) ui.openShare.hidden = false;
    return;
  }
  if (!me) return;
  ui.userName.textContent = me.username;
  ui.userFullName.textContent = me.username;
  ui.userRole.textContent = me.role === 'admin' ? 'administrador' : 'moderador';
  ui.userRole.className = `badge ${me.role === 'admin' ? 'live' : 'off'}`;
  ui.userSince.textContent = `Cuenta desde el ${fmtDate(me.createdAt)}${
    me.lastLoginAt ? ` · último acceso ${new Date(me.lastLoginAt).toLocaleString('es-ES')}` : ''
  }`;
  // Administrator-only buttons: managing accounts, and the link to the OBS
  // screen. A moderator prepares and moves things; the broadcast link is the
  // owner's business, and it carries the stage token inside it.
  const admin = me.role === 'admin';
  if (ui.openUsers) ui.openUsers.hidden = !admin;
  if (ui.openShare) ui.openShare.hidden = !admin;
  if (ui.hideToggle) ui.hideToggle.hidden = !admin;
  if (ui.listenToggle) ui.listenToggle.hidden = !admin;
  if (ui.openShare && ui.shareDialog?.open) ui.shareDialog.close();
}

async function loadMe() {
  const res = await fetch('/api/auth/me', { cache: 'no-store' });
  if (!res.ok) {
    location.replace(`/login?next=${encodeURIComponent(location.pathname + location.search)}`);
    return null;
  }
  const payload = await res.json();
  state.tokenFallback = Boolean(payload.tokenFallback);
  state.me = payload.user ?? null;
  if (!state.me && !state.tokenFallback) {
    location.replace(`/login?next=${encodeURIComponent(location.pathname + location.search)}`);
    return null;
  }
  renderMe();
  renderHistoryAdmin();
  return state.me;
}

function usersError(message) {
  ui.usersError.textContent = message;
  ui.usersError.hidden = !message;
}

function renderUsers() {
  ui.usersList.replaceChildren();
  if (!state.users.length) {
    const empty = document.createElement('p');
    empty.className = 'hint';
    empty.textContent = 'Todavía no hay cuentas.';
    ui.usersList.append(empty);
    return;
  }
  for (const user of state.users) {
    const row = document.createElement('div');
    row.className = `user-row${user.disabled ? ' off' : ''}`;

    const info = document.createElement('div');
    info.className = 'meta';
    const name = document.createElement('div');
    name.className = 'name';
    name.textContent = user.username;
    const sub = document.createElement('div');
    sub.className = 'sub';
    sub.textContent = [
      user.role === 'admin' ? 'administrador' : 'moderador',
      user.sessions ? `${user.sessions} sesión(es)` : 'sin sesiones',
      user.lastLoginAt ? `último acceso ${new Date(user.lastLoginAt).toLocaleString('es-ES')}` : 'nunca ha entrado',
    ].join(' · ');
    info.append(name, sub);

    const badge = document.createElement('span');
    badge.className = `badge ${user.disabled ? 'off' : 'live'}`;
    badge.textContent = user.disabled ? 'desactivado' : 'activo';

    const role = document.createElement('select');
    role.setAttribute('aria-label', `Rol de ${user.username}`);
    role.innerHTML =
      '<option value="mod">moderador</option><option value="admin">administrador</option>';
    role.value = user.role;
    role.addEventListener('change', async () => {
      try {
        await api(`/api/auth/users/${encodeURIComponent(user.id)}`, {
          method: 'PATCH',
          body: JSON.stringify({ role: role.value }),
        });
        toast(`${user.username} ahora es ${role.value === 'admin' ? 'administrador' : 'moderador'}.`, 'ok');
        await loadUsers();
      } catch (err) {
        usersError(err.message);
        role.value = user.role;
      }
    });

    const toggle = document.createElement('button');
    toggle.className = 'btn btn-ghost btn-mini';
    toggle.type = 'button';
    toggle.textContent = user.disabled ? 'Activar' : 'Desactivar';
    toggle.addEventListener('click', async () => {
      try {
        await api(`/api/auth/users/${encodeURIComponent(user.id)}`, {
          method: 'PATCH',
          body: JSON.stringify({ disabled: !user.disabled }),
        });
        await loadUsers();
      } catch (err) {
        usersError(err.message);
      }
    });

    const pass = document.createElement('button');
    pass.className = 'btn btn-ghost btn-mini';
    pass.type = 'button';
    pass.textContent = 'Nueva clave';
    pass.addEventListener('click', async () => {
      const password = prompt(`Clave nueva para ${user.username} (mínimo 10 caracteres):`);
      if (!password) return;
      try {
        await api(`/api/auth/users/${encodeURIComponent(user.id)}`, {
          method: 'PATCH',
          body: JSON.stringify({ password }),
        });
        toast(`Clave de ${user.username} cambiada.`, 'ok');
      } catch (err) {
        usersError(err.message);
      }
    });

    const del = document.createElement('button');
    del.className = 'btn btn-danger btn-mini';
    del.type = 'button';
    del.textContent = '✕';
    del.title = `Eliminar ${user.username}`;
    del.addEventListener('click', async () => {
      if (!confirm(`¿Eliminar la cuenta de ${user.username}?`)) return;
      try {
        await api(`/api/auth/users/${encodeURIComponent(user.id)}`, { method: 'DELETE' });
        toast(`Cuenta ${user.username} eliminada.`, 'ok');
        await loadUsers();
      } catch (err) {
        usersError(err.message);
      }
    });

    row.append(info, badge, role, pass, toggle, del);
    ui.usersList.append(row);
  }
}

async function loadUsers() {
  if (state.me?.role !== 'admin') return;
  try {
    const data = await api('/api/auth/users');
    state.users = data.users ?? [];
    usersError('');
    renderUsers();
  } catch (err) {
    usersError(err.message);
  }
}

async function createUser(username, password, role) {
  if (!username || !password) {
    usersError('Escribe usuario y contraseña.');
    return null;
  }
  try {
    const data = await api('/api/auth/users', {
      method: 'POST',
      body: JSON.stringify({ username, password, role, mustChangePassword: false }),
    });
    ui.newUsername.value = '';
    ui.newPassword.value = '';
    ui.newRole.value = 'mod';
    usersError('');
    toast(`Cuenta ${data.user.username} creada.`, 'ok');
    await loadUsers();
    return data.user;
  } catch (err) {
    usersError(err.message);
    return null;
  }
}

function showPasswordDialog(force = false) {
  ui.passCurrent.value = '';
  ui.passNext.value = '';
  ui.passAgain.value = '';
  ui.passError.hidden = true;
  ui.passwordDialog.dataset.force = force ? '1' : '';
  ui.passwordDialog.showModal();
}

async function submitPassword(event) {
  if (event.submitter?.value === 'cancel') {
    if (ui.passwordDialog.dataset.force === '1') {
      event.preventDefault();
      toast('Tienes que cambiar la contraseña antes de continuar.', 'warn');
    }
    return;
  }
  event.preventDefault();
  if (ui.passNext.value !== ui.passAgain.value) {
    ui.passError.textContent = 'Las dos contraseñas nuevas no coinciden.';
    ui.passError.hidden = false;
    return;
  }
  try {
    await api('/api/auth/password', {
      method: 'POST',
      body: JSON.stringify({ current: ui.passCurrent.value, next: ui.passNext.value }),
    });
    ui.passwordDialog.close();
    location.replace('/login');
  } catch (err) {
    ui.passError.textContent =
      err.message === 'wrong_password'
        ? 'La contraseña actual no es correcta.'
        : err.message === 'weak_password'
          ? 'La nueva necesita al menos 10 caracteres.'
          : err.message;
    ui.passError.hidden = false;
  }
}


/* ------------------------------- ui wiring ------------------------------ */

ui.userButton?.addEventListener('click', (event) => {
  event.stopPropagation();
  const open = ui.userPanel.hidden;
  ui.userPanel.hidden = !open;
  ui.userButton?.setAttribute('aria-expanded', String(open));
});
document.addEventListener('click', (event) => {
  if (!ui.userPanel.hidden && !ui.userPanel.contains(event.target)) {
    ui.userPanel.hidden = true;
    ui.userButton?.setAttribute('aria-expanded', 'false');
  }
});
ui.changePassword?.addEventListener('click', () => showPasswordDialog(false));
ui.passwordForm?.addEventListener('submit', submitPassword);
ui.logout?.addEventListener('click', async () => {
  try {
    await api('/api/auth/logout', { method: 'POST' });
  } catch {
    /* leaving anyway */
  }
  location.replace('/login');
});
ui.openUsers?.addEventListener('click', () => {
  ui.usersDialog?.showModal();
  loadUsers().catch(() => {});
});
ui.usersForm?.addEventListener('submit', (event) => {
  if (event.submitter?.value === 'create') {
    event.preventDefault();
    createUser(ui.newUsername.value.trim(), ui.newPassword.value.trim(), ui.newRole.value);
  }
});
el('createUser')?.addEventListener('click', async (event) => {
  event.preventDefault();
  await createUser(ui.newUsername.value.trim(), ui.newPassword.value.trim(), ui.newRole.value);
});
