/*
 * Geometry and editing rules for the long screen, kept apart from the DOM so
 * the behaviour can be tested without a browser.
 *
 * Everything here works in screen pixels: a 1920x2160 space whose top half is
 * what goes out, so an object dragged from the bank up across the cut keeps the
 * same numbers and lands exactly under the cursor.
 */

export const SNAP_PX = 6;
/** Distance, in stage pixels, within which an edge snaps to another one. */
export const SNAP_RANGE = 10;

export const HANDLES = ['nw', 'n', 'ne', 'e', 'se', 's', 'sw', 'w'];

const round2 = (n) => Math.round(n * 100) / 100;

export function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

export function rectOf(object) {
  return { x: object.x, y: object.y, w: object.w, h: object.h };
}

/** Bounding box of a rotated object, used for snapping and for fitting. */
export function boundsOf(object) {
  const rad = ((object.rot || 0) * Math.PI) / 180;
  const cos = Math.abs(Math.cos(rad));
  const sin = Math.abs(Math.sin(rad));
  const w = object.w * cos + object.h * sin;
  const h = object.w * sin + object.h * cos;
  return {
    x: object.x + object.w / 2 - w / 2,
    y: object.y + object.h / 2 - h / 2,
    w,
    h,
  };
}

/** A default size for a new object: natural size, or a sensible share of the canvas. */
export function defaultSize(object, canvas) {
  const nw = object.naturalWidth;
  const nh = object.naturalHeight;
  if (nw > 0 && nh > 0) {
    const scale = Math.min(1, (canvas.width * 0.6) / nw, (canvas.height * 0.6) / nh);
    return { w: round2(nw * scale), h: round2(nh * scale) };
  }
  return { w: round2(canvas.width * 0.35), h: round2(canvas.height * 0.35) };
}

export function centeredOn(canvas, size) {
  return {
    x: round2((canvas.width - size.w) / 2),
    y: round2((canvas.height - size.h) / 2),
  };
}

/**
 * Move. `dx`/`dy` are in stage pixels. `snaps` is filled in with the guides to
 * paint, which is what makes it feel like OBS instead of a free float.
 */
export function moveObject(object, { dx, dy, others = [], canvas, snap = true, guides = null }) {
  let { x, y } = object;
  x = round2(x + dx);
  y = round2(y + dy);

  const box = { x, y, w: object.w, h: object.h };
  if (snap) {
    const found = collectSnap(box, others, canvas);
    if (found.dx) x = round2(x + found.dx);
    if (found.dy) y = round2(y + found.dy);
    if (guides) {
      guides.x = found.guideX;
      guides.y = found.guideY;
    }
  }
  // Snapping works in whole pixels and does not know about the edges, so the
  // clamp goes last: it is the rule that decides what may be left outside.
  return clampInside({ x, y, w: object.w, h: object.h }, canvas);
}

const EDGES = (box) => ({
  left: box.x,
  centerX: box.x + box.w / 2,
  right: box.x + box.w,
  top: box.y,
  centerY: box.y + box.h / 2,
  bottom: box.y + box.h,
});

/**
 * Finds the smallest correction that lines the object up with a neighbour or
 * with the canvas, on either axis. Canvas lines only count when the object is
 * already close to the middle, so a free object does not jump to centre.
 */
export function collectSnap(box, others, canvas, range = SNAP_RANGE) {
  const out = { dx: 0, dy: 0, guideX: null, guideY: null };
  const mine = EDGES(box);
  const targetsX = [
    { value: 0, kind: 'canvas' },
    { value: canvas.width / 2, kind: 'canvas' },
    { value: canvas.width, kind: 'canvas' },
  ];
  const targetsY = [
    { value: 0, kind: 'canvas' },
    // The cut is a real line on this screen, so it is a real snap target: it
    // is where an object starts going out.
    { value: canvas.height / 2, kind: 'canvas' },
    { value: canvas.height, kind: 'canvas' },
  ];
  for (const other of others) {
    const theirs = EDGES(other);
    targetsX.push({ value: theirs.left, kind: 'object' }, { value: theirs.centerX, kind: 'object' }, { value: theirs.right, kind: 'object' });
    targetsY.push({ value: theirs.top, kind: 'object' }, { value: theirs.centerY, kind: 'object' }, { value: theirs.bottom, kind: 'object' });
  }

  let bestX = null;
  for (const edge of ['left', 'centerX', 'right']) {
    for (const target of targetsX) {
      const delta = target.value - mine[edge];
      if (Math.abs(delta) > range) continue;
      if (bestX && Math.abs(bestX.delta) <= Math.abs(delta)) continue;
      bestX = { delta, at: target.value };
    }
  }
  let bestY = null;
  for (const edge of ['top', 'centerY', 'bottom']) {
    for (const target of targetsY) {
      const delta = target.value - mine[edge];
      if (Math.abs(delta) > range) continue;
      if (bestY && Math.abs(bestY.delta) <= Math.abs(delta)) continue;
      bestY = { delta, at: target.value };
    }
  }
  if (bestX) {
    out.dx = bestX.delta;
    out.guideX = bestX.at;
  }
  if (bestY) {
    out.dy = bestY.delta;
    out.guideY = bestY.at;
  }
  return out;
}

/**
 * Resize from a handle. `aspect` keeps the media ratio (the default for
 * images), `fromCenter` mirrors the box around its middle, like OBS with Alt.
 */
export function resizeObject(object, handle, pointer, start, { aspect = true, fromCenter = false, min = 8, canvas }) {
  const left = start.x;
  const top = start.y;
  const right = start.x + start.w;
  const bottom = start.y + start.h;
  let x1 = left;
  let y1 = top;
  let x2 = right;
  let y2 = bottom;

  if (handle.includes('w')) x1 = pointer.x;
  if (handle.includes('e')) x2 = pointer.x;
  if (handle.includes('n')) y1 = pointer.y;
  if (handle.includes('s')) y2 = pointer.y;

  let w = Math.max(min, x2 - x1);
  let h = Math.max(min, y2 - y1);

  if (aspect && start.w > 0 && start.h > 0) {
    const ratio = start.w / start.h;
    const byWidth = w / ratio;
    // Follow whichever axis the pointer pushed further, so the corner tracks it.
    if (handle === 'n' || handle === 's') w = h * ratio;
    else if (byWidth > h) h = byWidth;
    else w = h * ratio;
    if (handle.includes('w')) x1 = x2 - w;
    else x2 = x1 + w;
    if (handle.includes('n')) y1 = y2 - h;
    else y2 = y1 + h;
  }

  if (fromCenter) {
    const cx = (left + right) / 2;
    const cy = (top + bottom) / 2;
    w = Math.max(min, Math.abs(pointer.x - cx) * 2);
    h = Math.max(min, Math.abs(pointer.y - cy) * 2);
    if (aspect && start.w > 0 && start.h > 0) {
      const ratio = start.w / start.h;
      if (w / ratio > h) h = w / ratio;
      else w = h * ratio;
    }
    x1 = cx - w / 2;
    y1 = cy - h / 2;
  }

  return {
    x: round2(x1),
    y: round2(y1),
    w: round2(w),
    h: round2(h),
    ...(canvas ? { inside: x1 >= -canvas.width && y1 >= -canvas.height } : {}),
  };
}

/**
 * Rotation around the object centre. `angle` is the absolute result in degrees,
 * already computed by the caller from the pointer, so this only clamps it.
 */
export function rotateObject(object, angle) {
  return { rot: round2(clamp(angle, -360, 360)) };
}

/**
 * How much of an object has to stay inside the screen, on every side. Further
 * out than this and it can no longer be clicked, so it could not be picked up
 * again to bring it back: gone for good while still listed as content. The
 * server applies the same rule, so the panel never lets go of something that
 * would be refused on save.
 */
export const REACH = 24;

/**
 * Puts an object back within reach after a move, a resize or a nudge. An object
 * bigger than the screen is centred instead, since no side has room to spare.
 */
export function clampInside(object, canvas) {
  const fit = (value, size, limit) => {
    if (size >= limit) return 0;
    return clamp(value, REACH - size, limit - REACH);
  };
  return {
    x: round2(fit(object.x, object.w, canvas.width)),
    y: round2(fit(object.y, object.h, canvas.height)),
  };
}

/** Fits an object to the full width of the canvas, keeping its ratio. */
export function fitWidth(object, canvas) {
  if (!object.w || !object.h) return { w: canvas.width, h: canvas.height };
  const ratio = object.h / object.w;
  const w = canvas.width;
  return { w: round2(w), h: round2(w * ratio) };
}

/**
 * Whether an object shows something the moderator can use, rather than just
 * look at. Today that is an embedded page, drawn as an iframe: a double click
 * hands the pointer to the page, so clicking inside it reaches the item that is
 * under the cursor there instead of the object sitting behind. Everything else
 * keeps the double click that centres it.
 */
export function isInteractive(object) {
  return object?.render === 'html';
}

/**
 * Centres an object on the long screen. The screen is two halves of the same
 * size, so the object is centred inside whichever half it already belongs to
 * rather than across the cut, which would park it half on air and half in the
 * bank. An object with no place yet goes to the bank.
 */
export function centerObject(object, canvas, cut = canvas.height / 2) {
  const half = object.y + object.h / 2 < cut ? { top: 0, height: cut } : { top: cut, height: canvas.height - cut };
  return {
    x: round2((canvas.width - object.w) / 2),
    y: round2(half.top + (half.height - object.h) / 2),
  };
}
