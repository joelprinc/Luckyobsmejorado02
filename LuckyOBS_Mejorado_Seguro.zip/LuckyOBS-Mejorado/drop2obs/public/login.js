const el = (id) => document.getElementById(id);
const form = el('form');
const error = el('error');
const submit = el('submit');
const password = el('password');
const params = new URLSearchParams(location.search);
const tokenForm = el('tokenForm');

/* Bootstrap mode: no accounts exist yet, so the owner signs in with the token
   the installer printed. The server swaps it for its own cookie. */
if (params.get('token') === '1') {
  form.hidden = true;
  tokenForm.hidden = false;
  el('token').focus();
}

/* If the owner has no accounts yet, the server token is the only way in, so
   offer that link instead of a login form that cannot possibly work. */
async function checkTokenAccess() {
  try {
    const res = await fetch('/api/auth/me', { cache: 'no-store' });
    if (!res.ok) return;
    const data = await res.json();
    if (data.authenticated) {
      location.replace(safeNext());
      return;
    }
    if (data.tokenFallback) {
      form.hidden = true;
      el('tokenHint').hidden = false;
    }
  } catch {
    /* offline: leave the form as it is */
  }
}

function safeNext() {
  const next = params.get('next');
  if (!next || !next.startsWith('/') || next.startsWith('//')) return '/';
  return next;
}

function showError(message) {
  error.textContent = message;
  error.hidden = false;
}

function clearError() {
  error.hidden = true;
  error.textContent = '';
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  clearError();
  submit.disabled = true;
  submit.textContent = 'Comprobando…';
  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ username: el('username').value, password: password.value }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      showError(data.message || 'No se pudo entrar.');
      password.value = '';
      password.focus();
      return;
    }
    if (data.user?.mustChangePassword) {
      location.replace(`${safeNext()}${safeNext().includes('?') ? '&' : '?'}cambiar=1`);
      return;
    }
    location.replace(safeNext());
  } catch {
    showError('Sin conexión con el servidor.');
  } finally {
    submit.disabled = false;
    submit.textContent = 'Entrar';
  }
});

tokenForm.addEventListener('submit', (event) => {
  event.preventDefault();
  const tokenError = el('tokenError');
  const value = el('token').value.trim();
  if (!value) {
    tokenError.textContent = 'Pega el token del servidor.';
    tokenError.hidden = false;
    return;
  }
  location.replace(`/?t=${encodeURIComponent(value)}`);
});

el('peek').addEventListener('click', () => {
  const visible = password.type === 'text';
  password.type = visible ? 'password' : 'text';
  el('peek').textContent = visible ? '👁' : '🙈';
  el('peek').setAttribute('aria-label', visible ? 'Ver contraseña' : 'Ocultar contraseña');
  password.focus();
});

checkTokenAccess();
