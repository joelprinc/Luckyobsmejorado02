/*
 * Scene renderer shared by the OBS browser source and the control page, so both
 * draw the program with the exact same code and the stream never disagrees with
 * what the moderator sees.
 *
 * It is deliberately dependency free and defensive: this file also runs inside
 * OBS, where a thrown error means a frozen source on air.
 */
(function (global) {
  'use strict';

  function mediaUrl(object, origin) {
    try {
      var url = new URL(object.url, origin || location.origin);
      return (origin || location.origin) + url.pathname + url.search;
    } catch (err) {
      return object.url || '';
    }
  }

  /**
   * How loud this object plays, from 0 to 1. An object saved before the volume
   * slider existed only had a mute switch, so that switch is still honoured.
   */
  function volumeOf(object) {
    var value = Number(object && object.volume);
    if (isFinite(value)) return Math.min(1, Math.max(0, value));
    return object && object.muted === true ? 0 : 1;
  }

  /** Whether the clip has to stay silent, whatever the volume says. */
  function silentFor(pageMuted, object) {
    return pageMuted !== false || volumeOf(object) === 0;
  }

  function failedBox(object) {
    var box = document.createElement('div');
    box.className = 'object-failed';
    box.textContent = 'No se pudo cargar ' + (object.name || '');
    return box;
  }

  /**
   * Starts a video and is patient about it. A clip with sound can be refused
   * until the browser has seen a gesture, and inside a browser source there is
   * never one, so the attempts are spread over the loading of the file and one
   * is left waiting for a first interaction in case it is needed.
   */
  function startVideo(video, withSound) {
    var attempt = function () {
      var play = video.play();
      if (play && typeof play.catch === 'function') {
        play.catch(function () { /* another attempt comes later */ });
      }
    };
    attempt();
    if (!withSound) return;
    video.addEventListener('loadeddata', attempt, { once: true });
    video.addEventListener('canplay', attempt, { once: true });
    window.addEventListener('pointerdown', attempt, { once: true });
    window.addEventListener('keydown', attempt, { once: true });
  }

  /**
   * A file that is only sound. A bare <video> with an mp3 in it plays and shows
   * nothing at all, which on a stream reads as a broken object, so this draws a
   * card with the name and an equaliser that moves while it plays. The sound is
   * the same <video> element underneath, so volume, loop and replay keep working
   * exactly as they do for a clip.
   */
  function audioCard(object, origin, muted) {
    var card = document.createElement('div');
    card.className = 'audio-card';
    var bars = document.createElement('span');
    bars.className = 'audio-bars';
    bars.setAttribute('aria-hidden', 'true');
    for (var i = 0; i < 5; i += 1) bars.appendChild(document.createElement('i'));
    var label = document.createElement('span');
    label.className = 'audio-name';
    label.textContent = object.name || 'audio';
    var media = buildContent(object, origin, muted, { bare: true });
    // The bars follow the sound and not the clock: what moves is what is playing.
    var sync = function () {
      card.classList.toggle('is-playing', !media.paused && !media.ended);
    };
    ['play', 'pause', 'ended', 'seeked'].forEach(function (name) {
      media.addEventListener(name, sync);
    });
    sync();
    card.appendChild(media);
    card.appendChild(bars);
    card.appendChild(label);
    return card;
  }

  function buildContent(object, origin, muted, options) {
    var render = object.render || object.kind;
    var url = mediaUrl(object, origin);
    var bare = Boolean(options && options.bare);
    if (render === 'image') {
      var img = document.createElement('img');
      img.alt = object.name || '';
      img.decoding = 'async';
      img.draggable = false;
      img.addEventListener('error', function () {
        if (img.parentNode) img.parentNode.replaceChild(failedBox(object), img);
      });
      img.src = url;
      return img;
    }
    if (render === 'text') {
      var box = document.createElement('div');
      box.className = 'object-live';
      // The words come from the server already sanitised, and the font stack too,
      // so this only ever writes what the object says. The inner span is what
      // carries the alignment: the box only centres it vertically.
      var text = document.createElement('span');
      text.className = 'object-live-text';
      text.textContent = object.text || '';
      text.style.fontFamily = object.textFontStack || 'sans-serif';
      text.style.fontSize = (Number(object.textSize) || 96) + 'px';
      text.style.color = object.textColor || '#ffffff';
      text.style.textAlign = object.textAlign || 'center';
      box.appendChild(text);
      return box;
    }
    if ((render === 'media' || render === 'video') && object.audioOnly && !bare) {
      return audioCard(object, origin, muted);
    }
    if (render === 'media' || render === 'video') {
      var video = document.createElement('video');
      // Sound belongs to the stream, not to the moderator's desk: the OBS
      // source asks for the clip with sound, the control page keeps it silent.
      // Both draw the same file, so it is heard once and only once. On top of
      // that, the object carries its own volume, and at zero OBS hears nothing.
      var silent = silentFor(muted, object);
      video.muted = silent;
      video.defaultMuted = silent;
      video.volume = silent ? 0 : volumeOf(object);
      video.loop = object.loop !== false;
      video.autoplay = true;
      video.playsInline = true;
      video.controls = false;
      video.draggable = false;
      video.preload = 'auto';
      video.setAttribute('webkit-playsinline', '');
      video.addEventListener('error', function () {
        if (video.parentNode) video.parentNode.replaceChild(failedBox(object), video);
      });
      video.src = url;
      startVideo(video, video.muted === false);
      return video;
    }
    if (render === 'html') {
      var frame = document.createElement('iframe');
      // HTML uploaded by a moderator is untrusted: keep scripts for animations
      // but never allow the iframe to inherit our login origin.
      frame.setAttribute('sandbox', 'allow-scripts');
      frame.setAttribute('referrerpolicy', 'no-referrer');
      // A frame is draggable like an image is, which is how an object could be
      // pulled out of the panel into another tab. It is moved with the pointer.
      frame.draggable = false;
      frame.src = url;
      return frame;
    }
    var pre = document.createElement('pre');
    pre.className = 'object-text';
    pre.draggable = false;
    pre.textContent = 'Cargando…';
    fetch(url, { credentials: 'omit' })
      .then(function (res) {
        if (!res.ok) throw new Error('HTTP ' + res.status);
        return res.text();
      })
      .then(function (text) { pre.textContent = text; })
      .catch(function (err) {
        pre.textContent = 'No se pudo cargar ' + (object.name || '') + ' (' + err.message + ')';
      });
    return pre;
  }

  /**
   * A screen is a 1920x1080 box scaled down to fit its container. Objects are
   * placed with plain pixels inside that box, so the same numbers describe the
   * same place on the control page and on air.
   */
  function SceneView(root, options) {
    this.root = root;
    this.options = options || {};
    this.origin = this.options.origin || location.origin;
    this.nodes = new Map();
    this.scene = { width: 1920, height: 1080, objects: [] };
    this.scale = 1;
    this.measure();
  }

  SceneView.prototype.measure = function measure() {
    var box = this.root.getBoundingClientRect();
    var w = this.scene.width || 1920;
    var h = this.scene.height || 1080;
    this.scale = box.width > 0 ? box.width / w : 1;
    this.boxHeight = box.height;
    this.pixelWidth = box.width;
    this.pixelHeight = box.height;
    this.root.style.setProperty('--scene-scale', String(this.scale));
  };

  /** Stage pixels for a point given in client coordinates. */
  SceneView.prototype.toScene = function toScene(clientX, clientY) {
    var box = this.root.getBoundingClientRect();
    var sx = this.scale || 1;
    return {
      x: (clientX - box.left) / sx,
      y: (clientY - box.top) / sx,
    };
  };

  SceneView.prototype.applyTransform = function applyTransform(node, object) {
    node.style.left = object.x + 'px';
    node.style.top = object.y + 'px';
    node.style.width = object.w + 'px';
    node.style.height = object.h + 'px';
    node.style.opacity = String(object.opacity ?? 1);
    node.style.zIndex = String(object.z ?? 0);
    node.style.transform = object.rot ? 'rotate(' + object.rot + 'deg)' : '';
    node.hidden = object.visible === false;
  };

  SceneView.prototype.render = function render(scene) {
    if (!scene || typeof scene !== 'object') return;
    this.scene = scene;
    this.measure();
    var self = this;
    var wanted = new Set();
    (scene.objects || []).forEach(function (object) {
      wanted.add(object.id);
      var render = object.render || object.kind;
      var node = self.nodes.get(object.id);
      // An object that stopped being what it was is torn down and built again,
      // because the node it left behind is of no use to what it is now.
      if (node && node.dataset.render !== render) {
        node.remove();
        self.nodes.delete(object.id);
        node = null;
      }
      if (!node) {
        node = self.createNode(object);
        self.nodes.set(object.id, node);
        self.root.appendChild(node);
      }
      node.dataset.id = object.id;
      self.applyTransform(node, object);
      // What is inside an existing node has to follow the object too: the words
      // of a label are edited in place, and the volume of a clip moves without
      // the clip ever being rebuilt.
      self.applyContent(node, object);
    });
    this.nodes.forEach(function (node, id) {
      if (wanted.has(id)) return;
      node.remove();
      self.nodes.delete(id);
    });
  };

  SceneView.prototype.createNode = function createNode(object) {
    var node = document.createElement('div');
    node.className = 'scene-object';
    node.dataset.id = object.id;
    node.dataset.render = object.render || object.kind;
    var media = document.createElement('div');
    media.className = 'scene-media';
    media.appendChild(buildContent(object, this.origin, this.options.muted));
    node.appendChild(media);
    this.applyClip(node, object);
    if (this.options.interactive) this.decorateNode(node, object);
    return node;
  };

  /**
   * Brings what is inside a node up to date without rebuilding it.
   *
   * For a label that means the words and their look, because that is edited in
   * place: rebuilding the node on every keystroke would throw away the selection
   * and make the caret jump. For a clip it means the volume and the loop, which
   * is what applyClip already does.
   */
  SceneView.prototype.applyContent = function applyContent(node, object) {
    var text = node.querySelector && node.querySelector('.object-live-text');
    if (text) {
      var words = String(object.text ?? '');
      if (text.textContent !== words) text.textContent = words;
      text.style.fontFamily = object.textFontStack || 'sans-serif';
      text.style.fontSize = (Number(object.textSize) || 96) + 'px';
      text.style.color = object.textColor || '#ffffff';
      text.style.textAlign = object.textAlign || 'center';
      return;
    }
    this.applyClip(node, object);
  };

  /**
   * Selection chrome is only built for the control page. It lives inside the
   * object node so it scales with the scene, which keeps the handles the same
   * physical size on screen as the stage is scaled.
   */
  SceneView.prototype.decorateNode = function decorate(node, object) {
    var box = document.createElement('div');
    box.className = 'object-box';
    ['nw', 'n', 'ne', 'e', 'se', 's', 'sw', 'w'].forEach(function (dir) {
      var handle = document.createElement('span');
      handle.className = 'handle handle-' + dir;
      handle.dataset.handle = dir;
      box.appendChild(handle);
    });
    var rotate = document.createElement('span');
    rotate.className = 'handle handle-rotate';
    rotate.dataset.handle = 'rotate';
    box.appendChild(rotate);

    var label = document.createElement('span');
    label.className = 'object-label';
    label.textContent = object.name || '';
    box.appendChild(label);

    node.appendChild(box);
    node.classList.add('interactive');
  };

  /**
   * Silences or unsilences everything already drawn, without redrawing it.
   *
   * Muting a video that is already playing is enough to take the sound off the
   * air, so the show can go quiet in the middle of a clip and come back with the
   * clip where it was. Used by the switch that hides everything.
   */
  SceneView.prototype.setMuted = function setMuted(muted) {
    this.options.muted = muted === true;
    var objects = (this.scene && this.scene.objects) || [];
    var self = this;
    this.nodes.forEach(function (node, id) {
      for (var i = 0; i < objects.length; i += 1) {
        if (objects[i].id !== id) continue;
        self.applyClip(node, objects[i]);
        return;
      }
    });
  };

  /** Live transform while a drag is still running, without a state round trip. */
  SceneView.prototype.patch = function patch(object) {
    var node = this.nodes.get(object.id);
    if (!node) return false;
    this.applyTransform(node, {
      x: object.x, y: object.y, w: object.w, h: object.h,
      rot: object.rot, opacity: object.opacity, z: object.z,
      visible: object.visible, locked: object.locked,
    });
    this.applyClip(node, object);
    return true;
  };

  /**
   * The moment a clip should be at, in seconds.
   *
   * `seek.at` is a clock, so the answer keeps moving on its own: a jump to the
   * first minute twenty seconds made thirty seconds ago is at one minute fifty
   * now, on this screen and on the OBS source alike. That is what lets a
   * moderator drag the scrubber and have the stream jump with it, without any of
   * this being asked again.
   */
  function targetTime(object, duration) {
    var seek = object && object.seek;
    if (!seek || !Number.isFinite(seek.pos)) return null;
    var gone = seek.at ? Math.max(0, (Date.now() - seek.at) / 1000) : 0;
    var target = seek.pos + gone;
    // A clip on a loop comes back to the start, so the shared moment wraps too.
    if (object.loop !== false && duration > 0) return target % duration;
    if (duration > 0) return Math.min(target, Math.max(0, duration - 0.05));
    return target;
  }

  /**
   * Brings a clip in line with its object: the sound, the loop it asks for, a
   * replay when the object says it was started again, and where in the clip it
   * has to be. A replay and a jump are stamped by the server, so these land on
   * the panel and on the OBS source alike instead of only where it was pressed.
   */
  SceneView.prototype.applyClip = function applyClip(node, object) {
    var video = node.querySelector && (node.querySelector('video') || node.querySelector('audio'));
    if (!video) return;
    var silent = silentFor(this.options.muted, object);
    if (video.muted !== silent) {
      video.muted = silent;
      video.defaultMuted = silent;
    }
    // The slider moves the sound of a clip that is already playing, so a fade
    // does not restart the video.
    var level = silent ? 0 : volumeOf(object);
    if (Math.abs(video.volume - level) > 0.001) video.volume = level;
    var looping = object.loop !== false;
    if (video.loop !== looping) video.loop = looping;
    var stamp = Number(object.playAt) || 0;
    if (stamp && stamp !== node.dataset.playAt) {
      node.dataset.playAt = String(stamp);
      video.currentTime = 0;
      startVideo(video, !silent);
    }
    this.applySeek(node, object, video, { force: true });
  };

  /**
   * Puts the clip where the object says, and undoes the drift afterwards.
   *
   * `force` is for a jump: it always moves, even to the place the clip was
   * already. Without it the check is a nudge, because two clocks in two
   * browsers never agree exactly and a video that keeps being corrected looks
   * like it is stuttering.
   */
  SceneView.prototype.applySeek = function applySeek(node, object, video, options) {
    var force = Boolean(options && options.force);
    var seek = object && object.seek;
    if (!video || !Number.isFinite(video.duration) || video.duration <= 0) return;
    if (!seek) {
      node.dataset.seekAt = '';
      return;
    }
    if (!force && seek.at === node.dataset.seekAt) return;
    var target = targetTime(object, video.duration);
    if (target === null) return;
    if (!force && Math.abs(video.currentTime - target) < 0.4) {
      node.dataset.seekAt = String(seek.at);
      return;
    }
    node.dataset.seekAt = String(seek.at);
    try {
      video.currentTime = target;
    } catch (err) {
      /* before metadata there is nowhere to go */
    }
    // Jumping backwards onto an ended clip has to start it again, or the scrub
    // would look like it did nothing.
    if (video.paused && video.ended !== true && target < video.duration - 0.05) {
      startVideo(video, video.muted === false);
    }
  };

  /**
   * Walks the clips forward so they do not drift apart from each other. Only the
   * OBS source needs this: it is the screen that has to be in the right place.
   */
  SceneView.prototype.syncClips = function syncClips() {
    var objects = (this.scene && this.scene.objects) || [];
    var self = this;
    this.nodes.forEach(function (node, id) {
      var video = node.querySelector && node.querySelector('video');
      if (!video) return;
      for (var i = 0; i < objects.length; i += 1) {
        if (objects[i].id !== id) continue;
        self.applySeek(node, objects[i], video, { force: false });
        return;
      }
    });
  };

  /** Where a clip is and how long it is, for the scrubber. */
  SceneView.prototype.clipProgress = function clipProgress(id) {
    var node = this.nodeFor(id);
    var media = node && node.querySelector && (node.querySelector('video') || node.querySelector('audio'));
    if (!media) return null;
    var duration = Number(media.duration);
    return {
      time: Number(media.currentTime) || 0,
      duration: Number.isFinite(duration) && duration > 0 ? duration : 0,
      playing: !media.paused && media.ended !== true,
    };
  };

  /** Whether a clip has run out, which is when a replay is the useful button. */
  SceneView.prototype.clipEnded = function clipEnded(id) {
    var node = this.nodes.get(id);
    var video = node && node.querySelector && node.querySelector('video');
    return Boolean(video && video.ended);
  };

  SceneView.prototype.objectAt = function objectAt(sceneX, sceneY) {
    var found = null;
    (this.scene.objects || []).forEach(function (object) {
      if (object.visible === false) return;
      if (
        sceneX >= object.x && sceneX <= object.x + object.w
        && sceneY >= object.y && sceneY <= object.y + object.h
      ) {
        // Last one wins: the topmost object under the cursor.
        found = object;
      }
    });
    return found;
  };

  SceneView.prototype.nodeFor = function nodeFor(id) {
    return this.nodes.get(id) || null;
  };

  global.SceneView = SceneView;
  global.buildSceneContent = buildContent;
  global.sceneVolume = volumeOf;
})(window);
