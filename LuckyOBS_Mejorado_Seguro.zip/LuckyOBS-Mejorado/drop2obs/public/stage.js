/*
 * Stage controller. Runs inside an OBS browser source, so it is written to
 * survive a flaky connection and a throttled tab: the WebSocket is the fast
 * path, a poll is the safety net, and the DOM is only touched when the visible
 * objects really change, so a playing video is never restarted mid show.
 */
(function () {
  'use strict';

  var params = new URLSearchParams(location.search);

  /*
   * The token, remembered from the url the source was given.
   *
   * Until now the screen leaned entirely on the session cookie that the first
   * visit leaves behind, and a browser source inside OBS is exactly where
   * cookies are least reliable: change the token on the server and the page
   * keeps retrying a socket that can never be accepted again, with no way out.
   * Carrying the token on every call makes the source independent of whether
   * the cookie survived, and it is the same key the url already has, so it adds
   * nothing new in the way of exposure.
   */
  function stageToken() {
    var fromUrl = params.get('t') || '';
    var key = 'luckyobs.stageToken';
    if (fromUrl) {
      try { localStorage.setItem(key, fromUrl); } catch (err) { /* private mode */ }
      return fromUrl;
    }
    try { return localStorage.getItem(key) || ''; } catch (err) { return ''; }
  }

  function withToken(pathname) {
    var token = stageToken();
    if (!token) return pathname;
    return pathname + (pathname.indexOf('?') === -1 ? '?' : '&') + 't=' + encodeURIComponent(token);
  }

  /* One shot at getting a fresh cookie, and never in a loop. */
  function reauthenticate() {
    var token = stageToken();
    if (!token) return false;
    // When the token travels in the link and it does not work, the link itself
    // is the problem: sending the browser back to the very same address would
    // reload it forever. Say what is wrong instead.
    if (params.get('t')) return false;
    var key = 'luckyobs.stageReauth';
    try {
      if (sessionStorage.getItem(key)) return false;
      sessionStorage.setItem(key, '1');
    } catch (err) {
      /* without session storage there is no safe way to try just once */
      return false;
    }
    location.replace(withToken('/stage'));
    return true;
  }
  var showHud = params.get('ui') === '1' || params.get('ui') === 'true';
  // Transparent unless asked otherwise: an overlay source is the common case.
  var solid = params.get('bg') === '1' || params.get('bg') === 'solid';
  var fitParam = params.get('fit');
  var forcedFit = fitParam === 'off' || fitParam === 'auto' ? 0 : Number(fitParam);

  var stage = document.getElementById('stage');
  var screenEl = document.getElementById('screen');
  var hud = document.getElementById('hud');
  var signature = null;
  var socket = null;
  var aliveTimer = null;
  var retry = 1000;
  var pollTimer = null;
  var lastError = '';
  var connected = false;
  var canvas = '';
  // Where the emission ends on the long screen. Kept between renders so the
  // geometry still knows it before the first payload lands.
  var lastCut = 0;
  /*
   * The switch that takes the whole show off the air. It comes from the server
   * with the rest of the state, so the deck, the control page and this source
   * always agree, and a reconnect cannot leave the stream showing what the
   * moderator already took off.
   */
  var hidden = false;
  /** When the scene was last drawn. The panel watches this to tell a frozen
   *  source from a live one: a browser source that has stopped rendering still
   *  answers, so the socket being open proves nothing on its own. */
  var renderedAt = Date.now();
  var view = null;

  if (solid) document.body.classList.add('solid');

  /* ------------------------------- helpers ------------------------------- */

  // Stable id so the control page can recognise "the same screen" across
  // reconnects instead of counting every reload as a new viewer.
  function stageId() {
    var key = 'luckyobs.stageId';
    try {
      var found = localStorage.getItem(key);
      if (found) return found;
      var made = 'stage-' + Math.random().toString(36).slice(2, 10);
      localStorage.setItem(key, made);
      return made;
    } catch (err) {
      return 'stage-' + Math.random().toString(36).slice(2, 10);
    }
  }

  /** The stage is always 1920x1080 unless the server canvas says otherwise. */
  function applyCanvas(scene) {
    var width = (scene && scene.width) || 1920;
    var height = (scene && scene.height) || 1080;
    // How much of the long screen goes out. Half of it unless the server says
    // otherwise, so a payload without the field still airs the right thing.
    var cut = lastCut > 0 ? lastCut : Math.round(height / 2);
    screenEl.style.setProperty('--scene-w', width + 'px');
    screenEl.style.setProperty('--scene-h', height + 'px');
    screenEl.style.setProperty('--air-h', cut + 'px');
  }

  /**
   * The stage fills the browser source with the emitted half of the long screen
   * and crops the rest, unless a fit factor is forced with ?fit=. The scene is
   * never stretched, because a stretched overlay would not line up with the rest
   * of the scene in OBS.
   *
   * The box is sized to the emitted half only. The scene inside keeps its full
   * height and is simply cut off by the box, so an object is in the same place
   * whether it is being drawn for the stream or for the moderator.
   */
  function layout() {
    var width = parseFloat(screenEl.style.getPropertyValue('--scene-w')) || 1920;
    var height = parseFloat(screenEl.style.getPropertyValue('--scene-h')) || 1080;
    var cut = parseFloat(screenEl.style.getPropertyValue('--air-h')) || height / 2;
    var fit = forcedFit > 0 ? forcedFit : Math.min(window.innerWidth / width, window.innerHeight / cut);
    if (!(fit > 0)) fit = 1;
    var boxW = width * fit;
    var boxH = cut * fit;
    screenEl.style.width = boxW + 'px';
    screenEl.style.height = boxH + 'px';
    screenEl.style.left = (window.innerWidth - boxW) / 2 + 'px';
    screenEl.style.top = (window.innerHeight - boxH) / 2 + 'px';
    stage.style.transform = 'scale(' + fit + ')';
    stage.style.width = width + 'px';
    stage.style.height = height + 'px';
    stage.style.left = '0px';
    stage.style.top = '0px';
    if (view && typeof view.measure === 'function') view.measure();
  }

  /* ------------------------------- render ------------------------------- */

  function sceneOf(state) {
    if (!state || typeof state !== 'object') return null;
    return state.program && state.program.objects ? state.program : null;
  }

  /**
   * The cut that says where the emission ends. Read from the payload and kept
   * for the next render, because the geometry needs it before a scene arrives.
   */
  function cutOf(state, scene) {
    if (state && Number(state.cut) > 0) lastCut = Number(state.cut);
    else if (lastCut <= 0) lastCut = Math.round(((scene && scene.height) || 1080) / 2);
    return lastCut;
  }

  /**
   * Only what actually goes out. An object sitting in the bank is never drawn
   * here, which is what keeps the bank off the stream by construction rather
   * than by hoping the crop lands in the right place. Anything whose top edge is
   * above the cut is drawn, including one that straddles it.
   */
  function onAir(scene, cut) {
    var objects = (scene.objects || []).filter(function (object) {
      return Number(object.y) < cut;
    });
    return { width: scene.width, height: scene.height, id: scene.id, objects: objects };
  }

  /**
   * What makes a redraw necessary. Anything that changes how an object is drawn
   * has to be in here, or the stream keeps showing what it showed before: the
   * volume included, because a quieter clip looks identical but sounds different,
   * and the text with it, because a label that was edited has to arrive.
   */
  function signatureOf(scene) {
    return JSON.stringify((scene.objects || []).map(function (object) {
      return [
        object.id, object.url, object.render, object.name, object.scene,
        object.x, object.y, object.w, object.h, object.rot,
        object.opacity, object.z, object.visible !== false,
        object.volume, object.audioOnly,
        object.text, object.textFontStack, object.textSize,
        object.textColor, object.textAlign,
        object.playAt, object.seek && String(object.seek.at) + ':' + object.seek.pos,
      ];
    }));
  }

  function hiddenOf(state) {
    hidden = Boolean(state && state.hidden);
    return hidden;
  }

  function render(state) {
    var scene = sceneOf(state);
    if (!scene) return;
    var cut = cutOf(state, scene);
    applyCanvas(scene);
    layout();
    // Off the air means off the air: not a single object is drawn. Nothing is
    // deleted, so the same show comes back.
    var off = hiddenOf(state);
    var air = onAir(scene, cut);
    if (off) air = { width: air.width, height: air.height, id: air.id, objects: [] };
    var next = signatureOf(air) + (off ? '|oculto' : '');
    // The stream is where a clip is heard: the source asks for it with sound,
    // while the control page keeps the same clip silent.
    if (!view) view = new SceneView(stage, { origin: location.origin, muted: off });
    renderedAt = Date.now();
    if (next === signature) {
      // Only the sound changed: a clip already playing just goes quiet.
      view.setMuted(off);
      updateHud(state, air);
      return;
    }
    signature = next;
    view.setMuted(off);
    view.render(air);
    updateHud(state, air);
  }

  /**
   * A transform in flight. Applied straight to the existing node so the stream
   * follows the moderator's cursor without a repaint.
   */
  function patchTransform(object) {
    if (!object || object.scene !== 'program') return;
    if (!view) return;
    if (!view.patch(object)) render({ program: view.scene });
  }

  /* ----------------------------- diagnostics ---------------------------- */

  /*
   * A source that draws nothing and a source that never started look exactly
   * the same from the panel: a black rectangle either way. So the stage tells
   * the server what it can really paint, and a black screen stops being a
   * guessing game. Only ever text and numbers, never anything about the user.
   */
  var errorLog = [];

  function noteError(text) {
    var line = String(text === undefined || text === null ? '' : text).slice(0, 160);
    if (!line) return;
    errorLog.push(line);
    if (errorLog.length > 4) errorLog.shift();
  }

  window.addEventListener('error', function (event) {
    noteError((event && event.message) || 'error');
  });

  window.addEventListener('unhandledrejection', function (event) {
    var reason = event && event.reason;
    noteError((reason && reason.message) || reason || 'promesa rechazada');
  });

  function diagnostics() {
    var box = screenEl.getBoundingClientRect();
    var imgs = stage ? stage.getElementsByTagName('img') : [];
    var broken = 0;
    for (var i = 0; i < imgs.length; i += 1) {
      if (!imgs[i].complete || imgs[i].naturalWidth === 0) broken += 1;
    }
    return {
      viewport: Math.round(window.innerWidth) + '×' + Math.round(window.innerHeight),
      ratio: Math.round((window.devicePixelRatio || 1) * 100) / 100,
      box: Math.round(box.width) + '×' + Math.round(box.height),
      drawn: stage ? stage.getElementsByTagName('*').length : 0,
      imgs: imgs.length,
      broken: broken,
      fit: Math.round(parseFloat(stage.style.transform.replace(/[^0-9.]/g, '')) * 1000) / 1000,
      errors: errorLog.slice(-3),
    };
  }

  /* --------------------------------- hud --------------------------------- */

  function updateHud(state, air) {
    if (!showHud) return;
    var size = Math.round(window.innerWidth) + '×' + Math.round(window.innerHeight);
    var all = air && air.objects ? air.objects.length : 0;
    var visible = air && air.objects
      ? air.objects.filter(function (o) { return o.visible !== false; }).length
      : 0;
    hud.hidden = false;
    hud.classList.toggle('off', !connected);
    hud.textContent = '';
    var dot = document.createElement('span');
    dot.className = 'dot';
    var text = document.createElement('span');
    text.textContent = connected
      ? (hidden ? 'todo oculto' : 'en vivo')
      : lastError || 'sin conexión';
    var meta = document.createElement('span');
    meta.className = 'size';
    meta.textContent = size + ' · ' + (all === visible ? visible + ' objetos' : visible + '/' + all + ' objetos');
    hud.appendChild(dot);
    hud.appendChild(text);
    hud.appendChild(meta);
  }

  window.addEventListener('resize', function () {
    layout();
    var size = Math.round(window.innerWidth) + 'x' + Math.round(window.innerHeight);
    if (size !== canvas) {
      canvas = size;
      if (socket && socket.readyState === 1) {
        try {
          socket.send(JSON.stringify({ type: 'hello', name: 'Pantalla OBS', canvas: canvas }));
        } catch (err) {
          /* best effort only */
        }
      }
    }
    if (showHud) updateHud(null);
  });
  canvas = Math.round(window.innerWidth) + 'x' + Math.round(window.innerHeight);

  /* ----------------------------- auth error ----------------------------- */

  /*
   * A source whose link has gone stale used to show nothing at all: a black
   * rectangle with no explanation anywhere. That was the single most common
   * cause of "OBS shows black and I don't know why", so it now says it out
   * loud, in the middle of the screen, where whoever is on air can see it.
   */
  var authNote = null;

  function clearAuthNote() {
    if (!authNote || !authNote.parentNode) return;
    authNote.parentNode.removeChild(authNote);
    authNote = null;
  }

  function showAuthNote() {
    if (authNote) return;
    authNote = document.createElement('div');
    authNote.className = 'stage-note';
    authNote.textContent = 'Enlace caducado: pide uno nuevo en el panel y vuelve a pegarlo en OBS';
    document.body.appendChild(authNote);
  }

  /* -------------------------------- data --------------------------------- */

  function applyState(state) {
    if (!state || typeof state !== 'object') return;
    connected = true;
    lastError = '';
    clearAuthNote();
    render(state);
  }

  function poll() {
    // The id travels with the poll as well: a source that fell back to polling
    // still has to be visible in the panel, or it would look as if OBS had gone.
    fetch(withToken('/api/state?id=' + encodeURIComponent(stageId())), {
      credentials: 'same-origin',
      cache: 'no-store',
    })
      .then(function (res) {
        if (res.status === 401) {
          // La cookie se ha quedado vieja (se ha cambiado el token): con el que
          // trae esta pagina se puede pedir una nueva sin intervention.
          if (!reauthenticate()) {
            showAuthNote();
            throw new Error('token necesario');
          }
          return;
        }
        if (!res.ok) throw new Error('HTTP ' + res.status);
        return res.json();
      })
      .then(applyState)
      .catch(function (err) {
        connected = false;
        lastError = err.message;
        if (showHud) updateHud(null);
      });
  }

  function startPolling() {
    if (pollTimer) return;
    poll();
    pollTimer = setInterval(poll, 4000);
  }

  function stopPolling() {
    if (!pollTimer) return;
    clearInterval(pollTimer);
    pollTimer = null;
  }

  function connect() {
    var scheme = location.protocol === 'https:' ? 'wss' : 'ws';
    var url = scheme + '://' + location.host
      + withToken('/stage?id=' + encodeURIComponent(stageId()));
    try {
      socket = new WebSocket(url);
    } catch (err) {
      startPolling();
      return;
    }
    socket.addEventListener('open', function () {
      retry = 1000;
      stopPolling();
      poll();
      var hello = { type: 'hello', name: 'Pantalla OBS' };
      if (canvas) hello.canvas = canvas;
      hello.diag = diagnostics();
      try {
        socket.send(JSON.stringify(hello));
      } catch (err) {
        /* the server only uses this for status */
      }
      // From here on the source says "I am still running" every few seconds.
      // Without this the panel has nothing to tell a live source from one that
      // stopped answering an hour ago, because the state itself does not change.
      clearInterval(aliveTimer);
      aliveTimer = setInterval(function () {
        if (socket.readyState !== 1) return;
        try {
          socket.send(JSON.stringify({
            type: 'alive',
            rendered: Date.now() - renderedAt,
            canvas: canvas,
            diag: diagnostics(),
          }));
        } catch (err) {
          /* best effort only */
        }
      }, 5000);
    });
    socket.addEventListener('message', function (event) {
      var payload;
      try {
        payload = JSON.parse(event.data);
      } catch (err) {
        return;
      }
      if (!payload) return;
      if (payload.type === 'state') applyState(payload.state || payload);
      else if (payload.type === 'transform') patchTransform(payload.object);
    });
    socket.addEventListener('close', function () {
      clearInterval(aliveTimer);
      connected = false;
      if (showHud) updateHud(null);
      startPolling();
      setTimeout(connect, retry);
      retry = Math.min(retry * 2, 15000);
    });
    socket.addEventListener('error', function () {
      try {
        socket.close();
      } catch (err) {
        /* the close handler does the rest */
      }
    });
  }

  /*
   * The clips are kept in place from here. A jump arrives as a moment and a
   * clock, so every screen works it out for itself, and this only has to make
   * sure the two do not wander apart over minutes.
   */
  setInterval(function () {
    if (view) view.syncClips();
  }, 2000);

  // OBS throttles a background tab: re-check as soon as it comes back.
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden) poll();
  });

  layout();
  startPolling();
  connect();
})();
